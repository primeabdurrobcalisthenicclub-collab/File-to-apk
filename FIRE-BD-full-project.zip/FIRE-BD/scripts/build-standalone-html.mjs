import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'vite';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');
const outTmpDir = path.join(rootDir, '.standalone-build');
const outHtmlPath = path.join(rootDir, 'public', 'FIRE-BD-standalone.html');

async function main() {
  process.env.NODE_ENV = 'production';
  process.env.STANDALONE_HTML = '1';
  fs.rmSync(outTmpDir, { recursive: true, force: true });
  fs.mkdirSync(path.dirname(outHtmlPath), { recursive: true });

  await build({
    root: rootDir,
    mode: 'production',
    configFile: path.join(rootDir, 'vite.config.ts'),
    build: {
      outDir: outTmpDir,
      emptyOutDir: true,
      assetsInlineLimit: 50 * 1024 * 1024,
      cssCodeSplit: false,
      rolldownOptions: {
        output: {
          format: 'iife',
          inlineDynamicImports: true,
          entryFileNames: 'bundle.js',
          assetFileNames: 'bundle.[ext]',
        },
      },
    },
  });

  const indexHtml = fs.readFileSync(path.join(outTmpDir, 'index.html'), 'utf8');
  const jsPath = path.join(outTmpDir, 'bundle.js');
  const cssPath = path.join(outTmpDir, 'bundle.css');

  const jsCode = fs.existsSync(jsPath)
    ? fs.readFileSync(jsPath, 'utf8').replace(/<\/script/gi, '<\\/script')
    : '';
  const cssCode = fs.existsSync(cssPath)
    ? fs.readFileSync(cssPath, 'utf8').replace(/<\/style/gi, '<\\/style')
    : '';

  let standalone = indexHtml
    .replace(/<link[^>]+rel=["']stylesheet["'][^>]*>/gi, '')
    .replace(/<script[^>]+type=["']module["'][^>]*><\/script>/gi, '');

  if (cssCode) {
    standalone = standalone.replace('</head>', `  <style>\n${cssCode}\n  </style>\n  </head>`);
  }
  if (jsCode) {
    standalone = standalone.replace('</body>', `  <script>\n${jsCode}\n  </script>\n  </body>`);
  }

  fs.writeFileSync(outHtmlPath, standalone, 'utf8');
  fs.rmSync(outTmpDir, { recursive: true, force: true });

  const sizeMb = (fs.statSync(outHtmlPath).size / (1024 * 1024)).toFixed(2);
  console.log(`Generated standalone HTML: ${outHtmlPath} (${sizeMb} MB)`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
