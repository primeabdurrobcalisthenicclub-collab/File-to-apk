import * as THREE from 'three';
import { VehicleDef, WeaponDef, WeaponSkin } from '../types/game';

export function buildWeaponMesh(weapon: WeaponDef, skin: WeaponSkin): THREE.Group {
  const group = new THREE.Group();
  group.name = `weapon_${weapon.id}`;

  const bodyMat = new THREE.MeshStandardMaterial({
    color: skin.bodyColor,
    roughness: 0.32,
    metalness: 0.78,
  });

  const accentMat = new THREE.MeshStandardMaterial({
    color: skin.accentColor,
    roughness: 0.28,
    metalness: 0.65,
    emissive: skin.level >= 2 ? new THREE.Color(skin.accentColor) : new THREE.Color(0x000000),
    emissiveIntensity: skin.level >= 2 ? 0.25 * (skin.level - 1) : 0,
  });

  const steelMat = new THREE.MeshStandardMaterial({
    color: '#1e242b',
    roughness: 0.25,
    metalness: 0.9,
  });

  if (weapon.weaponClass === 'Melee') {
    const isKnife = weapon.id === 'knife';
    const handle = new THREE.Mesh(
      new THREE.CylinderGeometry(isKnife ? 0.018 : 0.025, isKnife ? 0.02 : 0.028, isKnife ? 0.14 : 0.24, 10),
      accentMat
    );
    handle.position.set(0, isKnife ? 0.04 : 0.06, 0);
    group.add(handle);

    const guard = new THREE.Mesh(new THREE.BoxGeometry(isKnife ? 0.065 : 0.09, 0.018, 0.032), steelMat);
    guard.position.set(0, isKnife ? 0.11 : 0.18, 0);
    group.add(guard);

    const blade = new THREE.Mesh(
      new THREE.BoxGeometry(isKnife ? 0.012 : 0.02, isKnife ? 0.24 : 0.52, isKnife ? 0.042 : 0.065),
      bodyMat
    );
    blade.position.set(0, isKnife ? 0.24 : 0.44, 0.008);
    blade.rotation.x = isKnife ? -0.04 : -0.08;
    group.add(blade);
    return group;
  }

  const isSniper = weapon.weaponClass === 'Sniper';
  const isMarksman = weapon.weaponClass === 'Marksman';
  const isShotgun = weapon.weaponClass === 'Shotgun';
  const isSMG = weapon.weaponClass === 'SMG';
  const isPistol = weapon.weaponClass === 'Pistol';
  const isUtility = weapon.weaponClass === 'Utility';
  const isBullpup = weapon.id === 'aug' || weapon.id === 'famas' || weapon.id === 'groza' || weapon.id === 'mag_7';
  const isShieldGun = weapon.id === 'shield_gun';
  const isHeatgun = weapon.id === 'heatgun';
  const isLaser = weapon.id === 'treatment_laser' || weapon.id === 'treatment_gun' || weapon.id === 'treatment_sniper';
  const isVskSuppressed = weapon.id === 'vsk94';
  const isM82b = weapon.id === 'm82b';
  const isWinchester = weapon.id === 'winchester';
  const isRevolver = weapon.id === 'm500' || weapon.id === 'm1917';
  const isScopedPistol = weapon.id === 'm500';
  const isAkimbo = weapon.id === 'usp_2';
  const isDoubleBarrel = weapon.id === 'm1887' || weapon.id === 'tiger_1887' || weapon.id === 'm1873';
  const isTripleBarrel = weapon.id === 'trogon';
  const isChargeBuster = weapon.id === 'charge_buster';

  const bodyLen = isSniper
    ? 0.65
    : isMarksman
    ? 0.56
    : isUtility
    ? 0.54
    : isPistol
    ? weapon.id === 'm1873'
      ? 0.28
      : 0.24
    : isSMG
    ? 0.36
    : 0.48;
  const barrelLen = isSniper
    ? 0.62
    : isMarksman
    ? 0.48
    : isUtility
    ? 0.46
    : isPistol
    ? isRevolver
      ? 0.22
      : 0.16
    : isShotgun
    ? 0.48
    : isSMG
    ? 0.22
    : 0.38;

  const offsets = isAkimbo ? [-0.06, 0.06] : [0];

  offsets.forEach((xOff) => {
    // 1. Primary Receiver
    const receiver = new THREE.Mesh(new THREE.BoxGeometry(isUtility ? 0.095 : 0.068, 0.1, bodyLen), bodyMat);
    receiver.position.set(xOff, 0.02, 0);
    receiver.castShadow = true;
    group.add(receiver);

    // 2. Upper Rail & Trim
    const rail = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.025, bodyLen * 0.9), accentMat);
    rail.position.set(xOff, 0.08, 0);
    group.add(rail);

    // 3. Barrel(s)
    if (isDoubleBarrel) {
      [-0.015, 0.015].forEach((bx) => {
        const b = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.015, barrelLen, 10), steelMat);
        b.rotation.x = Math.PI / 2;
        b.position.set(xOff + bx, 0.036, bodyLen / 2 + barrelLen / 2 - 0.03);
        group.add(b);
      });
    } else if (isTripleBarrel) {
      [
        [0, 0.048],
        [-0.016, 0.022],
        [0.016, 0.022],
      ].forEach(([bx, by]) => {
        const b = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.014, barrelLen, 10), steelMat);
        b.rotation.x = Math.PI / 2;
        b.position.set(xOff + bx, by, bodyLen / 2 + barrelLen / 2 - 0.03);
        group.add(b);
      });
    } else {
      const barrel = new THREE.Mesh(
        new THREE.CylinderGeometry(
          isUtility ? 0.026 : isShotgun ? 0.022 : 0.014,
          isUtility ? 0.028 : isShotgun ? 0.024 : 0.015,
          barrelLen,
          12
        ),
        steelMat
      );
      barrel.rotation.x = Math.PI / 2;
      barrel.position.set(xOff, 0.035, bodyLen / 2 + barrelLen / 2 - 0.03);
      barrel.castShadow = true;
      group.add(barrel);
    }

    // Revolver cylinder drum
    if (isRevolver) {
      const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.034, 0.075, 12), steelMat);
      drum.rotation.x = Math.PI / 2;
      drum.position.set(xOff, 0.026, 0.04);
      group.add(drum);
    }

    // Under-barrel tube for Winchester or M1014/SPAS12/M590
    if (isWinchester || weapon.id === 'm1014' || weapon.id === 'spas12' || weapon.id === 'm590') {
      const underTube = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.013, barrelLen * 0.85, 10), steelMat);
      underTube.rotation.x = Math.PI / 2;
      underTube.position.set(xOff, 0.006, bodyLen / 2 + barrelLen / 2 - 0.05);
      group.add(underTube);
    }

    // 4. Muzzle Brake / Suppressor / Pilot Igniter
    const muzzleMat = isUtility
      ? new THREE.MeshStandardMaterial({
          color: '#f97316',
          emissive: '#f97316',
          emissiveIntensity: 0.9,
          roughness: 0.25,
        })
      : accentMat;
    if (isVskSuppressed) {
      const suppressor = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, barrelLen * 0.72, 12), steelMat);
      suppressor.rotation.x = Math.PI / 2;
      suppressor.position.set(xOff, 0.035, bodyLen / 2 + barrelLen * 0.62);
      group.add(suppressor);
    } else if (isM82b) {
      const brake = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.044, 0.095), accentMat);
      brake.position.set(xOff, 0.035, bodyLen / 2 + barrelLen - 0.01);
      group.add(brake);
      const bipod = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 0.04), steelMat);
      bipod.position.set(xOff, -0.025, bodyLen / 2 + 0.16);
      group.add(bipod);
    } else {
      const muzzle = new THREE.Mesh(new THREE.CylinderGeometry(isUtility ? 0.032 : 0.021, 0.021, 0.065, 10), muzzleMat);
      muzzle.rotation.x = Math.PI / 2;
      muzzle.position.set(xOff, 0.035, bodyLen / 2 + barrelLen - 0.01);
      group.add(muzzle);
    }

    // 5. Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.13, 0.055), accentMat);
    grip.position.set(xOff, -0.075, isBullpup ? 0.05 : -bodyLen * 0.24);
    grip.rotation.x = 0.22;
    group.add(grip);

    // Mini micro-SMG / MAG-7 extended grip magazine
    if (weapon.id === 'mini' || weapon.id === 'g18') {
      const extMag = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.12, 0.038), steelMat);
      extMag.position.set(xOff, -0.15, -bodyLen * 0.26);
      extMag.rotation.x = 0.22;
      group.add(extMag);
    }
  });

  // 6. Stock (not on pistol)
  if (!isPistol) {
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.048, 0.11, isBullpup ? 0.16 : 0.24), accentMat);
    stock.position.set(0, 0.0, -bodyLen / 2 - (isBullpup ? 0.06 : 0.11));
    group.add(stock);
  }

  // 7. Magazine or Flamethrower Fuel Tank
  if (isUtility) {
    const fuelTank = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.28, 12), accentMat);
    fuelTank.rotation.x = Math.PI / 2;
    fuelTank.position.set(0, -0.085, 0.14);
    group.add(fuelTank);
  } else if ((!isShotgun || weapon.id === 'mag_7' || weapon.id === 'trogon') && !isPistol && !isWinchester) {
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.17, 0.065), steelMat);
    mag.position.set(0, -0.1, isBullpup ? -0.14 : 0.06);
    mag.rotation.x = -0.18;
    group.add(mag);
  }

  // 8. Optic Scope (Sniper, Marksman, AR, or M500 scoped revolver)
  if (isSniper || isMarksman || weapon.weaponClass === 'AR' || isScopedPistol) {
    const scopeTube = new THREE.Mesh(
      new THREE.CylinderGeometry(0.022, 0.022, isSniper ? 0.28 : isMarksman ? 0.22 : 0.14, 12),
      steelMat
    );
    scopeTube.rotation.x = Math.PI / 2;
    scopeTube.position.set(0, 0.115, isScopedPistol ? 0.03 : -0.02);
    group.add(scopeTube);

    const lens = new THREE.Mesh(
      new THREE.CylinderGeometry(0.019, 0.019, 0.01, 12),
      new THREE.MeshStandardMaterial({
        color: skin.muzzleColor,
        emissive: skin.muzzleColor,
        emissiveIntensity: 0.7,
        roughness: 0.1,
        metalness: 0.5,
      })
    );
    lens.rotation.x = Math.PI / 2;
    lens.position.set(0, 0.115, isSniper ? 0.125 : isMarksman ? 0.095 : isScopedPistol ? 0.1 : 0.055);
    group.add(lens);
  }

  // 9. Special Weapon Attachments: Shield Gun, Heatgun, Treatment Guns, Charge Buster
  if (isShieldGun) {
    const shieldMat = new THREE.MeshStandardMaterial({
      color: '#38bdf8',
      emissive: '#0284c7',
      emissiveIntensity: 0.45,
      roughness: 0.15,
      metalness: 0.5,
      transparent: true,
      opacity: 0.72,
    });
    const frontShield = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.24, 0.022), shieldMat);
    frontShield.position.set(0, 0.05, bodyLen / 2 + 0.08);
    group.add(frontShield);
  }

  if (isHeatgun || isLaser || isChargeBuster) {
    const glowColor = isHeatgun ? '#f97316' : '#22d3ee';
    const core = new THREE.Mesh(
      new THREE.CylinderGeometry(isPistol ? 0.022 : 0.032, isPistol ? 0.022 : 0.032, isPistol ? 0.12 : 0.22, 12),
      new THREE.MeshStandardMaterial({
        color: glowColor,
        emissive: glowColor,
        emissiveIntensity: 0.9,
        roughness: 0.2,
      })
    );
    core.rotation.x = Math.PI / 2;
    core.position.set(0, 0.035, isPistol ? 0.05 : 0.08);
    group.add(core);
  }

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
    }
  });

  return group;
}

export function buildVehicleMesh(vehicle: VehicleDef): THREE.Group {
  const group = new THREE.Group();
  group.name = `vehicle_${vehicle.id}`;

  const primaryMat = new THREE.MeshPhysicalMaterial({
    color: vehicle.primaryColor,
    roughness: 0.22,
    metalness: 0.68,
    clearcoat: 0.85,
    clearcoatRoughness: 0.12,
  });

  const secondaryMat = new THREE.MeshStandardMaterial({
    color: vehicle.secondaryColor,
    roughness: 0.55,
    metalness: 0.35,
  });

  const accentMat = new THREE.MeshStandardMaterial({
    color: vehicle.accentColor,
    roughness: 0.3,
    metalness: 0.75,
  });

  const glassMat = new THREE.MeshStandardMaterial({
    color: '#0f172a',
    roughness: 0.08,
    metalness: 0.9,
    transparent: true,
    opacity: 0.78,
  });

  const tireMat = new THREE.MeshStandardMaterial({
    color: '#171717',
    roughness: 0.85,
    metalness: 0.1,
  });

  const headlightMat = new THREE.MeshStandardMaterial({
    color: '#fef08a',
    emissive: '#fde047',
    emissiveIntensity: 1.5,
  });

  const addWheel = (x: number, y: number, z: number, radius: number, width: number) => {
    const wheelGroup = new THREE.Group();
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, width, 18), tireMat);
    tire.rotation.z = Math.PI / 2;
    tire.castShadow = true;
    wheelGroup.add(tire);

    const rim = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.56, radius * 0.56, width + 0.02, 12), accentMat);
    rim.rotation.z = Math.PI / 2;
    wheelGroup.add(rim);

    wheelGroup.position.set(x, y, z);
    wheelGroup.userData.isWheel = true;
    group.add(wheelGroup);
  };

  if (vehicle.type === 'sports_car') {
    // Low-slung chassis
    const hull = new THREE.Mesh(new THREE.BoxGeometry(2.05, 0.58, 4.35), primaryMat);
    hull.position.set(0, 0.62, 0);
    hull.castShadow = true;
    group.add(hull);

    // Aerodynamic cabin
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.72, 0.52, 2.05), glassMat);
    cabin.position.set(0, 1.12, -0.15);
    group.add(cabin);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(1.66, 0.1, 1.6), primaryMat);
    roof.position.set(0, 1.4, -0.2);
    group.add(roof);

    // Racing stripe + Rear Spoiler
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.02, 4.32), accentMat);
    stripe.position.set(0, 0.92, 0);
    group.add(stripe);

    const wing = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.08, 0.34), secondaryMat);
    wing.position.set(0, 1.18, -2.02);
    group.add(wing);

    // Headlights
    [-0.72, 0.72].forEach((x) => {
      const light = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.14, 0.08), headlightMat);
      light.position.set(x, 0.68, 2.16);
      group.add(light);
    });

    addWheel(-1.02, 0.38, 1.35, 0.38, 0.28);
    addWheel(1.02, 0.38, 1.35, 0.38, 0.28);
    addWheel(-1.02, 0.38, -1.35, 0.4, 0.3);
    addWheel(1.02, 0.38, -1.35, 0.4, 0.3);
  } else if (vehicle.type === 'monster_truck') {
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(2.15, 0.78, 4.5), primaryMat);
    chassis.position.set(0, 1.35, 0);
    chassis.castShadow = true;
    group.add(chassis);

    const cab = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.75, 1.95), secondaryMat);
    cab.position.set(0, 2.08, 0.35);
    group.add(cab);

    const windshield = new THREE.Mesh(new THREE.BoxGeometry(1.72, 0.48, 0.1), glassMat);
    windshield.position.set(0, 2.1, 1.33);
    group.add(windshield);

    const rollbar = new THREE.Mesh(new THREE.TorusGeometry(0.8, 0.07, 8, 18, Math.PI), accentMat);
    rollbar.position.set(0, 1.75, -0.95);
    group.add(rollbar);

    [-0.78, 0.78].forEach((x) => {
      const light = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.1, 12), headlightMat);
      light.rotation.x = Math.PI / 2;
      light.position.set(x, 1.45, 2.25);
      group.add(light);
    });

    addWheel(-1.26, 0.72, 1.45, 0.72, 0.52);
    addWheel(1.26, 0.72, 1.45, 0.72, 0.52);
    addWheel(-1.26, 0.72, -1.45, 0.72, 0.52);
    addWheel(1.26, 0.72, -1.45, 0.72, 0.52);
  } else if (vehicle.type === 'jeep') {
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.92, 0.72, 4.1), primaryMat);
    body.position.set(0, 0.86, 0);
    body.castShadow = true;
    group.add(body);

    const cage = new THREE.Mesh(new THREE.BoxGeometry(1.76, 0.74, 2.3), secondaryMat);
    cage.position.set(0, 1.56, -0.45);
    group.add(cage);

    const windshield = new THREE.Mesh(new THREE.BoxGeometry(1.66, 0.52, 0.08), glassMat);
    windshield.position.set(0, 1.48, 0.74);
    windshield.rotation.x = -0.15;
    group.add(windshield);

    // Spare wheel mounted on back
    addWheel(0, 1.15, -2.18, 0.42, 0.24);

    [-0.65, 0.65].forEach((x) => {
      const light = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.08, 12), headlightMat);
      light.rotation.x = Math.PI / 2;
      light.position.set(x, 0.96, 2.06);
      group.add(light);
    });

    addWheel(-1.0, 0.46, 1.32, 0.46, 0.3);
    addWheel(1.0, 0.46, 1.32, 0.46, 0.3);
    addWheel(-1.0, 0.46, -1.32, 0.46, 0.3);
    addWheel(1.0, 0.46, -1.32, 0.46, 0.3);
  } else if (vehicle.type === 'amphibious_bike') {
    // Hydro pontoons + streamlined motorcycle hull
    [-0.45, 0.45].forEach((x) => {
      const pontoon = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.24, 2.4), secondaryMat);
      pontoon.position.set(x, 0.34, 0);
      group.add(pontoon);
    });

    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.52, 2.15), primaryMat);
    frame.position.set(0, 0.66, 0);
    frame.castShadow = true;
    group.add(frame);

    const fairing = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.42, 0.8), accentMat);
    fairing.position.set(0, 0.95, 0.68);
    fairing.rotation.x = -0.4;
    group.add(fairing);

    const handlebar = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.88, 10), secondaryMat);
    handlebar.rotation.z = Math.PI / 2;
    handlebar.position.set(0, 1.16, 0.62);
    group.add(handlebar);

    const headlight = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.14, 0.08), headlightMat);
    headlight.position.set(0, 0.92, 1.08);
    group.add(headlight);

    addWheel(0, 0.36, 0.95, 0.36, 0.22);
    addWheel(0, 0.36, -0.92, 0.38, 0.26);
  } else {
    // Dhaka CNG Auto (Tuk-Tuk)
    const lowerBody = new THREE.Mesh(new THREE.BoxGeometry(1.52, 0.68, 2.75), primaryMat);
    lowerBody.position.set(0, 0.65, -0.1);
    lowerBody.castShadow = true;
    group.add(lowerBody);

    const nose = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.65, 0.85), primaryMat);
    nose.position.set(0, 0.7, 1.35);
    group.add(nose);

    const canopy = new THREE.Mesh(new THREE.BoxGeometry(1.56, 0.92, 2.45), secondaryMat);
    canopy.position.set(0, 1.44, -0.2);
    group.add(canopy);

    const windshield = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.56, 0.08), glassMat);
    windshield.position.set(0, 1.32, 1.06);
    windshield.rotation.x = -0.18;
    group.add(windshield);

    const headlight = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.08, 12), headlightMat);
    headlight.rotation.x = Math.PI / 2;
    headlight.position.set(0, 0.78, 1.78);
    group.add(headlight);

    // 3 wheels: 1 front center, 2 rear
    addWheel(0, 0.32, 1.32, 0.32, 0.2);
    addWheel(-0.82, 0.32, -0.95, 0.32, 0.22);
    addWheel(0.82, 0.32, -0.95, 0.32, 0.22);
  }

  return group;
}
