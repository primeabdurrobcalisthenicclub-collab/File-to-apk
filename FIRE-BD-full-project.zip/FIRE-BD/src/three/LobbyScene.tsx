import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EMOTES, OUTFITS, VEHICLES, WEAPONS, WEAPON_SKINS } from '../data/catalog';
import { FriendEntry, LobbyInspectTarget, LobbyWeather } from '../types/game';
import { buildCharacterModel, CharacterAnimRefs, updateCharacterAnimation } from './characterBuilder';
import { ActiveEmoteState, createEmoteFx, EmoteFxHandle } from './emoteProps';
import {
  createContactShadowTexture,
  createTacticalFloorTexture,
  detectSoftwareWebGL,
} from './proceduralTextures';
import { buildVehicleMesh, buildWeaponMesh } from './weaponVehicleBuilder';

interface LobbySceneProps {
  equippedOutfitId: string;
  equippedWeaponId: string;
  equippedSkinId: string;
  equippedVehicleId: string;
  inspectTarget: LobbyInspectTarget;
  squadFriends: FriendEntry[];
  weather: LobbyWeather;
  activeEmote: { id: string; key: number } | null;
}

interface WeatherPreset {
  bg: THREE.Color;
  fogDensity: number;
  hemiSky: THREE.Color;
  hemiGround: THREE.Color;
  hemiIntensity: number;
  keyColor: THREE.Color;
  keyIntensity: number;
  rimColor: THREE.Color;
  rimIntensity: number;
  ringColor: THREE.Color;
  exposure: number;
  floorRoughness: number;
  floorMetalness: number;
}

const WEATHER_PRESETS: Record<LobbyWeather, WeatherPreset> = {
  clear: {
    bg: new THREE.Color('#101926'),
    fogDensity: 0.032,
    hemiSky: new THREE.Color('#93c5fd'),
    hemiGround: new THREE.Color('#1e293b'),
    hemiIntensity: 0.88,
    keyColor: new THREE.Color('#fff1d6'),
    keyIntensity: 2.6,
    rimColor: new THREE.Color('#f59e0b'),
    rimIntensity: 1.7,
    ringColor: new THREE.Color('#f59e0b'),
    exposure: 1.16,
    floorRoughness: 0.48,
    floorMetalness: 0.35,
  },
  rain: {
    bg: new THREE.Color('#09111a'),
    fogDensity: 0.058,
    hemiSky: new THREE.Color('#64748b'),
    hemiGround: new THREE.Color('#0f172a'),
    hemiIntensity: 0.62,
    keyColor: new THREE.Color('#cbd5e1'),
    keyIntensity: 1.25,
    rimColor: new THREE.Color('#38bdf8'),
    rimIntensity: 1.9,
    ringColor: new THREE.Color('#38bdf8'),
    exposure: 1.0,
    floorRoughness: 0.14,
    floorMetalness: 0.62,
  },
  night: {
    bg: new THREE.Color('#040711'),
    fogDensity: 0.044,
    hemiSky: new THREE.Color('#3b82f6'),
    hemiGround: new THREE.Color('#060911'),
    hemiIntensity: 0.36,
    keyColor: new THREE.Color('#93c5fd'),
    keyIntensity: 1.05,
    rimColor: new THREE.Color('#8b5cf6'),
    rimIntensity: 2.2,
    ringColor: new THREE.Color('#38bdf8'),
    exposure: 1.02,
    floorRoughness: 0.34,
    floorMetalness: 0.48,
  },
};

function createSoftParticleTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(32, 32, 2, 32, 32, 30);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(0.35, 'rgba(255,255,255,0.72)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

const _dummyObj = new THREE.Object3D();

export const LobbyScene: React.FC<LobbySceneProps> = ({
  equippedOutfitId,
  equippedWeaponId,
  equippedSkinId,
  equippedVehicleId,
  inspectTarget,
  squadFriends,
  weather,
  activeEmote,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const weatherRef = useRef<LobbyWeather>(weather);
  weatherRef.current = weather;
  const emotePlaybackRef = useRef<ActiveEmoteState | null>(null);
  const emoteFxRef = useRef<EmoteFxHandle | null>(null);

  const stageRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    subjectGroup: THREE.Group;
    animRefs: CharacterAnimRefs[];
    targetCamPos: THREE.Vector3;
    targetLookAt: THREE.Vector3;
    transitionActive: boolean;
  } | null>(null);

  // Initialize Three.js renderer once
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const initialPreset = WEATHER_PRESETS[weatherRef.current];
    scene.background = initialPreset.bg.clone();
    const sceneFog = new THREE.FogExp2(initialPreset.bg.getHex(), initialPreset.fogDensity);
    scene.fog = sceneFog;

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      42,
      container.clientWidth / Math.max(container.clientHeight, 1),
      0.1,
      100
    );
    camera.position.set(0.4, 1.55, 4.1);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.enablePan = false;
    controls.minDistance = 1.6;
    controls.maxDistance = 8.5;
    controls.maxPolarAngle = Math.PI * 0.52;
    controls.minPolarAngle = Math.PI * 0.18;
    controls.target.set(0, 1.05, 0);

    // Three-point warm/cool studio lighting
    const hemi = new THREE.HemisphereLight(
      initialPreset.hemiSky.getHex(),
      initialPreset.hemiGround.getHex(),
      initialPreset.hemiIntensity
    );
    scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(
      initialPreset.keyColor.getHex(),
      initialPreset.keyIntensity
    );
    keyLight.position.set(4.5, 6.5, 5);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 20;
    const d = 4.5;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(
      initialPreset.rimColor.getHex(),
      initialPreset.rimIntensity
    );
    rimLight.position.set(-4, 3.5, -4);
    scene.add(rimLight);

    // Tactical Hangar Floor
    const floorTex = createTacticalFloorTexture(
      isSoftwareGl ? 1 : Math.min(renderer.capabilities.getMaxAnisotropy(), 8)
    );
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorTex,
      roughness: initialPreset.floorRoughness,
      metalness: initialPreset.floorMetalness,
    });
    const floor = new THREE.Mesh(new THREE.CircleGeometry(28, 48), floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Turntable Podium
    const podium = new THREE.Mesh(
      new THREE.CylinderGeometry(1.75, 1.95, 0.14, 48),
      new THREE.MeshStandardMaterial({
        color: '#17202e',
        roughness: 0.3,
        metalness: 0.75,
      })
    );
    podium.position.y = 0.07;
    podium.receiveShadow = true;
    scene.add(podium);

    const podiumRingMat = new THREE.MeshBasicMaterial({
      color: initialPreset.ringColor.getHex(),
      side: THREE.DoubleSide,
    });
    const podiumRing = new THREE.Mesh(new THREE.RingGeometry(1.66, 1.74, 48), podiumRingMat);
    podiumRing.rotation.x = -Math.PI / 2;
    podiumRing.position.y = 0.142;
    scene.add(podiumRing);

    // Contact shadow plane
    const contactShadowTex = createContactShadowTexture();
    const shadowPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(1.8, 1.8),
      new THREE.MeshBasicMaterial({
        map: contactShadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.5,
      })
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.145;
    scene.add(shadowPlane);

    // Tactical Hangar Background Pillars (atmosphere)
    const pillarMat = new THREE.MeshStandardMaterial({
      color: '#111827',
      roughness: 0.65,
      metalness: 0.4,
    });
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2 + 0.4;
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.6, 6.5, 0.6), pillarMat);
      pillar.position.set(Math.cos(angle) * 9.5, 3.25, Math.sin(angle) * 9.5);
      pillar.lookAt(0, 3.25, 0);
      scene.add(pillar);
    }

    // Weather Particle Systems (Clear Sun Motes, Rain Streaks + Splashes, Night Stars + Fireflies + Moon)
    const particleTex = createSoftParticleTexture();

    // 1) Clear Sun Motes
    const moteCount = 120;
    const motePositions = new Float32Array(moteCount * 3);
    const motePhases = new Float32Array(moteCount);
    for (let i = 0; i < moteCount; i++) {
      motePositions[i * 3] = (Math.random() - 0.5) * 14;
      motePositions[i * 3 + 1] = 0.3 + Math.random() * 6.5;
      motePositions[i * 3 + 2] = (Math.random() - 0.5) * 14;
      motePhases[i] = Math.random() * Math.PI * 2;
    }
    const moteGeo = new THREE.BufferGeometry();
    moteGeo.setAttribute('position', new THREE.BufferAttribute(motePositions, 3));
    const moteMat = new THREE.PointsMaterial({
      size: 0.11,
      map: particleTex,
      color: '#fde68a',
      transparent: true,
      opacity: weatherRef.current === 'clear' ? 0.55 : 0,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const motePoints = new THREE.Points(moteGeo, moteMat);
    motePoints.frustumCulled = false;
    scene.add(motePoints);

    // 2) Rain Streaks (LineSegments) + Ground Splash Ripples (InstancedMesh)
    const rainCount = 680;
    const rainPositions = new Float32Array(rainCount * 6);
    const rainSpeeds = new Float32Array(rainCount);
    for (let i = 0; i < rainCount; i++) {
      const rx = (Math.random() - 0.5) * 18;
      const ry = Math.random() * 11;
      const rz = (Math.random() - 0.5) * 18;
      rainSpeeds[i] = 11 + Math.random() * 6;
      const idx = i * 6;
      rainPositions[idx] = rx;
      rainPositions[idx + 1] = ry;
      rainPositions[idx + 2] = rz;
      rainPositions[idx + 3] = rx - 0.08;
      rainPositions[idx + 4] = ry + 0.58;
      rainPositions[idx + 5] = rz - 0.04;
    }
    const rainGeo = new THREE.BufferGeometry();
    rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
    const rainMat = new THREE.LineBasicMaterial({
      color: '#bae6fd',
      transparent: true,
      opacity: weatherRef.current === 'rain' ? 0.55 : 0,
      depthWrite: false,
    });
    const rainLines = new THREE.LineSegments(rainGeo, rainMat);
    rainLines.frustumCulled = false;
    rainLines.visible = weatherRef.current === 'rain';
    scene.add(rainLines);

    const splashCount = 36;
    const splashGeo = new THREE.RingGeometry(0.05, 0.09, 16);
    splashGeo.rotateX(-Math.PI / 2);
    const splashMat = new THREE.MeshBasicMaterial({
      color: '#93c5fd',
      transparent: true,
      opacity: 0.45,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const splashMesh = new THREE.InstancedMesh(splashGeo, splashMat, splashCount);
    splashMesh.frustumCulled = false;
    const splashData: Array<{ x: number; y: number; z: number; life: number; speed: number }> = [];
    for (let i = 0; i < splashCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const rad = 0.6 + Math.random() * 6.5;
      const x = Math.cos(angle) * rad;
      const z = Math.sin(angle) * rad;
      const y = rad < 1.75 ? 0.148 : 0.02;
      splashData.push({ x, y, z, life: Math.random(), speed: 1.6 + Math.random() * 1.1 });
      _dummyObj.position.set(x, y, z);
      _dummyObj.scale.setScalar(1);
      _dummyObj.updateMatrix();
      splashMesh.setMatrixAt(i, _dummyObj.matrix);
    }
    splashMesh.instanceMatrix.needsUpdate = true;
    splashMesh.computeBoundingSphere();
    splashMesh.visible = weatherRef.current === 'rain';
    scene.add(splashMesh);

    // 3) Night Sky Starfield + Glowing Fireflies + Crescent/Full Moon
    const starCount = 320;
    const starPositions = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.42;
      const r = 34 + Math.random() * 10;
      starPositions[i * 3] = Math.sin(phi) * Math.cos(theta) * r;
      starPositions[i * 3 + 1] = Math.cos(phi) * r + 2;
      starPositions[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * r;
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    const starMat = new THREE.PointsMaterial({
      size: 0.24,
      map: particleTex,
      color: '#e0f2fe',
      transparent: true,
      opacity: weatherRef.current === 'night' ? 0.9 : 0,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const starPoints = new THREE.Points(starGeo, starMat);
    starPoints.frustumCulled = false;
    scene.add(starPoints);

    const fireflyCount = 95;
    const fireflyPositions = new Float32Array(fireflyCount * 3);
    const fireflyBase = new Float32Array(fireflyCount * 3);
    const fireflyPhases = new Float32Array(fireflyCount);
    for (let i = 0; i < fireflyCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const rad = 1.4 + Math.random() * 8.5;
      const bx = Math.cos(angle) * rad;
      const by = 0.4 + Math.random() * 4.4;
      const bz = Math.sin(angle) * rad;
      fireflyBase[i * 3] = bx;
      fireflyBase[i * 3 + 1] = by;
      fireflyBase[i * 3 + 2] = bz;
      fireflyPositions[i * 3] = bx;
      fireflyPositions[i * 3 + 1] = by;
      fireflyPositions[i * 3 + 2] = bz;
      fireflyPhases[i] = Math.random() * Math.PI * 2;
    }
    const fireflyGeo = new THREE.BufferGeometry();
    fireflyGeo.setAttribute('position', new THREE.BufferAttribute(fireflyPositions, 3));
    const fireflyMat = new THREE.PointsMaterial({
      size: 0.19,
      map: particleTex,
      color: '#7dd3fc',
      transparent: true,
      opacity: weatherRef.current === 'night' ? 0.85 : 0,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const fireflyPoints = new THREE.Points(fireflyGeo, fireflyMat);
    fireflyPoints.frustumCulled = false;
    scene.add(fireflyPoints);

    const moonMat = new THREE.MeshBasicMaterial({
      color: '#dbeafe',
      transparent: true,
      opacity: weatherRef.current === 'night' ? 0.92 : 0,
      fog: false,
    });
    const moonMesh = new THREE.Mesh(new THREE.SphereGeometry(1.5, 24, 24), moonMat);
    moonMesh.position.set(-14, 15, -24);
    moonMesh.visible = weatherRef.current === 'night';
    scene.add(moonMesh);

    const subjectGroup = new THREE.Group();
    subjectGroup.position.y = 0.14;
    scene.add(subjectGroup);

    stageRef.current = {
      scene,
      camera,
      controls,
      subjectGroup,
      animRefs: [],
      targetCamPos: new THREE.Vector3(0.4, 1.55, 4.1),
      targetLookAt: new THREE.Vector3(0, 1.05, 0),
      transitionActive: false,
    };

    const onControlStart = () => {
      if (stageRef.current) stageRef.current.transitionActive = false;
    };
    controls.addEventListener('start', onControlStart);

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = Math.max(container.clientHeight, 1);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    let lightningTimer = 4.2;
    let lightningFlash = 0;

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.elapsedTime;
      const st = stageRef.current;
      const activeWeather = weatherRef.current;
      const targetPreset = WEATHER_PRESETS[activeWeather];

      // Smoothly transition atmosphere, lighting & floor PBR wetness
      const colorBlend = 1 - Math.exp(-3.8 * dt);
      (scene.background as THREE.Color).lerp(targetPreset.bg, colorBlend);
      sceneFog.color.lerp(targetPreset.bg, colorBlend);
      sceneFog.density = THREE.MathUtils.damp(sceneFog.density, targetPreset.fogDensity, 3.8, dt);

      hemi.color.lerp(targetPreset.hemiSky, colorBlend);
      hemi.groundColor.lerp(targetPreset.hemiGround, colorBlend);
      hemi.intensity = THREE.MathUtils.damp(hemi.intensity, targetPreset.hemiIntensity, 4, dt);

      // Distant storm lightning pulse in Rain mode
      if (activeWeather === 'rain') {
        lightningTimer -= dt;
        if (lightningTimer <= 0) {
          lightningFlash = 1.0;
          lightningTimer = 4.5 + Math.random() * 5.5;
        }
        lightningFlash = THREE.MathUtils.damp(lightningFlash, 0, 10, dt);
      } else {
        lightningFlash = 0;
      }

      keyLight.color.lerp(targetPreset.keyColor, colorBlend);
      keyLight.intensity =
        THREE.MathUtils.damp(keyLight.intensity, targetPreset.keyIntensity, 4, dt) +
        lightningFlash * 2.2;

      rimLight.color.lerp(targetPreset.rimColor, colorBlend);
      rimLight.intensity =
        THREE.MathUtils.damp(rimLight.intensity, targetPreset.rimIntensity, 4, dt) +
        lightningFlash * 1.4;

      podiumRingMat.color.lerp(targetPreset.ringColor, colorBlend);
      floorMat.roughness = THREE.MathUtils.damp(floorMat.roughness, targetPreset.floorRoughness, 3.2, dt);
      floorMat.metalness = THREE.MathUtils.damp(floorMat.metalness, targetPreset.floorMetalness, 3.2, dt);
      renderer.toneMappingExposure = THREE.MathUtils.damp(
        renderer.toneMappingExposure,
        targetPreset.exposure + lightningFlash * 0.28,
        5,
        dt
      );

      // Update Weather Particle Systems
      // 1) Clear Sun Motes
      moteMat.opacity = THREE.MathUtils.damp(
        moteMat.opacity,
        activeWeather === 'clear' ? 0.56 : 0,
        4.5,
        dt
      );
      motePoints.visible = moteMat.opacity > 0.01;
      if (motePoints.visible) {
        const mAttr = moteGeo.attributes.position as THREE.BufferAttribute;
        const arr = mAttr.array as Float32Array;
        for (let i = 0; i < moteCount; i++) {
          const idx = i * 3;
          arr[idx] += Math.sin(elapsed * 0.6 + motePhases[i]) * dt * 0.18;
          arr[idx + 1] += dt * 0.24;
          arr[idx + 2] += Math.cos(elapsed * 0.5 + motePhases[i]) * dt * 0.18;
          if (arr[idx + 1] > 6.8) {
            arr[idx + 1] = 0.25;
            arr[idx] = (Math.random() - 0.5) * 14;
            arr[idx + 2] = (Math.random() - 0.5) * 14;
          }
        }
        mAttr.needsUpdate = true;
      }

      // 2) Rain Streaks & Floor Splashes
      rainMat.opacity = THREE.MathUtils.damp(
        rainMat.opacity,
        activeWeather === 'rain' ? 0.58 : 0,
        6,
        dt
      );
      rainLines.visible = rainMat.opacity > 0.01;
      splashMesh.visible = rainLines.visible;
      if (rainLines.visible) {
        const rAttr = rainGeo.attributes.position as THREE.BufferAttribute;
        const arr = rAttr.array as Float32Array;
        for (let i = 0; i < rainCount; i++) {
          const idx = i * 6;
          const fall = rainSpeeds[i] * dt;
          const windX = fall * 0.14;
          const windZ = fall * 0.06;
          arr[idx] -= windX;
          arr[idx + 1] -= fall;
          arr[idx + 2] -= windZ;
          arr[idx + 3] -= windX;
          arr[idx + 4] -= fall;
          arr[idx + 5] -= windZ;
          if (arr[idx + 1] < 0) {
            const rx = (Math.random() - 0.5) * 18;
            const ry = 9.5 + Math.random() * 2;
            const rz = (Math.random() - 0.5) * 18;
            arr[idx] = rx;
            arr[idx + 1] = ry;
            arr[idx + 2] = rz;
            arr[idx + 3] = rx - 0.08;
            arr[idx + 4] = ry + 0.58;
            arr[idx + 5] = rz - 0.04;
          }
        }
        rAttr.needsUpdate = true;

        splashMat.opacity = rainMat.opacity * 0.85;
        for (let i = 0; i < splashCount; i++) {
          const sp = splashData[i];
          sp.life += dt * sp.speed;
          if (sp.life >= 1) {
            sp.life = 0;
            const angle = Math.random() * Math.PI * 2;
            const rad = 0.6 + Math.random() * 6.5;
            sp.x = Math.cos(angle) * rad;
            sp.z = Math.sin(angle) * rad;
            sp.y = rad < 1.75 ? 0.148 : 0.02;
          }
          const scale = 0.35 + sp.life * 2.1;
          _dummyObj.position.set(sp.x, sp.y, sp.z);
          _dummyObj.scale.setScalar(scale);
          _dummyObj.updateMatrix();
          splashMesh.setMatrixAt(i, _dummyObj.matrix);
        }
        splashMesh.instanceMatrix.needsUpdate = true;
      }

      // 3) Night Sky Stars, Fireflies & Moon
      starMat.opacity = THREE.MathUtils.damp(
        starMat.opacity,
        activeWeather === 'night' ? 0.85 + Math.sin(elapsed * 2.2) * 0.08 : 0,
        4.5,
        dt
      );
      starPoints.visible = starMat.opacity > 0.01;
      if (starPoints.visible) {
        starPoints.rotation.y += dt * 0.012;
      }

      fireflyMat.opacity = THREE.MathUtils.damp(
        fireflyMat.opacity,
        activeWeather === 'night' ? 0.86 : 0,
        4.5,
        dt
      );
      fireflyPoints.visible = fireflyMat.opacity > 0.01;
      if (fireflyPoints.visible) {
        const fAttr = fireflyGeo.attributes.position as THREE.BufferAttribute;
        const arr = fAttr.array as Float32Array;
        for (let i = 0; i < fireflyCount; i++) {
          const idx = i * 3;
          const ph = fireflyPhases[i];
          arr[idx] = fireflyBase[idx] + Math.sin(elapsed * 0.85 + ph) * 0.65;
          arr[idx + 1] = fireflyBase[idx + 1] + Math.sin(elapsed * 1.3 + ph * 1.4) * 0.35;
          arr[idx + 2] = fireflyBase[idx + 2] + Math.cos(elapsed * 0.75 + ph) * 0.65;
        }
        fAttr.needsUpdate = true;
      }

      moonMat.opacity = THREE.MathUtils.damp(
        moonMat.opacity,
        activeWeather === 'night' ? 0.92 : 0,
        4.5,
        dt
      );
      moonMesh.visible = moonMat.opacity > 0.01;

      if (st) {
        if (st.transitionActive) {
          camera.position.x = THREE.MathUtils.damp(camera.position.x, st.targetCamPos.x, 5, dt);
          camera.position.y = THREE.MathUtils.damp(camera.position.y, st.targetCamPos.y, 5, dt);
          camera.position.z = THREE.MathUtils.damp(camera.position.z, st.targetCamPos.z, 5, dt);
          controls.target.x = THREE.MathUtils.damp(controls.target.x, st.targetLookAt.x, 5, dt);
          controls.target.y = THREE.MathUtils.damp(controls.target.y, st.targetLookAt.y, 5, dt);
          controls.target.z = THREE.MathUtils.damp(controls.target.z, st.targetLookAt.z, 5, dt);
          if (camera.position.distanceTo(st.targetCamPos) < 0.03) {
            st.transitionActive = false;
          }
        }

        let curEmote: ActiveEmoteState | null = null;
        if (emotePlaybackRef.current) {
          emotePlaybackRef.current.elapsed += dt;
          if (emotePlaybackRef.current.elapsed >= emotePlaybackRef.current.duration) {
            emotePlaybackRef.current = null;
            if (emoteFxRef.current) {
              st.subjectGroup.remove(emoteFxRef.current.group);
              emoteFxRef.current.dispose();
              emoteFxRef.current = null;
            }
          } else {
            curEmote = emotePlaybackRef.current;
            emoteFxRef.current?.update(curEmote.elapsed, dt);
          }
        }

        st.animRefs.forEach((refs, idx) => {
          updateCharacterAnimation(refs, elapsed + idx * 0.9, 0, 'stand', idx === 0 ? curEmote : null);
        });

        if (st.subjectGroup.userData.rotatePreview) {
          st.subjectGroup.rotation.y += dt * 0.45;
        }
      }

      controls.update();
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', onResize);
      controls.removeEventListener('start', onControlStart);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      if (emoteFxRef.current) {
        emoteFxRef.current.dispose();
        emoteFxRef.current = null;
      }
      controls.dispose();
      envTex.dispose();
      floorTex.dispose();
      contactShadowTex.dispose();
      particleTex.dispose();
      moteGeo.dispose();
      moteMat.dispose();
      rainGeo.dispose();
      rainMat.dispose();
      splashGeo.dispose();
      splashMat.dispose();
      starGeo.dispose();
      starMat.dispose();
      fireflyGeo.dispose();
      fireflyMat.dispose();
      moonMesh.geometry.dispose();
      moonMat.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update displayed 3D subject when outfit, weapon, skin, vehicle, or inspectTarget changes
  useEffect(() => {
    const st = stageRef.current;
    if (!st) return;

    while (st.subjectGroup.children.length > 0) {
      st.subjectGroup.remove(st.subjectGroup.children[0]);
    }
    st.animRefs = [];
    st.subjectGroup.rotation.set(0, 0, 0);
    st.subjectGroup.userData.rotatePreview = false;

    const weapon = WEAPONS.find((w) => w.id === equippedWeaponId) ?? WEAPONS[0];
    const skin = WEAPON_SKINS.find((s) => s.id === equippedSkinId) ?? WEAPON_SKINS[0];

    if (inspectTarget === 'weapon') {
      const gunMesh = buildWeaponMesh(weapon, skin);
      gunMesh.scale.setScalar(2.4);
      gunMesh.position.set(0, 1.05, 0);
      gunMesh.rotation.y = Math.PI / 2;
      st.subjectGroup.add(gunMesh);
      st.subjectGroup.userData.rotatePreview = true;
      st.targetCamPos.set(0, 1.35, 2.75);
      st.targetLookAt.set(0, 1.08, 0);
      st.transitionActive = true;
    } else if (inspectTarget === 'vehicle') {
      const vehicle = VEHICLES.find((v) => v.id === equippedVehicleId) ?? VEHICLES[0];
      const vehMesh = buildVehicleMesh(vehicle);
      vehMesh.scale.setScalar(0.8);
      vehMesh.rotation.y = Math.PI * 0.22;
      st.subjectGroup.add(vehMesh);
      st.subjectGroup.userData.rotatePreview = true;
      st.targetCamPos.set(2.8, 2.2, 5.2);
      st.targetLookAt.set(0, 0.85, 0);
      st.transitionActive = true;
    } else {
      const outfit = OUTFITS.find((o) => o.id === equippedOutfitId) ?? OUTFITS[0];
      const mainChar = buildCharacterModel(outfit, weapon, skin, true);
      mainChar.group.position.set(0, 0, 0);
      st.subjectGroup.add(mainChar.group);
      st.animRefs.push(mainChar.refs);

      // Render invited squadmates standing behind/beside main player
      const offsets = [
        [-1.15, -0.55],
        [1.15, -0.55],
        [-2.0, -1.1],
      ];
      squadFriends.slice(0, 3).forEach((friend, i) => {
        const friendOutfit = OUTFITS.find((o) => o.id === friend.outfitId) ?? OUTFITS[0];
        const mate = buildCharacterModel(friendOutfit, WEAPONS[1], WEAPON_SKINS[2], true);
        const [ox, oz] = offsets[i];
        mate.group.position.set(ox, 0, oz);
        mate.group.rotation.y = ox < 0 ? 0.2 : -0.2;
        st.subjectGroup.add(mate.group);
        st.animRefs.push(mate.refs);
      });

      st.targetCamPos.set(0.3, 1.55, 4.15);
      st.targetLookAt.set(0, 1.05, 0);
      st.transitionActive = true;
    }
  }, [equippedOutfitId, equippedWeaponId, equippedSkinId, equippedVehicleId, inspectTarget, squadFriends]);

  // Trigger 3D Emote Animation & Props on the Lobby Character
  useEffect(() => {
    const st = stageRef.current;
    if (!st || !activeEmote) return;
    if (emoteFxRef.current) {
      st.subjectGroup.remove(emoteFxRef.current.group);
      emoteFxRef.current.dispose();
      emoteFxRef.current = null;
    }
    if (inspectTarget !== 'character') return;
    const def = EMOTES.find((e) => e.id === activeEmote.id);
    if (!def) return;
    emotePlaybackRef.current = { id: def.id, elapsed: 0, duration: def.durationSec };
    const fx = createEmoteFx(def.id);
    emoteFxRef.current = fx;
    st.subjectGroup.add(fx.group);
  }, [activeEmote, inspectTarget]);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing"
      aria-label="3D Interactive Lobby Viewport"
    />
  );
};
