import React, { useEffect, useRef, useState } from 'react';
import {
  Backpack,
  Eye,
  HeartPulse,
  Mic,
  MicOff,
  Package,
  Radio,
  Repeat,
  Smile,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EMOTES, GAME_MODES, OUTFITS, VEHICLES, WEAPONS, WEAPON_SKINS } from '../data/catalog';
import {
  GameModeId,
  HudButtonId,
  HudButtonLayout,
  MatchParticipantStat,
  MatchSummary,
  PlayerProfile,
  SensitivitySettings,
  TeamFormat,
  VehicleDef,
  WeaponDef,
  WeaponSkin,
} from '../types/game';
import { audioEngine } from '../utils/sound';
import { buildCharacterModel, CharacterAnimRefs, updateCharacterAnimation } from './characterBuilder';
import { ActiveEmoteState, createEmoteFx, EmoteFxHandle } from './emoteProps';
import {
  createContainerTexture,
  createGrassTerrainTexture,
  createTacticalFloorTexture,
  detectSoftwareWebGL,
} from './proceduralTextures';
import { buildVehicleMesh } from './weaponVehicleBuilder';

interface BattleArenaProps {
  profile: PlayerProfile;
  modeId: GameModeId;
  format: TeamFormat;
  sensitivity: SensitivitySettings;
  hudLayout: HudButtonLayout[];
  onMatchEnd: (summary: MatchSummary) => void;
  onExitEarly: () => void;
}

interface BotActor {
  id: string;
  name: string;
  team: 'ally' | 'enemy';
  group: THREE.Group;
  refs: CharacterAnimRefs;
  hp: number;
  maxHp: number;
  alive: boolean;
  kills: number;
  damage: number;
  fireCooldown: number;
  strafeAngle: number;
  strafeTimer: number;
  weapon: WeaponDef;
  lastFiredAt: number;
  knocked: boolean;
}

interface LootCrate {
  id: string;
  label: string;
  kind: 'medkit' | 'gloo' | 'ammo' | 'ep';
  x: number;
  z: number;
  mesh: THREE.Mesh;
  collected: boolean;
}

interface RadarBlip {
  id: string;
  x: number;
  z: number;
  team: 'ally' | 'enemy';
  firing: boolean;
  hp: number;
  maxHp: number;
  name: string;
  knocked: boolean;
}

interface ActiveVehicle {
  def: VehicleDef;
  mesh: THREE.Group;
  x: number;
  z: number;
  yaw: number;
  speed: number;
  hp: number;
}

interface GlooWallObj {
  mesh: THREE.Mesh;
  x: number;
  z: number;
  yaw: number;
  hp: number;
}

interface TracerBeam {
  mesh: THREE.Mesh;
  life: number;
}

interface KillFeedEntry {
  id: string;
  killer: string;
  victim: string;
  weapon: string;
  isHeadshot: boolean;
}

// Module-level scratch vectors to avoid GC inside loop
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _rayOrigin = new THREE.Vector3();
const _rayDir = new THREE.Vector3();

function getFormatCounts(format: TeamFormat): { allies: number; enemies: number } {
  const [a, b] = format.split('v').map(Number);
  return { allies: Math.max(0, a - 1), enemies: b };
}

function groundHeightAt(x: number, z: number, isIsland: boolean): number {
  if (!isIsland) return 0;
  // River channel cutting diagonally through Sonar Island
  const riverCenter = Math.sin(x * 0.04) * 12;
  const distToRiver = Math.abs(z - riverCenter);
  if (distToRiver < 5.5) {
    return -0.75 * (1 - distToRiver / 5.5);
  }
  return (
    Math.sin(x * 0.05) * Math.cos(z * 0.05) * 1.15 +
    Math.sin(x * 0.12 + z * 0.09) * 0.32
  );
}

export const BattleArena: React.FC<BattleArenaProps> = ({
  profile,
  modeId,
  format,
  sensitivity,
  hudLayout,
  onMatchEnd,
  onExitEarly,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const modeDef = GAME_MODES.find((m) => m.id === modeId) ?? GAME_MODES[0];
  const isIsland = modeDef.mapKey === 'sonar_island';

  const initialPrimaryWeapon = WEAPONS.find((w) => w.id === profile.equippedWeaponId) ?? WEAPONS[0];
  const initialSecondaryId = initialPrimaryWeapon.id === 'awm' ? 'kar98k' : 'awm';
  const initialSecondaryWeapon = WEAPONS.find((w) => w.id === initialSecondaryId) ?? WEAPONS[0];
  const initialSidearmId = initialPrimaryWeapon.weaponClass === 'Pistol' ? 'doyel_1911' : 'desert_eagle';
  const initialSidearmWeapon = WEAPONS.find((w) => w.id === initialSidearmId) ?? WEAPONS[0];

  // React HUD state
  const [hp, setHp] = useState(200);
  const [maxHp] = useState(200);
  const [ep, setEp] = useState(100);
  const [ammo, setAmmo] = useState(initialPrimaryWeapon.magSize);
  const [reserveAmmo, setReserveAmmo] = useState(initialPrimaryWeapon.magSize * 5);
  const [slotAmmoView, setSlotAmmoView] = useState<[number, number, number, number]>([
    initialPrimaryWeapon.magSize,
    initialSecondaryWeapon.magSize,
    initialSidearmWeapon.magSize,
    999,
  ]);
  const [reloading, setReloading] = useState(false);
  const [glooCount, setGlooCount] = useState(3);
  const [medkitCount, setMedkitCount] = useState(2);
  const [medkitProgress, setMedkitProgress] = useState<number | null>(null);
  const [kills, setKills] = useState(0);
  const [aliveEnemies, setAliveEnemies] = useState(0);
  const [scopeLevel, setScopeLevel] = useState<'none' | 'redDot' | '2x' | '4x' | 'sniper'>('none');
  const [posture, setPosture] = useState<'stand' | 'crouch' | 'prone'>('stand');
  const [sprinting, setSprinting] = useState(false);
  const [autoSprintLock, setAutoSprintLock] = useState(false);
  const [activeSlot, setActiveSlot] = useState<0 | 1 | 2 | 3>(0); // 0=Primary1, 1=Primary2, 2=Pistol, 3=Melee
  const [nearbyVehicleName, setNearbyVehicleName] = useState<string | null>(null);
  const [nearbyLoot, setNearbyLoot] = useState<LootCrate | null>(null);
  const [reviveTarget, setReviveTarget] = useState<{ id: string; name: string } | null>(null);
  const [drivingVehicle, setDrivingVehicle] = useState<VehicleDef | null>(null);
  const [vehicleSpeedKmh, setVehicleSpeedKmh] = useState(0);
  const [zoneRadius, setZoneRadius] = useState(isIsland ? 85 : 40);
  const [zoneTimerSec, setZoneTimerSec] = useState(isIsland ? 140 : 60);
  const [outsideZone, setOutsideZone] = useState(false);
  const [killFeed, setKillFeed] = useState<KillFeedEntry[]>([]);
  const [hitIndicator, setHitIndicator] = useState<'none' | 'body' | 'head'>('none');
  const [damageFlash, setDamageFlash] = useState(false);
  const [aimTargetEnemy, setAimTargetEnemy] = useState(false);
  const [crosshairSpreadPx, setCrosshairSpreadPx] = useState(10);
  const [radarBlips, setRadarBlips] = useState<RadarBlip[]>([]);
  const [playerRadarPose, setPlayerRadarPose] = useState({ x: 0, z: 0, yaw: 0 });
  const [backpackOpen, setBackpackOpen] = useState(false);
  const [weaponBoxOpen, setWeaponBoxOpen] = useState(false);
  const [skillCooldownSec, setSkillCooldownSec] = useState(0);
  const [skillActiveSec, setSkillActiveSec] = useState(0);
  const [micOn, setMicOn] = useState(true);
  const [speakerOn, setSpeakerOn] = useState(!audioEngine.muted);
  const [pingAlert, setPingAlert] = useState<string | null>(null);
  const [emoteWheelOpen, setEmoteWheelOpen] = useState(false);

  // Clash Squad / Round-based state
  const [roundNumber, setRoundNumber] = useState(1);
  const [allyRounds, setAllyRounds] = useState(0);
  const [enemyRounds, setEnemyRounds] = useState(0);
  const [csCash, setCsCash] = useState(1600);
  const [buyPhaseOpen, setBuyPhaseOpen] = useState(modeId === 'cs_rank');
  const [activePrimaryWeaponId, setActivePrimaryWeaponId] = useState(profile.equippedWeaponId);
  const [secondaryWeaponId] = useState(initialSecondaryId);

  // Joystick, Fire-Drag & FreeLook pointer state
  const [joyKnob, setJoyKnob] = useState({ x: 0, y: 0 });
  const joyActiveRef = useRef<{ pointerId: number | null; ox: number; oy: number }>({
    pointerId: null,
    ox: 0,
    oy: 0,
  });
  const fireDragRef = useRef<{ pointerId: number | null; x: number; y: number }>({
    pointerId: null,
    x: 0,
    y: 0,
  });
  const freeLookDragRef = useRef<{ pointerId: number | null; x: number; y: number }>({
    pointerId: null,
    x: 0,
    y: 0,
  });

  // Mutable simulation ref accessed by Three.js loop
  const simRef = useRef({
    keys: {} as Record<string, boolean>,
    joyVec: { x: 0, y: 0 },
    yaw: 0,
    pitch: 0.14,
    freeLookYawOffset: 0,
    isFreeLooking: false,
    firing: false,
    sprinting: false,
    autoSprint: false,
    posture: 'stand' as 'stand' | 'crouch' | 'prone',
    scope: 'none' as 'none' | 'redDot' | '2x' | '4x' | 'sniper',
    activeSlot: 0 as 0 | 1 | 2 | 3,
    previousSlot: 1 as 0 | 1 | 2 | 3,
    hp: 200,
    ep: 100,
    ammo: [initialPrimaryWeapon.magSize, initialSecondaryWeapon.magSize, initialSidearmWeapon.magSize, 999],
    reserve: [initialPrimaryWeapon.magSize * 5, initialSecondaryWeapon.magSize * 5, initialSidearmWeapon.magSize * 5, 999],
    reloading: false,
    glooCount: 3,
    medkitCount: 2,
    medkitTimer: 0,
    skillCooldown: 0,
    skillBuffTimer: 0,
    fireBloom: 0,
    aimHoverEnemy: false,
    aimAssistSlowdown: 1.0,
    kills: 0,
    damageDealt: 0,
    lastFireTime: 0,
    playerPos: new THREE.Vector3(0, 0, isIsland ? 42 : 22),
    velY: 0,
    onGround: true,
    drivingIdx: -1,
    nearbyIdx: -1,
    zoneRadius: isIsland ? 85 : 42,
    matchStartTime: performance.now(),
    matchFinished: false,
    sensitivityObj: sensitivity,
    primaryWeaponId: profile.equippedWeaponId,
    secondaryWeaponId: initialSecondaryId,
    roundNumber: 1,
    allyRounds: 0,
    enemyRounds: 0,
    roundCooldown: 0,
    bots: [] as BotActor[],
    lootCrates: [] as LootCrate[],
    glooWalls: [] as GlooWallObj[],
    vehicles: [] as ActiveVehicle[],
    obstacles: [] as THREE.Box3[],
    tracers: [] as TracerBeam[],
    deployGlooRequested: false,
    medkitRequested: false,
    reloadRequested: false,
    jumpRequested: false,
    driveToggleRequested: false,
    lootCollectRequested: false,
    reviveRequested: false,
    skillRequested: false,
    buyWeaponId: null as string | null,
    lastTouchLook: null as { id: number; x: number; y: number } | null,
    applyLookDeltaFn: null as ((dx: number, dy: number, isFreeLookOverride?: boolean) => void) | null,
    requestedEmoteId: null as string | null,
    activeEmote: null as ActiveEmoteState | null,
  });

  useEffect(() => {
    simRef.current.sensitivityObj = sensitivity;
  }, [sensitivity]);

  useEffect(() => {
    simRef.current.primaryWeaponId = activePrimaryWeaponId;
  }, [activePrimaryWeaponId]);

  const getWeaponIdForSlot = (slot: 0 | 1 | 2 | 3): string => {
    const primaryWeapon = WEAPONS.find((w) => w.id === simRef.current.primaryWeaponId) ?? WEAPONS[0];
    if (slot === 0) return simRef.current.primaryWeaponId;
    if (slot === 1) return simRef.current.secondaryWeaponId;
    if (slot === 2) return primaryWeapon.weaponClass === 'Pistol' ? 'doyel_1911' : 'desert_eagle';
    return primaryWeapon.id === 'knife' ? 'knife' : 'katari_blade';
  };

  const getActiveWeaponAndSkin = (): { weapon: WeaponDef; skin: WeaponSkin } => {
    const wId = getWeaponIdForSlot(simRef.current.activeSlot);
    const weapon = WEAPONS.find((w) => w.id === wId) ?? WEAPONS[0];
    const skinId = profile.equippedSkinIds[weapon.id];
    const skin = WEAPON_SKINS.find((s) => s.id === skinId) ?? WEAPON_SKINS.find((s) => s.weaponId === weapon.id) ?? WEAPON_SKINS[0];
    return { weapon, skin };
  };

  // Main Three.js game engine
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const skyColor = isIsland ? '#7ab8d9' : '#252d3a';
    scene.background = new THREE.Color(skyColor);
    scene.fog = new THREE.FogExp2(skyColor, isIsland ? 0.0068 : 0.012);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      62,
      container.clientWidth / Math.max(container.clientHeight, 1),
      0.1,
      360
    );

    // Warm sun + cool hemisphere
    const hemi = new THREE.HemisphereLight(isIsland ? '#bae6fd' : '#cbd5e1', isIsland ? '#365314' : '#1e293b', 0.85);
    scene.add(hemi);

    const sun = new THREE.DirectionalLight(isIsland ? '#fff5dc' : '#fed7aa', 2.2);
    sun.position.set(45, 70, 35);
    sun.castShadow = !isSoftwareGl;
    sun.shadow.mapSize.set(1024, 1024);
    const sd = isIsland ? 65 : 38;
    sun.shadow.camera.left = -sd;
    sun.shadow.camera.right = sd;
    sun.shadow.camera.top = sd;
    sun.shadow.camera.bottom = -sd;
    sun.shadow.camera.near = 2;
    sun.shadow.camera.far = 170;
    sun.shadow.bias = -0.0005;
    sun.shadow.normalBias = 0.02;
    scene.add(sun);

    const maxAniso = isSoftwareGl ? 1 : Math.min(renderer.capabilities.getMaxAnisotropy(), 8);
    const obstacles: THREE.Box3[] = [];
    const shootableMeshes: THREE.Object3D[] = [];

    if (isIsland) {
      // Sonar Island Rolling Terrain
      const geo = new THREE.PlaneGeometry(240, 240, 64, 64);
      geo.rotateX(-Math.PI / 2);
      const posAttr = geo.attributes.position;
      for (let i = 0; i < posAttr.count; i++) {
        const vx = posAttr.getX(i);
        const vz = posAttr.getZ(i);
        posAttr.setY(i, groundHeightAt(vx, vz, true));
      }
      geo.computeVertexNormals();

      const grassTex = createGrassTerrainTexture(maxAniso);
      const terrain = new THREE.Mesh(
        geo,
        new THREE.MeshStandardMaterial({ map: grassTex, roughness: 0.88, metalness: 0.02 })
      );
      terrain.receiveShadow = true;
      scene.add(terrain);

      // Delta River Water Plane
      const water = new THREE.Mesh(
        new THREE.PlaneGeometry(240, 240),
        new THREE.MeshStandardMaterial({
          color: '#0284c7',
          roughness: 0.14,
          metalness: 0.65,
          transparent: true,
          opacity: 0.82,
        })
      );
      water.rotation.x = -Math.PI / 2;
      water.position.y = -0.18;
      scene.add(water);

      // Instanced Tropical Palm Trees
      const trunkGeo = new THREE.CylinderGeometry(0.18, 0.3, 5.2, 7);
      const trunkMat = new THREE.MeshStandardMaterial({ color: '#5c4033', roughness: 0.9 });
      const crownGeo = new THREE.ConeGeometry(2.1, 1.8, 7);
      const crownMat = new THREE.MeshStandardMaterial({ color: '#2e6f2b', roughness: 0.78 });

      const treePositions: [number, number][] = [];
      for (let i = 0; i < 65; i++) {
        const angle = (i / 65) * Math.PI * 2 + (i % 5) * 0.17;
        const rad = 22 + ((i * 19) % 68);
        const tx = Math.cos(angle) * rad;
        const tz = Math.sin(angle) * rad;
        const ty = groundHeightAt(tx, tz, true);
        if (ty > 0.05) treePositions.push([tx, tz]);
      }

      const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treePositions.length);
      const crownInst = new THREE.InstancedMesh(crownGeo, crownMat, treePositions.length);
      const dummy = new THREE.Object3D();
      treePositions.forEach(([tx, tz], idx) => {
        const ty = groundHeightAt(tx, tz, true);
        const s = 0.85 + (idx % 4) * 0.12;
        dummy.position.set(tx, ty + 2.5 * s, tz);
        dummy.scale.set(s, s, s);
        dummy.rotation.y = idx * 0.7;
        dummy.updateMatrix();
        trunkInst.setMatrixAt(idx, dummy.matrix);

        dummy.position.set(tx, ty + 5.1 * s, tz);
        dummy.updateMatrix();
        crownInst.setMatrixAt(idx, dummy.matrix);
      });
      trunkInst.computeBoundingSphere();
      crownInst.computeBoundingSphere();
      trunkInst.castShadow = true;
      crownInst.castShadow = true;
      scene.add(trunkInst);
      scene.add(crownInst);

      // Tactical Bunkers & Cover Rocks
      const bunkerMat = new THREE.MeshStandardMaterial({ color: '#64748b', roughness: 0.82 });
      const bunkerCoords: [number, number, number, number][] = [
        [0, 0, 6, 3.2],
        [-22, -14, 5, 2.8],
        [24, -18, 6, 3.0],
        [-28, 22, 5.5, 2.8],
        [20, 26, 6, 3.0],
        [10, -34, 5, 2.6],
      ];
      bunkerCoords.forEach(([bx, bz, bw, bh]) => {
        const by = groundHeightAt(bx, bz, true);
        const box = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bw * 0.65), bunkerMat);
        box.position.set(bx, by + bh / 2, bz);
        box.castShadow = true;
        box.receiveShadow = true;
        scene.add(box);
        obstacles.push(new THREE.Box3().setFromObject(box));
      });
    } else {
      // Dhaka Yard Compact Tactical Arena
      const floorTex = createTacticalFloorTexture(maxAniso);
      const arenaFloor = new THREE.Mesh(
        new THREE.PlaneGeometry(110, 110),
        new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.65, metalness: 0.25 })
      );
      arenaFloor.rotation.x = -Math.PI / 2;
      arenaFloor.receiveShadow = true;
      scene.add(arenaFloor);

      // Perimeter Terracotta Brick Warehouse Walls
      const brickMat = new THREE.MeshStandardMaterial({ color: '#7c2d12', roughness: 0.82 });
      [
        [0, -40, 82, 7, 2],
        [0, 40, 82, 7, 2],
        [-40, 0, 2, 7, 82],
        [40, 0, 2, 7, 82],
      ].forEach(([wx, wz, ww, wh, wd]) => {
        const wall = new THREE.Mesh(new THREE.BoxGeometry(ww, wh, wd), brickMat);
        wall.position.set(wx, wh / 2, wz);
        wall.receiveShadow = true;
        scene.add(wall);
        obstacles.push(new THREE.Box3().setFromObject(wall));
      });

      // Stacked Shipping Containers
      const colors = ['#b91c1c', '#1d4ed8', '#d97706', '#047857'];
      const containerSpecs: [number, number, number, number, number, number, number][] = [
        [-12, 1.5, -10, 3.2, 3, 7, 0],
        [12, 1.5, 10, 3.2, 3, 7, 1],
        [-14, 1.5, 12, 7, 3, 3.2, 2],
        [14, 1.5, -12, 7, 3, 3.2, 3],
        [0, 1.5, 0, 4.2, 3.2, 4.2, 0],
        [0, 4.6, 0, 3.6, 2.8, 3.6, 2],
        [-22, 1.5, 0, 3.2, 3, 8, 1],
        [22, 1.5, 0, 3.2, 3, 8, 3],
      ];
      containerSpecs.forEach(([cx, cy, cz, cw, ch, cd, ci]) => {
        const tex = createContainerTexture(colors[ci % colors.length], maxAniso);
        const mesh = new THREE.Mesh(
          new THREE.BoxGeometry(cw, ch, cd),
          new THREE.MeshStandardMaterial({ map: tex, roughness: 0.52, metalness: 0.45 })
        );
        mesh.position.set(cx, cy, cz);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        scene.add(mesh);
        obstacles.push(new THREE.Box3().setFromObject(mesh));
      });
    }

    // Blue Safe Zone Ring
    const zoneRing = new THREE.Mesh(
      new THREE.CylinderGeometry(simRef.current.zoneRadius, simRef.current.zoneRadius, 40, 48, 1, true),
      new THREE.MeshBasicMaterial({
        color: '#38bdf8',
        transparent: true,
        opacity: 0.22,
        side: THREE.DoubleSide,
        depthWrite: false,
      })
    );
    zoneRing.position.y = 18;
    scene.add(zoneRing);

    // Spawn 5 Drivable Vehicles on Sonar Island
    const activeVehicles: ActiveVehicle[] = [];
    if (isIsland) {
      const spawnCoords: [number, number, number][] = [
        [8, 36, 0.3],
        [-16, 26, -0.5],
        [22, 12, 1.2],
        [-12, -2, 0.9], // near river for Amphibious Hydro-Bike!
        [14, -22, -1.1],
      ];
      VEHICLES.forEach((vDef, idx) => {
        const [vx, vz, vyaw] = spawnCoords[idx % spawnCoords.length];
        const vMesh = buildVehicleMesh(vDef);
        const vy = Math.max(-0.15, groundHeightAt(vx, vz, true));
        vMesh.position.set(vx, vy, vz);
        vMesh.rotation.y = vyaw;
        scene.add(vMesh);
        activeVehicles.push({
          def: vDef,
          mesh: vMesh,
          x: vx,
          z: vz,
          yaw: vyaw,
          speed: 0,
          hp: vDef.armor,
        });
      });
    }
    simRef.current.vehicles = activeVehicles;

    // Build Player 3D Model
    const playerOutfit = OUTFITS.find((o) => o.id === profile.equippedOutfitId) ?? OUTFITS[0];
    const { weapon: initWeapon, skin: initSkin } = getActiveWeaponAndSkin();
    const playerChar = buildCharacterModel(playerOutfit, initWeapon, initSkin, true);
    const startZ = isIsland ? 42 : 26;
    simRef.current.playerPos.set(0, groundHeightAt(0, startZ, isIsland), startZ);
    playerChar.group.position.copy(simRef.current.playerPos);
    scene.add(playerChar.group);
    let activeEmoteFx: EmoteFxHandle | null = null;

    // Spawn Allies & Enemies based on format
    const { allies, enemies } = getFormatCounts(format);
    const bots: BotActor[] = [];
    const enemyNames = ['Shadow_BD', 'Tiger_X', 'DhakaViper', 'SniperKing'];
    const allyNames = ['Tanvir_OP', 'Nusrat_Sniper', 'Rafiq_Dhaka'];

    const spawnBot = (idx: number, team: 'ally' | 'enemy') => {
      const outfit = OUTFITS[(idx + (team === 'enemy' ? 5 : 1)) % OUTFITS.length];
      const w = WEAPONS[(idx + 1) % 4];
      const sk = WEAPON_SKINS.find((s) => s.weaponId === w.id) ?? WEAPON_SKINS[0];
      const char = buildCharacterModel(outfit, w, sk, true);

      const angle = (idx / Math.max(1, team === 'enemy' ? enemies : allies)) * Math.PI * 0.8 - Math.PI * 0.4;
      const sx = team === 'enemy' ? Math.sin(angle) * (isIsland ? 34 : 18) : (idx + 1) * 4;
      const sz = team === 'enemy' ? (isIsland ? -24 : -26) : startZ - 3;
      const sy = groundHeightAt(sx, sz, isIsland);

      char.group.position.set(sx, sy, sz);
      // Tag shootable hitbox proxy on torso/head
      char.group.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          child.userData.botId = `${team}_${idx}`;
          child.userData.isHead = child.parent === char.refs.head;
          if (team === 'enemy') shootableMeshes.push(child);
        }
      });

      scene.add(char.group);
      bots.push({
        id: `${team}_${idx}`,
        name: team === 'enemy' ? enemyNames[idx % enemyNames.length] : allyNames[idx % allyNames.length],
        team,
        group: char.group,
        refs: char.refs,
        hp: 180,
        maxHp: 180,
        alive: true,
        kills: 0,
        damage: 0,
        fireCooldown: 1 + Math.random(),
        strafeAngle: Math.random() * Math.PI * 2,
        strafeTimer: 1.5,
        weapon: w,
        lastFiredAt: 0,
        knocked: false,
      });
    };

    for (let i = 0; i < allies; i++) spawnBot(i, 'ally');
    for (let i = 0; i < enemies; i++) spawnBot(i, 'enemy');
    simRef.current.bots = bots;
    setAliveEnemies(enemies);

    // Spawn Contextual Ground Loot Crates
    const lootSpecs: Array<{ kind: LootCrate['kind']; label: string; color: string; x: number; z: number }> = [
      { kind: 'medkit', label: 'Medkit (+1)', color: '#10b981', x: -6, z: isIsland ? 34 : 18 },
      { kind: 'gloo', label: 'Gloo Wall (+2)', color: '#0ea5e9', x: 7, z: isIsland ? 30 : 14 },
      { kind: 'ammo', label: 'Ammo Cache (+40)', color: '#f59e0b', x: -11, z: isIsland ? 14 : 4 },
      { kind: 'ep', label: 'Mushroom / EP (+40)', color: '#a855f7', x: 10, z: isIsland ? 10 : -2 },
      { kind: 'medkit', label: 'Medkit (+1)', color: '#10b981', x: 0, z: isIsland ? -4 : -8 },
      { kind: 'gloo', label: 'Gloo Wall (+2)', color: '#0ea5e9', x: -8, z: isIsland ? -16 : -14 },
    ];
    const lootCrates: LootCrate[] = lootSpecs.map((spec, idx) => {
      const ly = groundHeightAt(spec.x, spec.z, isIsland);
      const mesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.85, 0.55, 0.85),
        new THREE.MeshStandardMaterial({
          color: spec.color,
          emissive: spec.color,
          emissiveIntensity: 0.35,
          roughness: 0.3,
        })
      );
      mesh.position.set(spec.x, ly + 0.3, spec.z);
      mesh.castShadow = true;
      scene.add(mesh);
      return {
        id: `loot_${idx}`,
        label: spec.label,
        kind: spec.kind,
        x: spec.x,
        z: spec.z,
        mesh,
        collected: false,
      };
    });
    simRef.current.lootCrates = lootCrates;

    const onResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / Math.max(container.clientHeight, 1);
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', onResize);

    // Keyboard Controls
    const onKeyDown = (e: KeyboardEvent) => {
      simRef.current.keys[e.code] = true;
      if (e.code === 'Space') simRef.current.jumpRequested = true;
      if (e.code === 'KeyC') {
        const next = simRef.current.posture === 'crouch' ? 'stand' : 'crouch';
        simRef.current.posture = next;
        setPosture(next);
      }
      if (e.code === 'KeyZ') {
        const next = simRef.current.posture === 'prone' ? 'stand' : 'prone';
        simRef.current.posture = next;
        setPosture(next);
      }
      if (e.code === 'KeyG') simRef.current.deployGlooRequested = true;
      if (e.code === 'KeyR') simRef.current.reloadRequested = true;
      if (e.code === 'KeyF') simRef.current.driveToggleRequested = true;
      if (e.code === 'KeyE') simRef.current.lootCollectRequested = true;
      if (e.code === 'KeyQ') {
        const prev = simRef.current.activeSlot;
        const next = simRef.current.previousSlot;
        simRef.current.previousSlot = prev;
        simRef.current.activeSlot = next;
        setActiveSlot(next);
        setAmmo(simRef.current.ammo[next]);
        setReserveAmmo(simRef.current.reserve[next]);
      }
      if (e.code === 'Digit1' || e.code === 'Digit2' || e.code === 'Digit3' || e.code === 'Digit4') {
        const idx = (Number(e.code.replace('Digit', '')) - 1) as 0 | 1 | 2 | 3;
        if (idx !== simRef.current.activeSlot) {
          simRef.current.previousSlot = simRef.current.activeSlot;
        }
        simRef.current.activeSlot = idx;
        setActiveSlot(idx);
        setAmmo(simRef.current.ammo[idx]);
        setReserveAmmo(simRef.current.reserve[idx]);
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      simRef.current.keys[e.code] = false;
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    // Mouse / Touch Look Controls scaled by Sensitivity Settings (0-100) + Aim Assist Slowdown
    const canvasEl = renderer.domElement;
    let draggingLook = false;
    let prevX = 0;
    let prevY = 0;

    const applyLookDelta = (dx: number, dy: number, isFreeLookOverride = false) => {
      const s = simRef.current.sensitivityObj;
      const freeLooking = isFreeLookOverride || simRef.current.isFreeLooking;
      let sensVal = s.general;
      if (freeLooking) sensVal = s.freeLook;
      else if (simRef.current.scope === 'redDot') sensVal = s.redDot;
      else if (simRef.current.scope === '2x') sensVal = s.scope2x;
      else if (simRef.current.scope === '4x') sensVal = s.scope4x;
      else if (simRef.current.scope === 'sniper') sensVal = s.sniperScope;

      const assist = freeLooking ? 1.0 : simRef.current.aimAssistSlowdown;
      const mult = (0.0012 + (sensVal / 100) * 0.0058) * assist;
      if (freeLooking) {
        simRef.current.freeLookYawOffset -= dx * mult;
      } else {
        simRef.current.yaw -= dx * mult;
      }
      simRef.current.pitch = THREE.MathUtils.clamp(simRef.current.pitch + dy * mult * 0.85, -0.58, 0.75);
    };
    simRef.current.applyLookDeltaFn = applyLookDelta;

    const onMouseDown = (e: MouseEvent) => {
      if (e.button === 0) {
        draggingLook = true;
        prevX = e.clientX;
        prevY = e.clientY;
      } else if (e.button === 2) {
        const { weapon } = getActiveWeaponAndSkin();
        const nextScope = simRef.current.scope === 'none' ? (weapon.maxScope === 'none' ? 'redDot' : weapon.maxScope) : 'none';
        simRef.current.scope = nextScope;
        setScopeLevel(nextScope);
      }
    };
    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === canvasEl) {
        applyLookDelta(e.movementX, e.movementY);
      } else if (draggingLook) {
        applyLookDelta(e.clientX - prevX, e.clientY - prevY);
        prevX = e.clientX;
        prevY = e.clientY;
      }
    };
    const onMouseUp = () => {
      draggingLook = false;
    };
    const onContextMenu = (e: MouseEvent) => e.preventDefault();

    const onTouchStart = (e: TouchEvent) => {
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (t.clientX >= window.innerWidth * 0.45 && !simRef.current.lastTouchLook) {
          simRef.current.lastTouchLook = { id: t.identifier, x: t.clientX, y: t.clientY };
        }
      }
    };
    const onTouchMove = (e: TouchEvent) => {
      const active = simRef.current.lastTouchLook;
      if (!active) return;
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (t.identifier === active.id) {
          applyLookDelta(t.clientX - active.x, t.clientY - active.y);
          active.x = t.clientX;
          active.y = t.clientY;
        }
      }
    };
    const onTouchEnd = (e: TouchEvent) => {
      const active = simRef.current.lastTouchLook;
      if (!active) return;
      for (let i = 0; i < e.changedTouches.length; i++) {
        if (e.changedTouches[i].identifier === active.id) {
          simRef.current.lastTouchLook = null;
        }
      }
    };

    canvasEl.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    canvasEl.addEventListener('contextmenu', onContextMenu);
    canvasEl.addEventListener('touchstart', onTouchStart, { passive: true });
    canvasEl.addEventListener('touchmove', onTouchMove, { passive: true });
    canvasEl.addEventListener('touchend', onTouchEnd);
    canvasEl.addEventListener('touchcancel', onTouchEnd);

    const raycaster = new THREE.Raycaster();
    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;

    const spawnTracer = (from: THREE.Vector3, to: THREE.Vector3, colorHex: string) => {
      const dist = Math.max(0.5, from.distanceTo(to));
      const beam = new THREE.Mesh(
        new THREE.CylinderGeometry(0.025, 0.025, dist, 6),
        new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 0.85 })
      );
      beam.position.copy(from).lerp(to, 0.5);
      beam.lookAt(to);
      beam.rotateX(Math.PI / 2);
      scene.add(beam);
      simRef.current.tracers.push({ mesh: beam, life: 0.1 });
    };

    const finishMatch = (victory: boolean) => {
      if (simRef.current.matchFinished) return;
      simRef.current.matchFinished = true;
      if (victory) audioEngine.playVictoryFanfare();

      const participants: MatchParticipantStat[] = [
        {
          id: 'player',
          name: profile.username,
          team: 'ally',
          isPlayer: true,
          kills: simRef.current.kills,
          damage: Math.round(simRef.current.damageDealt),
          survived: simRef.current.hp > 0,
          likesReceived: 0,
          likedByMe: false,
        },
        ...simRef.current.bots.map((b) => ({
          id: b.id,
          name: b.name,
          team: b.team,
          isPlayer: false,
          kills: b.kills,
          damage: Math.round(b.damage),
          survived: b.alive,
          likesReceived: Math.floor(Math.random() * 2),
          likedByMe: false,
        })),
      ];

      onMatchEnd({
        modeId,
        format,
        victory,
        placement: victory ? 1 : 2,
        totalTeams: 2,
        playerKills: simRef.current.kills,
        playerDamage: Math.round(simRef.current.damageDealt),
        rankDelta: modeDef.isRanked ? (victory ? 32 + simRef.current.kills * 4 : -12 + simRef.current.kills * 2) : 0,
        goldEarned: (victory ? 450 : 180) + simRef.current.kills * 55,
        durationSec: Math.max(5, Math.round((performance.now() - simRef.current.matchStartTime) / 1000)),
        participants,
      });
    };

    const resetRound = () => {
      simRef.current.hp = 200;
      setHp(200);
      simRef.current.playerPos.set(0, 0, 26);
      simRef.current.glooCount = 3;
      setGlooCount(3);
      simRef.current.bots.forEach((b, idx) => {
        b.alive = true;
        b.hp = b.maxHp;
        b.group.visible = true;
        const sx = (idx - 1.5) * 6;
        const sz = b.team === 'enemy' ? -24 : 22;
        b.group.position.set(sx, 0, sz);
      });
      setAliveEnemies(simRef.current.bots.filter((b) => b.team === 'enemy' && b.alive).length);
      if (modeId === 'cs_rank') setBuyPhaseOpen(true);
    };

    const handlePlayerFire = (nowMs: number) => {
      const st = simRef.current;
      if (st.reloading || st.drivingIdx >= 0 || st.hp <= 0) return;

      const { weapon, skin } = getActiveWeaponAndSkin();
      const fireInterval = weapon.fireRateMs * (1 - skin.fireRateBonusPct / 100);
      if (nowMs - st.lastFireTime < fireInterval) return;

      const slot = st.activeSlot;
      const infiniteAmmo = weapon.weaponClass === 'Melee' || weapon.id === 'heatgun';
      if (!infiniteAmmo && st.ammo[slot] <= 0) {
        st.reloadRequested = true;
        return;
      }

      st.lastFireTime = nowMs;
      st.fireBloom = Math.min(14, st.fireBloom + 4.5);
      if (!infiniteAmmo) {
        st.ammo[slot] -= 1;
        setAmmo(st.ammo[slot]);
        setSlotAmmoView([st.ammo[0], st.ammo[1], st.ammo[2], st.ammo[3]]);
      }
      audioEngine.playGunshot(weapon.weaponClass);

      const pellets = weapon.pellets ?? 1;
      const totalDmg = weapon.damage + skin.damageBonus;
      const muzzlePos = _v1.copy(st.playerPos).add(new THREE.Vector3(0, st.posture === 'prone' ? 0.45 : 1.35, 0));

      for (let p = 0; p < pellets; p++) {
        const spreadX = (Math.random() - 0.5) * weapon.spread * (st.scope === 'none' ? 1 : 0.25);
        const spreadY = (Math.random() - 0.5) * weapon.spread * (st.scope === 'none' ? 1 : 0.25);

        _rayDir.set(spreadX, spreadY, -1).normalize();
        _rayDir.applyEuler(new THREE.Euler(-st.pitch, st.yaw, 0, 'YXZ'));
        _rayOrigin.copy(camera.position);

        raycaster.set(_rayOrigin, _rayDir);
        raycaster.far = weapon.range;

        // Check Gloo Wall blocking first
        const glooMeshes = st.glooWalls.map((g) => g.mesh);
        const glooHits = raycaster.intersectObjects(glooMeshes, false);
        const botHits = raycaster.intersectObjects(shootableMeshes, false);

        let hitPoint = _rayOrigin.clone().add(_rayDir.clone().multiplyScalar(Math.min(weapon.range, 65)));

        if (
          glooHits.length > 0 &&
          (botHits.length === 0 || glooHits[0].distance < botHits[0].distance)
        ) {
          hitPoint = glooHits[0].point;
          const gw = st.glooWalls.find((g) => g.mesh === glooHits[0].object);
          if (gw) {
            const wallMult = weapon.id === 'm82b' ? 2.6 : weapon.id === 'flamethrower' ? 2.2 : 1;
            gw.hp -= totalDmg * wallMult;
            if (gw.hp <= 0) {
              scene.remove(gw.mesh);
              st.glooWalls = st.glooWalls.filter((g) => g !== gw);
            }
          }
          // M82B anti-materiel pierces Gloo Walls to also hit targets behind them
          if (weapon.id === 'm82b' && botHits.length > 0) {
            const pierceHit = botHits[0];
            const botId = pierceHit.object.userData.botId;
            const isHead = Boolean(pierceHit.object.userData.isHead);
            const bot = st.bots.find((b) => b.id === botId && b.alive);
            if (bot) {
              const dmg = Math.round((isHead ? totalDmg * 1.8 : totalDmg) * 0.78);
              bot.hp -= dmg;
              st.damageDealt += dmg;
              audioEngine.playHitmarker(isHead);
              setHitIndicator(isHead ? 'head' : 'body');
              setTimeout(() => setHitIndicator('none'), 140);
            }
          }
        } else if (botHits.length > 0) {
          const hit = botHits[0];
          hitPoint = hit.point;
          const botId = hit.object.userData.botId;
          const isHead = Boolean(hit.object.userData.isHead);
          const bot = st.bots.find((b) => b.id === botId && b.alive);
          if (bot) {
            const dmg = isHead ? Math.round(totalDmg * 1.8) : totalDmg;
            bot.hp -= dmg;
            st.damageDealt += dmg;
            if (
              (weapon.id === 'treatment_laser' || weapon.id === 'treatment_gun' || weapon.id === 'treatment_sniper') &&
              st.hp < maxHp
            ) {
              const healAmt = weapon.id === 'treatment_sniper' ? 22 : weapon.id === 'treatment_gun' ? 8 : 6;
              st.hp = Math.min(maxHp, st.hp + healAmt);
              setHp(Math.ceil(st.hp));
            }
            if (weapon.id === 'treatment_sniper') {
              st.bots.forEach((ally) => {
                if (ally.team === 'ally' && ally.alive && ally.hp < ally.maxHp) {
                  ally.hp = Math.min(ally.maxHp, ally.hp + 30);
                  ally.knocked = ally.hp <= 45;
                }
              });
            }
            audioEngine.playHitmarker(isHead);
            setHitIndicator(isHead ? 'head' : 'body');
            setTimeout(() => setHitIndicator('none'), 140);

            if (bot.hp <= 0) {
              bot.alive = false;
              bot.group.visible = false;
              st.kills += 1;
              setKills(st.kills);
              setCsCash((c) => c + 400);
              setKillFeed((kf) => [
                { id: `${Date.now()}_${Math.random()}`, killer: profile.username, victim: bot.name, weapon: weapon.name, isHeadshot: isHead },
                ...kf.slice(0, 3),
              ]);
            }
          }
        }

        if (weapon.weaponClass !== 'Melee') {
          spawnTracer(muzzlePos, hitPoint, skin.muzzleColor);
        }
      }
    };

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.elapsedTime;
      const st = simRef.current;

      if (!st.matchFinished) {
        // 1. Update Zone Shrink & Countdown in BR modes
        if (isIsland && st.zoneRadius > 16) {
          st.zoneRadius = Math.max(16, st.zoneRadius - dt * 0.48);
          zoneRing.scale.set(st.zoneRadius / 85, 1, st.zoneRadius / 85);
          if (Math.floor(elapsed * 2) !== Math.floor((elapsed - dt) * 2)) {
            setZoneRadius(Math.round(st.zoneRadius));
            setZoneTimerSec(Math.max(0, Math.round((st.zoneRadius - 16) / 0.48)));
          }
        }

        const distFromCenter = Math.hypot(st.playerPos.x, st.playerPos.z);
        const isOut = distFromCenter > st.zoneRadius;
        if (isOut) {
          st.hp = Math.max(0, st.hp - dt * 6);
          setHp(Math.ceil(st.hp));
          setOutsideZone(true);
        } else {
          setOutsideZone(false);
        }

        // 2. Handle Reload
        if (st.reloadRequested && !st.reloading) {
          st.reloadRequested = false;
          const slot = st.activeSlot;
          const { weapon } = getActiveWeaponAndSkin();
          if (slot !== 3 && st.ammo[slot] < weapon.magSize && st.reserve[slot] > 0) {
            st.reloading = true;
            setReloading(true);
            setTimeout(() => {
              const needed = weapon.magSize - st.ammo[slot];
              const take = Math.min(needed, st.reserve[slot]);
              st.ammo[slot] += take;
              st.reserve[slot] -= take;
              st.reloading = false;
              setReloading(false);
              setSlotAmmoView([st.ammo[0], st.ammo[1], st.ammo[2], st.ammo[3]]);
              if (st.activeSlot === slot) {
                setAmmo(st.ammo[slot]);
                setReserveAmmo(st.reserve[slot]);
              }
            }, weapon.reloadMs);
          }
        }

        // 3. Handle Medkit Circular Progress Timer (1.4s)
        if (st.medkitRequested && st.medkitCount > 0 && st.hp < maxHp && st.medkitTimer <= 0) {
          st.medkitRequested = false;
          st.medkitTimer = 1.4;
          setMedkitProgress(0);
        } else {
          st.medkitRequested = false;
        }
        if (st.medkitTimer > 0) {
          st.medkitTimer -= dt;
          if (st.medkitTimer <= 0) {
            st.medkitTimer = 0;
            setMedkitProgress(null);
            if (st.medkitCount > 0 && st.hp > 0) {
              st.medkitCount -= 1;
              st.hp = Math.min(maxHp, st.hp + 75);
              setMedkitCount(st.medkitCount);
              setHp(Math.ceil(st.hp));
            }
          } else {
            setMedkitProgress(1 - st.medkitTimer / 1.4);
          }
        }

        // 3b. Active Character Skill (Tactical Surge: +40 HP & +22% Sprint, 18s CD)
        if (st.skillRequested && st.skillCooldown <= 0) {
          st.skillRequested = false;
          st.skillCooldown = 18;
          st.skillBuffTimer = 5;
          st.hp = Math.min(maxHp, st.hp + 40);
          setHp(Math.ceil(st.hp));
          setSkillCooldownSec(18);
          setSkillActiveSec(5);
          audioEngine.playStartChime();
        } else {
          st.skillRequested = false;
        }
        if (st.skillCooldown > 0) {
          const prevC = Math.ceil(st.skillCooldown);
          st.skillCooldown = Math.max(0, st.skillCooldown - dt);
          if (Math.ceil(st.skillCooldown) !== prevC) setSkillCooldownSec(Math.ceil(st.skillCooldown));
        }
        if (st.skillBuffTimer > 0) {
          const prevB = Math.ceil(st.skillBuffTimer);
          st.skillBuffTimer = Math.max(0, st.skillBuffTimer - dt);
          if (Math.ceil(st.skillBuffTimer) !== prevB) setSkillActiveSec(Math.ceil(st.skillBuffTimer));
        }

        // 4. Handle Gloo Wall Deploy
        if (st.deployGlooRequested && st.glooCount > 0) {
          st.deployGlooRequested = false;
          st.glooCount -= 1;
          setGlooCount(st.glooCount);
          audioEngine.playGlooDeploy();

          const forwardX = -Math.sin(st.yaw);
          const forwardZ = -Math.cos(st.yaw);
          const gx = st.playerPos.x + forwardX * 2.8;
          const gz = st.playerPos.z + forwardZ * 2.8;
          const gy = groundHeightAt(gx, gz, isIsland);

          const gMesh = new THREE.Mesh(
            new THREE.CylinderGeometry(2.1, 2.1, 2.3, 14, 1, false, -Math.PI * 0.35, Math.PI * 0.7),
            new THREE.MeshStandardMaterial({
              color: '#0ea5e9',
              emissive: '#0284c7',
              emissiveIntensity: 0.35,
              roughness: 0.2,
              metalness: 0.4,
              transparent: true,
              opacity: 0.86,
              side: THREE.DoubleSide,
            })
          );
          gMesh.position.set(gx, gy + 1.15, gz);
          gMesh.rotation.y = st.yaw + Math.PI;
          gMesh.castShadow = true;
          scene.add(gMesh);
          st.glooWalls.push({ mesh: gMesh, x: gx, z: gz, yaw: st.yaw, hp: 320 });
        } else {
          st.deployGlooRequested = false;
        }

        // 5. Handle Vehicle Enter / Exit
        let closestIdx = -1;
        let closestDist = 4.6;
        st.vehicles.forEach((v, idx) => {
          const d = Math.hypot(v.x - st.playerPos.x, v.z - st.playerPos.z);
          if (d < closestDist) {
            closestDist = d;
            closestIdx = idx;
          }
        });
        if (closestIdx !== st.nearbyIdx) {
          st.nearbyIdx = closestIdx;
          setNearbyVehicleName(closestIdx >= 0 ? st.vehicles[closestIdx].def.name : null);
        }

        if (st.driveToggleRequested) {
          st.driveToggleRequested = false;
          if (st.drivingIdx >= 0) {
            // Exit vehicle
            const v = st.vehicles[st.drivingIdx];
            st.playerPos.set(v.x + 2.2, groundHeightAt(v.x + 2.2, v.z, isIsland), v.z);
            st.drivingIdx = -1;
            playerChar.group.visible = true;
            setDrivingVehicle(null);
            setVehicleSpeedKmh(0);
          } else if (closestIdx >= 0) {
            st.drivingIdx = closestIdx;
            playerChar.group.visible = false;
            setDrivingVehicle(st.vehicles[closestIdx].def);
          }
        }

        // 5b. Contextual Loot Crates & Revive Knocked Ally Check
        let closestLoot: LootCrate | null = null;
        let closestLootDist = 3.8;
        st.lootCrates.forEach((crate) => {
          if (crate.collected) return;
          crate.mesh.rotation.y += dt * 1.4;
          const d = Math.hypot(crate.x - st.playerPos.x, crate.z - st.playerPos.z);
          if (d < closestLootDist) {
            closestLootDist = d;
            closestLoot = crate;
          }
        });
        setNearbyLoot(closestLoot);

        if (st.lootCollectRequested && closestLoot) {
          st.lootCollectRequested = false;
          const lc = closestLoot as LootCrate;
          lc.collected = true;
          scene.remove(lc.mesh);
          audioEngine.playUiClick();
          if (lc.kind === 'medkit') {
            st.medkitCount += 1;
            setMedkitCount(st.medkitCount);
          } else if (lc.kind === 'gloo') {
            st.glooCount += 2;
            setGlooCount(st.glooCount);
          } else if (lc.kind === 'ammo') {
            st.reserve[0] += 40;
            st.reserve[1] += 40;
            setReserveAmmo(st.reserve[st.activeSlot]);
          } else if (lc.kind === 'ep') {
            st.ep = Math.min(100, st.ep + 40);
            setEp(st.ep);
          }
        } else {
          st.lootCollectRequested = false;
        }

        // Revive nearby injured/knocked ally
        let foundRevive: { id: string; name: string } | null = null;
        for (const ally of st.bots) {
          if (ally.team === 'ally' && ally.alive && ally.hp <= 55) {
            ally.knocked = true;
            const d = ally.group.position.distanceTo(st.playerPos);
            if (d < 4.5) {
              foundRevive = { id: ally.id, name: ally.name };
              if (st.reviveRequested) {
                ally.hp = 150;
                ally.knocked = false;
                foundRevive = null;
                audioEngine.playStartChime();
              }
              break;
            }
          }
        }
        st.reviveRequested = false;
        setReviveTarget(foundRevive);

        // 6. Player or Vehicle Movement
        const moveInputX = (st.keys['KeyD'] || st.keys['ArrowRight'] ? 1 : 0) - (st.keys['KeyA'] || st.keys['ArrowLeft'] ? 1 : 0) + st.joyVec.x;
        const moveInputZ =
          (st.keys['KeyW'] || st.keys['ArrowUp'] ? 1 : 0) -
          (st.keys['KeyS'] || st.keys['ArrowDown'] ? 1 : 0) -
          st.joyVec.y +
          (st.autoSprint && Math.abs(st.joyVec.y) < 0.15 ? 1 : 0);

        if (st.drivingIdx >= 0) {
          const veh = st.vehicles[st.drivingIdx];
          const throttle = THREE.MathUtils.clamp(moveInputZ, -1, 1);
          const steer = THREE.MathUtils.clamp(-moveInputX, -1, 1);

          if (Math.abs(throttle) > 0.05) {
            veh.speed = THREE.MathUtils.clamp(
              veh.speed + throttle * veh.def.acceleration * dt,
              -veh.def.topSpeed * 0.4,
              veh.def.topSpeed
            );
          } else {
            veh.speed = THREE.MathUtils.damp(veh.speed, 0, 3.5, dt);
          }

          if (Math.abs(veh.speed) > 0.5) {
            veh.yaw += steer * veh.def.handling * dt * (veh.speed >= 0 ? 1 : -1);
          }

          const nx = THREE.MathUtils.clamp(veh.x + Math.sin(veh.yaw) * veh.speed * dt, -105, 105);
          const nz = THREE.MathUtils.clamp(veh.z + Math.cos(veh.yaw) * veh.speed * dt, -105, 105);
          const groundY = groundHeightAt(nx, nz, isIsland);

          const inWater = groundY < -0.22;
          if (inWater && !veh.def.amphibious) {
            veh.speed *= 0.92;
          }
          veh.x = nx;
          veh.z = nz;
          veh.mesh.position.set(nx, Math.max(-0.15, groundY), nz);
          veh.mesh.rotation.y = veh.yaw;

          veh.mesh.children.forEach((ch) => {
            if (ch.userData.isWheel) ch.rotation.x += veh.speed * dt * 0.8;
          });

          st.playerPos.set(nx, Math.max(-0.15, groundY), nz);
          st.yaw = THREE.MathUtils.damp(st.yaw, veh.yaw + Math.PI, 4.5, dt);
          setVehicleSpeedKmh(Math.round(Math.abs(veh.speed) * 4.2));
        } else {
          // Foot movement
          const len = Math.hypot(moveInputX, moveInputZ);
          const normX = len > 1 ? moveInputX / len : moveInputX;
          const normZ = len > 1 ? moveInputZ / len : moveInputZ;

          const skillMult = st.skillBuffTimer > 0 ? 1.22 : 1.0;
          const isSprintActive = st.sprinting || st.autoSprint || st.keys['ShiftLeft'];
          const baseSpeed =
            (st.posture === 'prone' ? 2.4 : st.posture === 'crouch' ? 4.2 : isSprintActive ? 9.4 : 6.6) * skillMult;
          const sinY = Math.sin(st.yaw);
          const cosY = Math.cos(st.yaw);

          const dx = (normX * cosY - normZ * sinY) * baseSpeed * dt;
          const dz = (-normX * sinY - normZ * cosY) * baseSpeed * dt;

          const bound = isIsland ? 105 : 37;
          let nextX = THREE.MathUtils.clamp(st.playerPos.x + dx, -bound, bound);
          let nextZ = THREE.MathUtils.clamp(st.playerPos.z + dz, -bound, bound);

          for (const box of obstacles) {
            if (nextX > box.min.x - 0.5 && nextX < box.max.x + 0.5 && nextZ > box.min.z - 0.5 && nextZ < box.max.z + 0.5) {
              nextX = st.playerPos.x;
              nextZ = st.playerPos.z;
              break;
            }
          }

          if (st.jumpRequested && st.onGround) {
            st.velY = 7.4;
            st.onGround = false;
            st.posture = 'stand';
            setPosture('stand');
          }
          st.jumpRequested = false;

          st.velY -= 20 * dt;
          st.playerPos.y += st.velY * dt;
          const groundY = groundHeightAt(nextX, nextZ, isIsland);
          if (st.playerPos.y <= groundY) {
            st.playerPos.y = groundY;
            st.velY = 0;
            st.onGround = true;
          }
          st.playerPos.x = nextX;
          st.playerPos.z = nextZ;

          playerChar.group.position.copy(st.playerPos);
          playerChar.group.rotation.y = st.yaw + Math.PI;

          // Handle live in-match emote playback (auto-cancels on move, fire, or jump)
          if (st.requestedEmoteId) {
            const def = EMOTES.find((e) => e.id === st.requestedEmoteId);
            if (def) {
              st.activeEmote = { id: def.id, elapsed: 0, duration: def.durationSec };
              if (activeEmoteFx) {
                playerChar.group.remove(activeEmoteFx.group);
                activeEmoteFx.dispose();
              }
              activeEmoteFx = createEmoteFx(def.id);
              playerChar.group.add(activeEmoteFx.group);
            }
            st.requestedEmoteId = null;
          }

          const cancelEmote = len > 0.14 || st.firing || !st.onGround || st.posture !== 'stand';
          if (cancelEmote && st.activeEmote) {
            st.activeEmote = null;
            if (activeEmoteFx) {
              playerChar.group.remove(activeEmoteFx.group);
              activeEmoteFx.dispose();
              activeEmoteFx = null;
            }
          } else if (st.activeEmote) {
            st.activeEmote.elapsed += dt;
            if (st.activeEmote.elapsed >= st.activeEmote.duration) {
              st.activeEmote = null;
              if (activeEmoteFx) {
                playerChar.group.remove(activeEmoteFx.group);
                activeEmoteFx.dispose();
                activeEmoteFx = null;
              }
            } else if (activeEmoteFx) {
              activeEmoteFx.update(st.activeEmote.elapsed, dt);
            }
          }

          updateCharacterAnimation(
            playerChar.refs,
            elapsed,
            len * (isSprintActive ? 1.3 : 1),
            st.posture,
            st.activeEmote ?? undefined
          );

          // Crosshair Bloom & Magnetic Aim Assist Check
          st.fireBloom = Math.max(0, st.fireBloom - dt * 18);
          _rayDir.set(0, 0, -1).applyEuler(new THREE.Euler(-st.pitch, st.yaw, 0, 'YXZ')).normalize();
          raycaster.set(camera.position, _rayDir);
          raycaster.far = 220;
          const aimHits = raycaster.intersectObjects(shootableMeshes, false);
          const hoveringEnemy = aimHits.length > 0;
          st.aimHoverEnemy = hoveringEnemy;

          // Subtle magnetic aim assist cone check
          let nearEnemyCone = hoveringEnemy;
          if (!nearEnemyCone) {
            for (const b of st.bots) {
              if (!b.alive || b.team !== 'enemy') continue;
              _v1.copy(b.group.position).add(new THREE.Vector3(0, 1.25, 0)).sub(camera.position).normalize();
              if (_v1.dot(_rayDir) > 0.9965) {
                nearEnemyCone = true;
                break;
              }
            }
          }
          st.aimAssistSlowdown = hoveringEnemy ? 0.44 : nearEnemyCone ? 0.68 : 1.0;

          const baseSpread = st.scope !== 'none' ? 3 : st.posture === 'prone' ? 4 : st.posture === 'crouch' ? 6 : 9;
          const targetSpread = Math.round(baseSpread + Math.min(8, len * 6) + st.fireBloom);
          if (Math.floor(elapsed * 18) !== Math.floor((elapsed - dt) * 18)) {
            setAimTargetEnemy(hoveringEnemy);
            setCrosshairSpreadPx(targetSpread);
          }
        }

        // 7. Firing
        if (st.firing) {
          handlePlayerFire(performance.now());
        }

        // 8. AI Bots Update
        let aliveEnemiesCount = 0;
        let aliveAlliesCount = st.hp > 0 ? 1 : 0;

        st.bots.forEach((bot) => {
          if (!bot.alive) return;
          if (bot.team === 'enemy') aliveEnemiesCount++;
          else aliveAlliesCount++;

          // Find nearest opponent
          let targetPos: THREE.Vector3 | null = null;
          let targetIsPlayer = false;
          let bestDist = 999;

          if (bot.team === 'enemy' && st.hp > 0) {
            bestDist = bot.group.position.distanceTo(st.playerPos);
            targetPos = st.playerPos;
            targetIsPlayer = true;
          }
          for (const other of st.bots) {
            if (!other.alive || other.team === bot.team) continue;
            const d = bot.group.position.distanceTo(other.group.position);
            if (d < bestDist) {
              bestDist = d;
              targetPos = other.group.position;
              targetIsPlayer = false;
            }
          }

          if (targetPos) {
            _v2.subVectors(targetPos, bot.group.position);
            const flatDist = Math.hypot(_v2.x, _v2.z);
            const lookYaw = Math.atan2(_v2.x, _v2.z);
            bot.group.rotation.y = lookYaw;

            bot.strafeTimer -= dt;
            if (bot.strafeTimer <= 0) {
              bot.strafeTimer = 1.2 + Math.random() * 1.4;
              bot.strafeAngle = (Math.random() - 0.5) * Math.PI;
            }

            const moveSpeed = flatDist > 16 ? 4.4 : flatDist < 8 ? -1.5 : 2.2;
            const moveDir = lookYaw + (flatDist <= 16 ? Math.PI * 0.45 * Math.sign(bot.strafeAngle) : 0);
            const bBound = isIsland ? 88 : 35;
            const bx = THREE.MathUtils.clamp(bot.group.position.x + Math.sin(moveDir) * moveSpeed * dt, -bBound, bBound);
            const bz = THREE.MathUtils.clamp(bot.group.position.z + Math.cos(moveDir) * moveSpeed * dt, -bBound, bBound);
            const by = groundHeightAt(bx, bz, isIsland);
            bot.group.position.set(bx, by, bz);
            updateCharacterAnimation(bot.refs, elapsed + 1.3, Math.abs(moveSpeed) / 5, 'stand');

            bot.fireCooldown -= dt;
            if (bot.fireCooldown <= 0 && flatDist < 48) {
              bot.fireCooldown = 0.65 + Math.random() * 0.85;
              bot.lastFiredAt = elapsed;
              const botOrigin = bot.group.position.clone().add(new THREE.Vector3(0, 1.35, 0));
              const aimPoint = targetPos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 1.2, 1.15, (Math.random() - 0.5) * 1.2));
              const dirToTarget = _v1.subVectors(aimPoint, botOrigin).normalize();

              // Check if blocked by a Gloo Wall
              raycaster.set(botOrigin, dirToTarget);
              raycaster.far = flatDist;
              const gwHits = raycaster.intersectObjects(st.glooWalls.map((g) => g.mesh), false);
              if (gwHits.length > 0) {
                spawnTracer(botOrigin, gwHits[0].point, '#ef4444');
                const gw = st.glooWalls.find((g) => g.mesh === gwHits[0].object);
                if (gw) {
                  gw.hp -= 24;
                  if (gw.hp <= 0) {
                    scene.remove(gw.mesh);
                    st.glooWalls = st.glooWalls.filter((g) => g !== gw);
                  }
                }
              } else {
                spawnTracer(botOrigin, aimPoint, bot.team === 'enemy' ? '#ef4444' : '#38bdf8');
                if (Math.random() < (flatDist < 18 ? 0.42 : 0.24)) {
                  const dmg = 11 + Math.floor(Math.random() * 8);
                  bot.damage += dmg;
                  if (targetIsPlayer) {
                    st.hp = Math.max(0, st.hp - dmg);
                    setHp(Math.ceil(st.hp));
                    setDamageFlash(true);
                    setTimeout(() => setDamageFlash(false), 140);
                  } else {
                    const hitBot = st.bots.find((o) => o.group.position === targetPos && o.alive);
                    if (hitBot) {
                      hitBot.hp -= dmg;
                      if (hitBot.hp <= 0) {
                        hitBot.alive = false;
                        hitBot.group.visible = false;
                        bot.kills += 1;
                      }
                    }
                  }
                }
              }
            }
          }
        });

        setAliveEnemies(aliveEnemiesCount);
        if (Math.floor(elapsed * 5) !== Math.floor((elapsed - dt) * 5)) {
          setPlayerRadarPose({ x: st.playerPos.x, z: st.playerPos.z, yaw: st.yaw });
          setRadarBlips(
            st.bots
              .filter((b) => b.alive)
              .map((b) => ({
                id: b.id,
                x: b.group.position.x,
                z: b.group.position.z,
                team: b.team,
                firing: elapsed - b.lastFiredAt < 1.1,
                hp: Math.max(0, Math.round(b.hp)),
                maxHp: b.maxHp,
                name: b.name,
                knocked: b.hp <= 55,
              }))
          );
        }

        // 9. Check Round / Match End
        if (st.roundCooldown > 0) {
          st.roundCooldown -= dt;
        } else if (aliveEnemiesCount === 0 || st.hp <= 0 || aliveAlliesCount === 0) {
          const wonRound = aliveEnemiesCount === 0 && st.hp > 0;
          if (modeDef.roundBased) {
            const targetWins = modeId === 'cs_rank' ? 3 : 2;
            const nextAlly = st.allyRounds + (wonRound ? 1 : 0);
            const nextEnemy = st.enemyRounds + (wonRound ? 0 : 1);
            st.allyRounds = nextAlly;
            st.enemyRounds = nextEnemy;
            setAllyRounds(nextAlly);
            setEnemyRounds(nextEnemy);

            if (nextAlly >= targetWins || nextEnemy >= targetWins) {
              finishMatch(nextAlly >= targetWins);
            } else {
              st.roundNumber += 1;
              setRoundNumber(st.roundNumber);
              setCsCash((c) => c + (wonRound ? 1400 : 1000));
              st.roundCooldown = 0.6;
              resetRound();
            }
          } else {
            finishMatch(wonRound);
          }
        }
      }

      // 10. Update Tracer Beams
      for (let i = st.tracers.length - 1; i >= 0; i--) {
        const t = st.tracers[i];
        t.life -= dt;
        if (t.life <= 0) {
          scene.remove(t.mesh);
          t.mesh.geometry.dispose();
          (t.mesh.material as THREE.Material).dispose();
          st.tracers.splice(i, 1);
        }
      }

      // 11. Smooth Over-The-Shoulder Third-Person Camera + Scope FOV
      const effectiveYaw = st.yaw + (st.isFreeLooking ? st.freeLookYawOffset : 0);
      const isVeh = st.drivingIdx >= 0;
      const targetFov =
        st.scope === 'sniper' ? 22 : st.scope === '4x' ? 32 : st.scope === '2x' ? 42 : st.scope === 'redDot' ? 52 : isVeh ? 70 : 62;
      if (Math.abs(camera.fov - targetFov) > 0.2) {
        camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 12, dt);
        camera.updateProjectionMatrix();
      }

      const camDist = isVeh ? 7.2 : st.scope !== 'none' ? 1.65 : 3.9;
      const shoulderOffset = isVeh ? 0 : st.scope !== 'none' ? 0.55 : 0.68;
      const camHeight = isVeh ? 2.8 : st.posture === 'prone' ? 0.78 : st.posture === 'crouch' ? 1.22 : 1.68;

      const sinCam = Math.sin(effectiveYaw);
      const cosCam = Math.cos(effectiveYaw);

      const desiredCamX = st.playerPos.x + sinCam * camDist + cosCam * shoulderOffset;
      const desiredCamZ = st.playerPos.z + cosCam * camDist - sinCam * shoulderOffset;
      const desiredCamY = st.playerPos.y + camHeight + Math.sin(st.pitch) * camDist * 0.65;

      camera.position.x = THREE.MathUtils.damp(camera.position.x, desiredCamX, 16, dt);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, desiredCamY, 16, dt);
      camera.position.z = THREE.MathUtils.damp(camera.position.z, desiredCamZ, 16, dt);

      const lookAheadDist = 14;
      const lookX = st.playerPos.x - sinCam * lookAheadDist + cosCam * shoulderOffset * 0.4;
      const lookZ = st.playerPos.z - cosCam * lookAheadDist - sinCam * shoulderOffset * 0.4;
      const lookY = st.playerPos.y + camHeight - Math.sin(st.pitch) * lookAheadDist * 0.7;
      camera.lookAt(lookX, lookY, lookZ);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      canvasEl.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      canvasEl.removeEventListener('contextmenu', onContextMenu);
      canvasEl.removeEventListener('touchstart', onTouchStart);
      canvasEl.removeEventListener('touchmove', onTouchMove);
      canvasEl.removeEventListener('touchend', onTouchEnd);
      canvasEl.removeEventListener('touchcancel', onTouchEnd);
      if (activeEmoteFx) {
        playerChar.group.remove(activeEmoteFx.group);
        activeEmoteFx.dispose();
        activeEmoteFx = null;
      }
      envTex.dispose();
      renderer.dispose();
      if (canvasEl.parentNode === container) container.removeChild(canvasEl);
    };
  }, []);

  const getBtnStyle = (id: HudButtonId): React.CSSProperties => {
    const cfg = hudLayout.find((h) => h.id === id);
    if (!cfg) return {};
    return {
      left: `${cfg.xPct}%`,
      top: `${cfg.yPct}%`,
      transform: `translate(-50%, -50%) scale(${cfg.scale})`,
      opacity: cfg.opacity,
    };
  };

  // Multi-touch safe Virtual Joystick + Upward Auto-Sprint Lock
  const handleJoystickStart = (e: React.PointerEvent) => {
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    const rect = e.currentTarget.getBoundingClientRect();
    joyActiveRef.current = {
      pointerId: e.pointerId,
      ox: rect.left + rect.width / 2,
      oy: rect.top + rect.height / 2,
    };
  };

  const handleJoystickMove = (e: React.PointerEvent) => {
    if (joyActiveRef.current.pointerId !== e.pointerId) return;
    e.stopPropagation();
    const dx = e.clientX - joyActiveRef.current.ox;
    const dy = e.clientY - joyActiveRef.current.oy;
    const maxR = 44;
    const dist = Math.hypot(dx, dy);
    const clampedDist = Math.min(dist, maxR);
    const angle = Math.atan2(dy, dx);
    const nx = Math.cos(angle) * (clampedDist / maxR);
    const ny = Math.sin(angle) * (clampedDist / maxR);
    setJoyKnob({ x: Math.cos(angle) * clampedDist, y: Math.sin(angle) * clampedDist });
    simRef.current.joyVec = { x: nx, y: ny };

    // Upward drag past threshold triggers Auto-Sprint lock
    if (dy < -54 && !simRef.current.autoSprint) {
      simRef.current.autoSprint = true;
      simRef.current.sprinting = true;
      setAutoSprintLock(true);
      setSprinting(true);
    } else if (dy > 16 && simRef.current.autoSprint) {
      simRef.current.autoSprint = false;
      setAutoSprintLock(false);
    }
  };

  const handleJoystickEnd = (e: React.PointerEvent) => {
    if (joyActiveRef.current.pointerId !== e.pointerId) return;
    e.stopPropagation();
    joyActiveRef.current.pointerId = null;
    setJoyKnob({ x: 0, y: 0 });
    simRef.current.joyVec = { x: 0, y: 0 };
  };

  const selectWeaponSlot = (slot: 0 | 1 | 2 | 3) => {
    if (slot !== simRef.current.activeSlot) {
      simRef.current.previousSlot = simRef.current.activeSlot;
    }
    simRef.current.activeSlot = slot;
    setActiveSlot(slot);
    setAmmo(simRef.current.ammo[slot]);
    setReserveAmmo(simRef.current.reserve[slot]);
    simRef.current.scope = 'none';
    setScopeLevel('none');
    audioEngine.playUiClick();
  };

  const quickSwapWeapon = () => {
    const target = simRef.current.previousSlot;
    selectWeaponSlot(target);
  };

  const cycleScope = () => {
    const { weapon } = getActiveWeaponAndSkin();
    const order: Array<'none' | 'redDot' | '2x' | '4x' | 'sniper'> = ['none', 'redDot', '2x', '4x', 'sniper'];
    const maxIdx = order.indexOf(weapon.maxScope);
    const curIdx = order.indexOf(simRef.current.scope);
    const next = curIdx >= maxIdx ? 'none' : order[curIdx + 1];
    simRef.current.scope = next;
    setScopeLevel(next);
    audioEngine.playUiClick();
  };

  const activeWeapon = getActiveWeaponAndSkin().weapon;
  const slotWeapons = ([0, 1, 2, 3] as const).map((s) => {
    const id = getWeaponIdForSlot(s);
    return WEAPONS.find((w) => w.id === id) ?? WEAPONS[0];
  });
  const allyBlips = radarBlips.filter((b) => b.team === 'ally');
  const worldScale = isIsland ? 0.28 : 0.65;

  return (
    <div className="relative w-full h-full overflow-hidden bg-slate-950 select-none touch-none">
      {/* 3D Playable Canvas */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full touch-none" />

      {/* Damage Vignette */}
      {damageFlash && (
        <div className="pointer-events-none absolute inset-0 border-8 border-red-500/70 bg-red-600/15 transition-opacity" />
      )}

      {/* Active Skill Aura Overlay */}
      {skillActiveSec > 0 && (
        <div className="pointer-events-none absolute inset-0 border-4 border-cyan-400/50" />
      )}

      {/* Sniper / Scope Overlay */}
      {scopeLevel !== 'none' && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div
            className={`relative flex items-center justify-center ${
              scopeLevel === 'sniper'
                ? 'w-80 h-80 rounded-full border-4 border-slate-950 shadow-[0_0_0_9999px_rgba(4,7,12,0.82)]'
                : 'w-44 h-44 rounded-full border border-amber-400/50'
            }`}
          >
            <div className="absolute w-full h-[1px] bg-red-500/75" />
            <div className="absolute h-full w-[1px] bg-red-500/75" />
            <div className="w-2 h-2 rounded-full bg-red-500" />
          </div>
        </div>
      )}

      {/* Dynamic Center Crosshair (expands on move/fire, shrinks on crouch/scope, turns RED on enemy hitbox) */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center z-10">
        <div className="relative flex items-center justify-center">
          <div
            className={`w-1.5 h-1.5 rounded-full transition-transform duration-75 ${
              hitIndicator === 'head'
                ? 'bg-red-500 scale-150'
                : aimTargetEnemy
                ? 'bg-red-500 scale-125'
                : hitIndicator === 'body'
                ? 'bg-amber-400 scale-125'
                : 'bg-white/95'
            }`}
          />
          <div
            className={`absolute w-[1.5px] h-2 transition-all duration-75 ${aimTargetEnemy ? 'bg-red-500' : 'bg-white/90'}`}
            style={{ transform: `translateY(-${crosshairSpreadPx}px)` }}
          />
          <div
            className={`absolute w-[1.5px] h-2 transition-all duration-75 ${aimTargetEnemy ? 'bg-red-500' : 'bg-white/90'}`}
            style={{ transform: `translateY(${crosshairSpreadPx}px)` }}
          />
          <div
            className={`absolute h-[1.5px] w-2 transition-all duration-75 ${aimTargetEnemy ? 'bg-red-500' : 'bg-white/90'}`}
            style={{ transform: `translateX(-${crosshairSpreadPx}px)` }}
          />
          <div
            className={`absolute h-[1.5px] w-2 transition-all duration-75 ${aimTargetEnemy ? 'bg-red-500' : 'bg-white/90'}`}
            style={{ transform: `translateX(${crosshairSpreadPx}px)` }}
          />
        </div>
      </div>

      {/* TOP-LEFT ZONE: Mini-Map Radar, Zone Timer & Compact Team Health Bars */}
      <div className="absolute top-3 left-3 z-20 flex flex-col gap-2 pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-2.5 bg-slate-950/80 border border-white/15 rounded-xl p-2">
          <div className="w-20 h-20 rounded-lg border border-sky-400/60 bg-slate-900 relative overflow-hidden flex items-center justify-center">
            {/* Safe Zone Circle */}
            <div
              className="absolute rounded-full border border-sky-400/75"
              style={{
                width: `${Math.min(76, zoneRadius * worldScale * 2)}px`,
                height: `${Math.min(76, zoneRadius * worldScale * 2)}px`,
              }}
            />
            {/* Bot Radar Blips (Allies Green, Firing Enemies Red) */}
            {radarBlips.map((b) => {
              const rx = (b.x - playerRadarPose.x) * worldScale;
              const rz = (b.z - playerRadarPose.z) * worldScale;
              if (Math.abs(rx) > 36 || Math.abs(rz) > 36) return null;
              if (b.team === 'enemy' && !b.firing) return null;
              return (
                <div
                  key={b.id}
                  className={`absolute w-2 h-2 rounded-full ${b.team === 'enemy' ? 'bg-red-500' : 'bg-emerald-400'}`}
                  style={{ transform: `translate(${rx}px, ${rz}px)` }}
                />
              );
            })}
            {/* Player Orientation Chevron */}
            <div
              className="w-0 h-0 border-l-[5px] border-r-[5px] border-b-[10px] border-l-transparent border-r-transparent border-b-amber-400"
              style={{ transform: `rotate(${(-playerRadarPose.yaw * 180) / Math.PI}deg)` }}
            />
            <span className="absolute bottom-0.5 right-1 text-[9px] font-mono-num text-sky-300">
              {zoneTimerSec}s
            </span>
          </div>

          <div className="text-[11px] pr-1">
            <div className="font-display font-bold text-white">{modeDef.mapName}</div>
            <div className="text-slate-400">{modeDef.name} · {format}</div>
            <div className="text-sky-300 font-mono-num mt-0.5">Zone {zoneRadius}m</div>
            {outsideZone && <div className="text-red-400 font-bold">OUTSIDE ZONE</div>}
          </div>
        </div>

        {/* Squad Team Health Bars */}
        <div className="bg-slate-950/75 border border-white/10 rounded-lg px-2.5 py-1.5 space-y-1 w-48">
          <div className="flex items-center justify-between text-[10px]">
            <span className="text-amber-300 font-semibold truncate max-w-[95px]">1. {profile.username}</span>
            <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400" style={{ width: `${(hp / maxHp) * 100}%` }} />
            </div>
          </div>
          {allyBlips.map((ally, idx) => (
            <div key={ally.id} className="flex items-center justify-between text-[10px]">
              <span className={`truncate max-w-[95px] ${ally.knocked ? 'text-red-400 font-bold' : 'text-slate-200'}`}>
                {idx + 2}. {ally.name} {ally.knocked ? '(HELP)' : ''}
              </span>
              <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full ${ally.knocked ? 'bg-red-500' : 'bg-sky-400'}`}
                  style={{ width: `${(ally.hp / ally.maxHp) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* TOP-CENTER SCOREBOARD + PING ALERT */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1.5 pointer-events-none">
        <div className="flex items-center gap-4 bg-slate-950/85 border border-white/10 rounded-lg px-4 py-1.5 font-mono-num text-xs">
          {modeDef.roundBased && (
            <>
              <div className="text-sky-400 font-bold">ALLY {allyRounds}</div>
              <div className="text-slate-400">RD {roundNumber}</div>
              <div className="text-red-400 font-bold">OPP {enemyRounds}</div>
              <div className="h-4 w-px bg-white/15" />
            </>
          )}
          <div>
            <span className="text-slate-400 mr-1">ALIVE</span>
            <span className="text-white font-bold">{aliveEnemies + 1}</span>
          </div>
          <div>
            <span className="text-slate-400 mr-1">KILLS</span>
            <span className="text-amber-400 font-bold">{kills}</span>
          </div>
        </div>

        {pingAlert && (
          <div className="px-3 py-1 rounded bg-amber-500/90 text-slate-950 font-display font-bold text-xs shadow">
            {pingAlert}
          </div>
        )}
      </div>

      {/* TOP-RIGHT LEAVE + KILL FEED */}
      <div className="absolute top-3 right-3 z-20 flex flex-col items-end gap-1.5 pointer-events-auto">
        <button
          onClick={onExitEarly}
          className="px-3 py-1.5 bg-slate-950/85 hover:bg-red-900/80 border border-white/15 rounded-md text-xs font-medium text-slate-200 cursor-pointer"
        >
          Leave Match
        </button>
        <div className="flex flex-col items-end gap-1 pointer-events-none">
          {killFeed.map((kf) => (
            <div
              key={kf.id}
              className="bg-slate-950/80 border border-white/10 rounded px-2.5 py-1 text-[11px] flex items-center gap-1.5"
            >
              <span className="text-amber-400 font-semibold">{kf.killer}</span>
              <span className="text-slate-400">[{kf.weapon}{kf.isHeadshot ? ' HS' : ''}]</span>
              <span className="text-red-400 font-semibold">{kf.victim}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom-Center Health, EP, Armor & Ammo Strip */}
      <div className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1.5 w-[260px] sm:w-[320px]">
        {drivingVehicle && (
          <div className="bg-slate-950/85 border border-amber-400/40 rounded px-3 py-1 text-xs font-mono-num text-amber-300 flex items-center gap-3">
            <span>{drivingVehicle.name}</span>
            <span>·</span>
            <span>{vehicleSpeedKmh} KM/H</span>
          </div>
        )}
        <div className="w-full bg-slate-950/85 border border-white/10 rounded-lg px-3.5 py-2">
          <div className="flex items-center justify-between text-[11px] font-mono-num mb-1">
            <span className="text-amber-400">EP {ep}/100</span>
            <span className="text-white font-bold">HP {hp}/{maxHp}</span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mb-1">
            <div className="h-full bg-amber-400" style={{ width: `${ep}%` }} />
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all ${hp > 70 ? 'bg-emerald-400' : 'bg-red-500'}`}
              style={{ width: `${(hp / maxHp) * 100}%` }}
            />
          </div>
          <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-300 font-mono-num">
            <span>{activeWeapon.name}</span>
            <span>{reloading ? 'RELOADING...' : activeWeapon.weaponClass === 'Melee' ? 'MELEE' : `${ammo} / ${reserveAmmo}`}</span>
          </div>
        </div>
      </div>

      {/* =================================================================== */}
      {/* COMPLETE CUSTOMIZABLE FREE FIRE MULTI-TOUCH HUD CONTROLS            */}
      {/* =================================================================== */}

      {/* 1. Virtual Joystick (Bottom-Left) + Auto-Sprint Lock Above */}
      <div
        style={getBtnStyle('joystick')}
        onPointerDown={handleJoystickStart}
        onPointerMove={handleJoystickMove}
        onPointerUp={handleJoystickEnd}
        onPointerCancel={handleJoystickEnd}
        className="absolute z-20 w-28 h-28 rounded-full bg-slate-900/40 border-2 border-white/25 flex items-center justify-center touch-none cursor-move"
      >
        {autoSprintLock && (
          <div className="absolute -top-7 px-2 py-0.5 rounded bg-amber-500 text-slate-950 text-[9px] font-bold pointer-events-none">
            AUTO SPRINT
          </div>
        )}
        <div
          className="w-11 h-11 rounded-full bg-amber-400/90 border-2 border-white shadow-lg pointer-events-none"
          style={{ transform: `translate(${joyKnob.x}px, ${joyKnob.y}px)` }}
        />
      </div>

      {/* 2. Primary Right Fire Button (Drag-Aim / Drag-Headshot Mechanic) */}
      <button
        style={getBtnStyle('fire')}
        onPointerDown={(e) => {
          e.stopPropagation();
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          fireDragRef.current = { pointerId: e.pointerId, x: e.clientX, y: e.clientY };
          simRef.current.firing = true;
        }}
        onPointerMove={(e) => {
          if (fireDragRef.current.pointerId !== e.pointerId) return;
          e.stopPropagation();
          const dx = e.clientX - fireDragRef.current.x;
          const dy = e.clientY - fireDragRef.current.y;
          fireDragRef.current.x = e.clientX;
          fireDragRef.current.y = e.clientY;
          simRef.current.applyLookDeltaFn?.(dx, dy);
        }}
        onPointerUp={(e) => {
          if (fireDragRef.current.pointerId !== e.pointerId) return;
          e.stopPropagation();
          fireDragRef.current.pointerId = null;
          simRef.current.firing = false;
        }}
        onPointerCancel={(e) => {
          if (fireDragRef.current.pointerId !== e.pointerId) return;
          fireDragRef.current.pointerId = null;
          simRef.current.firing = false;
        }}
        className="absolute z-20 w-20 h-20 rounded-full bg-red-600/80 hover:bg-red-500 border-2 border-amber-300 text-white font-display font-bold text-xs tracking-wider shadow-lg active:scale-95 touch-none cursor-crosshair"
      >
        FIRE
      </button>

      {/* 2b. Left Static Fire Button (Fires without dragging camera) */}
      <button
        style={getBtnStyle('leftFire')}
        onPointerDown={(e) => {
          e.stopPropagation();
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          simRef.current.firing = true;
        }}
        onPointerUp={(e) => {
          e.stopPropagation();
          simRef.current.firing = false;
        }}
        onPointerCancel={() => {
          simRef.current.firing = false;
        }}
        className="absolute z-20 w-14 h-14 rounded-full bg-red-600/75 hover:bg-red-500 border-2 border-white/60 text-white font-display font-bold text-[10px] shadow-lg active:scale-95 touch-none cursor-pointer"
      >
        L-FIRE
      </button>

      {/* 3. Scope / ADS Button */}
      <button
        style={getBtnStyle('scope')}
        onPointerDown={(e) => {
          e.stopPropagation();
          cycleScope();
        }}
        className={`absolute z-20 w-14 h-14 rounded-full border-2 text-xs font-bold touch-none cursor-pointer ${
          scopeLevel !== 'none'
            ? 'bg-amber-500 text-slate-950 border-white'
            : 'bg-slate-900/75 text-white border-white/25'
        }`}
      >
        {scopeLevel === 'none' ? 'SCOPE' : scopeLevel.toUpperCase()}
      </button>

      {/* 4. Jump */}
      <button
        style={getBtnStyle('jump')}
        onPointerDown={(e) => {
          e.stopPropagation();
          simRef.current.jumpRequested = true;
        }}
        className="absolute z-20 w-13 h-13 rounded-full bg-slate-900/75 border border-white/25 text-white text-[11px] font-semibold touch-none cursor-pointer active:scale-95"
      >
        JUMP
      </button>

      {/* 5. Crouch */}
      <button
        style={getBtnStyle('crouch')}
        onPointerDown={(e) => {
          e.stopPropagation();
          const next = simRef.current.posture === 'crouch' ? 'stand' : 'crouch';
          simRef.current.posture = next;
          setPosture(next);
        }}
        className={`absolute z-20 w-13 h-13 rounded-full border text-[11px] font-semibold touch-none cursor-pointer ${
          posture === 'crouch'
            ? 'bg-amber-500 text-slate-950 border-white'
            : 'bg-slate-900/75 text-white border-white/25'
        }`}
      >
        CROUCH
      </button>

      {/* 6. Prone */}
      <button
        style={getBtnStyle('prone')}
        onPointerDown={(e) => {
          e.stopPropagation();
          const next = simRef.current.posture === 'prone' ? 'stand' : 'prone';
          simRef.current.posture = next;
          setPosture(next);
        }}
        className={`absolute z-20 w-12 h-12 rounded-full border text-[11px] font-semibold touch-none cursor-pointer ${
          posture === 'prone'
            ? 'bg-amber-500 text-slate-950 border-white'
            : 'bg-slate-900/75 text-white border-white/25'
        }`}
      >
        PRONE
      </button>

      {/* 7. Gloo Wall / Grenade Slot (Bottom-Left Zone) */}
      <button
        style={getBtnStyle('glooWall')}
        onPointerDown={(e) => {
          e.stopPropagation();
          simRef.current.deployGlooRequested = true;
        }}
        className="absolute z-20 w-14 h-14 rounded-full bg-sky-600/80 hover:bg-sky-500 border-2 border-sky-200 text-white text-[10px] font-bold touch-none cursor-pointer active:scale-95"
      >
        GLOO ({glooCount})
      </button>

      {/* 8. Sprint Lock Button */}
      <button
        style={getBtnStyle('sprint')}
        onPointerDown={(e) => {
          e.stopPropagation();
          const next = !(simRef.current.sprinting || simRef.current.autoSprint);
          simRef.current.sprinting = next;
          simRef.current.autoSprint = next;
          setSprinting(next);
          setAutoSprintLock(next);
        }}
        className={`absolute z-20 w-11 h-11 rounded-full border text-[10px] font-semibold touch-none cursor-pointer ${
          sprinting || autoSprintLock
            ? 'bg-amber-500 text-slate-950 border-white'
            : 'bg-slate-900/75 text-white border-white/25'
        }`}
      >
        RUN
      </button>

      {/* 9. Top-Right Weapon Switch Box (Primary 1, Primary 2, Pistol, Melee + tap-to-swap) */}
      <div style={getBtnStyle('weaponSwitch')} className="absolute z-20 flex flex-col items-end gap-1">
        <div
          onPointerDown={(e) => {
            e.stopPropagation();
            setWeaponBoxOpen((o) => !o);
          }}
          className="px-3 py-1.5 rounded-lg bg-slate-900/85 border border-amber-400/50 text-white cursor-pointer flex items-center gap-3 shadow-lg"
        >
          <div className="text-right">
            <div className="text-[10px] text-amber-400 font-bold">
              {activeSlot === 0 ? 'PRIMARY 1' : activeSlot === 1 ? 'PRIMARY 2' : activeSlot === 2 ? 'SIDEARM' : 'MELEE'}
            </div>
            <div className="font-display font-bold text-xs leading-tight">{activeWeapon.name}</div>
          </div>
          <div className="text-xs font-mono-num font-bold text-slate-200 border-l border-white/15 pl-2">
            {activeSlot === 3 ? '∞' : ammo}
          </div>
        </div>
        {weaponBoxOpen && (
          <div className="w-52 bg-slate-950/95 border border-white/15 rounded-xl p-1.5 space-y-1 shadow-xl">
            {slotWeapons.map((w, idx) => (
              <button
                key={`${w.id}_${idx}`}
                onClick={() => {
                  selectWeaponSlot(idx as 0 | 1 | 2 | 3);
                  setWeaponBoxOpen(false);
                }}
                className={`w-full px-2.5 py-1.5 rounded-lg text-left flex items-center justify-between text-xs cursor-pointer ${
                  activeSlot === idx ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-200 hover:bg-slate-800'
                }`}
              >
                <span>
                  {idx === 0 ? '1.' : idx === 1 ? '2.' : idx === 2 ? '3.' : '4.'} {w.name}
                </span>
                <span className="font-mono-num">{idx === 3 ? 'MELEE' : slotAmmoView[idx]}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 9b. Quick Weapon Switch Button (Single-tap toggle between last 2 weapons, e.g. double-sniper) */}
      <button
        style={getBtnStyle('quickSwitch')}
        onPointerDown={(e) => {
          e.stopPropagation();
          quickSwapWeapon();
        }}
        className="absolute z-20 w-12 h-12 rounded-full bg-slate-900/80 border border-amber-400/60 text-amber-300 flex flex-col items-center justify-center text-[9px] font-bold touch-none cursor-pointer active:scale-95"
      >
        <Repeat className="w-4 h-4" />
        <span>SWAP</span>
      </button>

      {/* 10. Reload */}
      <button
        style={getBtnStyle('reload')}
        onPointerDown={(e) => {
          e.stopPropagation();
          simRef.current.reloadRequested = true;
        }}
        className="absolute z-20 w-12 h-12 rounded-full bg-slate-900/75 border border-white/25 text-white text-[10px] font-semibold touch-none cursor-pointer active:scale-95"
      >
        RELOAD
      </button>

      {/* 11. Medkit / Heal Button with Circular Progress Timer */}
      <button
        style={getBtnStyle('medkit')}
        onPointerDown={(e) => {
          e.stopPropagation();
          simRef.current.medkitRequested = true;
        }}
        className="absolute z-20 w-13 h-13 rounded-full bg-emerald-700/80 border border-emerald-300 text-white text-[10px] font-bold touch-none cursor-pointer active:scale-95 flex items-center justify-center"
      >
        {medkitProgress !== null && (
          <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none" viewBox="0 0 36 36">
            <circle
              cx="18"
              cy="18"
              r="16"
              fill="none"
              stroke="#34d399"
              strokeWidth="3"
              strokeDasharray="100"
              strokeDashoffset={100 - medkitProgress * 100}
            />
          </svg>
        )}
        <span>{medkitProgress !== null ? 'HEAL' : `MED (${medkitCount})`}</span>
      </button>

      {/* 11b. Backpack Inventory Button (Bottom-Left Zone) */}
      <button
        style={getBtnStyle('backpack')}
        onPointerDown={(e) => {
          e.stopPropagation();
          setBackpackOpen((o) => !o);
        }}
        className="absolute z-20 w-12 h-12 rounded-full bg-slate-900/80 border border-white/25 text-slate-200 flex flex-col items-center justify-center text-[9px] font-bold touch-none cursor-pointer"
      >
        <Backpack className="w-4 h-4 text-amber-400" />
        <span>BAG</span>
      </button>

      {/* 12. Active Character Skill Button with Cooldown Sweep */}
      <button
        style={getBtnStyle('activeSkill')}
        onPointerDown={(e) => {
          e.stopPropagation();
          simRef.current.skillRequested = true;
        }}
        className={`absolute z-20 w-13 h-13 rounded-full border-2 flex flex-col items-center justify-center text-[9px] font-bold touch-none cursor-pointer ${
          skillActiveSec > 0
            ? 'bg-cyan-500 text-slate-950 border-white'
            : skillCooldownSec > 0
            ? 'bg-slate-900/85 text-slate-400 border-slate-600'
            : 'bg-cyan-600/85 text-white border-cyan-300'
        }`}
      >
        <Zap className="w-4 h-4" />
        <span>{skillActiveSec > 0 ? `${skillActiveSec}s` : skillCooldownSec > 0 ? `${skillCooldownSec}s` : 'SKILL'}</span>
      </button>

      {/* 13. Free-Look Eye Icon (360° camera orbit while running straight) */}
      <button
        style={getBtnStyle('freeLook')}
        onPointerDown={(e) => {
          e.stopPropagation();
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          freeLookDragRef.current = { pointerId: e.pointerId, x: e.clientX, y: e.clientY };
          simRef.current.isFreeLooking = true;
        }}
        onPointerMove={(e) => {
          if (freeLookDragRef.current.pointerId !== e.pointerId) return;
          e.stopPropagation();
          const dx = e.clientX - freeLookDragRef.current.x;
          const dy = e.clientY - freeLookDragRef.current.y;
          freeLookDragRef.current.x = e.clientX;
          freeLookDragRef.current.y = e.clientY;
          simRef.current.applyLookDeltaFn?.(dx, dy, true);
        }}
        onPointerUp={(e) => {
          if (freeLookDragRef.current.pointerId !== e.pointerId) return;
          e.stopPropagation();
          freeLookDragRef.current.pointerId = null;
          simRef.current.isFreeLooking = false;
          simRef.current.freeLookYawOffset = 0;
        }}
        onPointerCancel={() => {
          freeLookDragRef.current.pointerId = null;
          simRef.current.isFreeLooking = false;
          simRef.current.freeLookYawOffset = 0;
        }}
        className="absolute z-20 w-11 h-11 rounded-full bg-slate-900/80 border border-white/30 text-white flex items-center justify-center touch-none cursor-grab"
        title="Hold & Drag for 360° Free Look"
      >
        <Eye className="w-4 h-4 text-sky-300" />
      </button>

      {/* 14. Ping / Quick Chat, Emotes & Mic/Speaker Toggles */}
      <div style={getBtnStyle('ping')} className="absolute z-20 flex items-center gap-1.5">
        <div className="relative">
          <button
            onClick={() => {
              setEmoteWheelOpen((v) => !v);
              audioEngine.playUiClick();
            }}
            className={`px-2 py-1.5 rounded-lg border text-[10px] font-bold flex items-center gap-1 cursor-pointer ${
              emoteWheelOpen
                ? 'bg-amber-500 text-slate-950 border-amber-300'
                : 'bg-slate-900/85 border-white/20 text-amber-300'
            }`}
            title="Play Equipped Emote"
          >
            <Smile className="w-3.5 h-3.5" />
            <span>EMOTE</span>
          </button>

          {emoteWheelOpen && (
            <div className="absolute top-full right-0 mt-1.5 w-52 p-2 rounded-xl bg-slate-950/95 border border-amber-400/35 shadow-2xl z-30">
              <div className="text-[9px] font-bold uppercase tracking-wider text-amber-300 mb-1.5 px-1">
                Equipped Emotes
              </div>
              <div className="grid grid-cols-2 gap-1 max-h-40 overflow-y-auto">
                {(profile.equippedEmoteIds.length > 0 ? profile.equippedEmoteIds : ['emote_hello_wave']).map((eId) => {
                  const em = EMOTES.find((item) => item.id === eId);
                  if (!em) return null;
                  return (
                    <button
                      key={em.id}
                      onClick={() => {
                        simRef.current.requestedEmoteId = em.id;
                        simRef.current.posture = 'stand';
                        setPosture('stand');
                        setEmoteWheelOpen(false);
                        audioEngine.playUiClick();
                      }}
                      className="px-2 py-1.5 rounded-md bg-slate-900 hover:bg-amber-500/20 border border-white/10 text-left text-[10px] font-semibold text-white truncate cursor-pointer"
                    >
                      {em.name}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
        <button
          onClick={() => {
            setPingAlert(`${profile.username}: Enemy Spotted!`);
            audioEngine.playUiClick();
            setTimeout(() => setPingAlert(null), 2200);
          }}
          className="px-2.5 py-1.5 rounded-lg bg-slate-900/85 border border-white/20 text-amber-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
        >
          <Radio className="w-3.5 h-3.5" />
          <span>PING</span>
        </button>
        <button
          onClick={() => setMicOn((m) => !m)}
          className="p-1.5 rounded-lg bg-slate-900/85 border border-white/20 text-slate-200 cursor-pointer"
          title="Toggle Mic"
        >
          {micOn ? <Mic className="w-3.5 h-3.5 text-emerald-400" /> : <MicOff className="w-3.5 h-3.5 text-red-400" />}
        </button>
        <button
          onClick={() => {
            audioEngine.muted = !audioEngine.muted;
            setSpeakerOn(!audioEngine.muted);
          }}
          className="p-1.5 rounded-lg bg-slate-900/85 border border-white/20 text-slate-200 cursor-pointer"
          title="Toggle Speaker"
        >
          {speakerOn ? <Volume2 className="w-3.5 h-3.5 text-sky-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
        </button>
      </div>

      {/* 15. Contextual Loot / Drive / Exit Pop-up */}
      {(nearbyVehicleName || drivingVehicle || nearbyLoot) && (
        <div style={getBtnStyle('drive')} className="absolute z-20 flex flex-col items-center gap-1.5">
          {nearbyLoot && (
            <button
              onPointerDown={(e) => {
                e.stopPropagation();
                simRef.current.lootCollectRequested = true;
              }}
              className="px-3.5 py-1.5 rounded-lg bg-emerald-500 text-slate-950 border border-white text-xs font-display font-bold shadow-lg flex items-center gap-1.5 cursor-pointer"
            >
              <Package className="w-3.5 h-3.5" />
              <span>LOOT: {nearbyLoot.label}</span>
            </button>
          )}
          {(nearbyVehicleName || drivingVehicle) && (
            <button
              onPointerDown={(e) => {
                e.stopPropagation();
                simRef.current.driveToggleRequested = true;
              }}
              className="px-3.5 py-1.5 rounded-lg bg-amber-500 text-slate-950 border border-white text-xs font-display font-bold shadow-lg cursor-pointer"
            >
              {drivingVehicle ? 'EXIT VEHICLE' : `DRIVE ${nearbyVehicleName}`}
            </button>
          )}
        </div>
      )}

      {/* 16. Contextual Revive / Help Button */}
      {reviveTarget && (
        <button
          style={getBtnStyle('revive')}
          onPointerDown={(e) => {
            e.stopPropagation();
            simRef.current.reviveRequested = true;
          }}
          className="absolute z-20 px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 border-2 border-white text-xs font-display font-bold shadow-xl flex items-center gap-1.5 cursor-pointer"
        >
          <HeartPulse className="w-4 h-4" />
          <span>REVIVE {reviveTarget.name}</span>
        </button>
      )}

      {/* Backpack Inventory Overlay */}
      {backpackOpen && (
        <div className="absolute inset-0 z-30 bg-slate-950/75 flex items-center justify-center p-4" onClick={() => setBackpackOpen(false)}>
          <div
            className="w-full max-w-md bg-slate-900 border border-white/15 rounded-xl p-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-2.5 mb-3">
              <h3 className="font-display font-bold text-white flex items-center gap-2">
                <Backpack className="w-4 h-4 text-amber-400" /> Tactical Backpack Lv.3
              </h3>
              <button onClick={() => setBackpackOpen(false)} className="text-xs text-slate-400 hover:text-white cursor-pointer">
                Close
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {slotWeapons.map((w, i) => (
                <button
                  key={`${w.id}_bag_${i}`}
                  onClick={() => {
                    selectWeaponSlot(i as 0 | 1 | 2 | 3);
                    setBackpackOpen(false);
                  }}
                  className="p-2.5 rounded-lg bg-slate-950/80 border border-white/10 text-left hover:border-amber-400 cursor-pointer"
                >
                  <div className="text-[10px] text-amber-400 font-semibold">{w.weaponClass}</div>
                  <div className="font-bold text-white">{w.name}</div>
                  <div className="text-[11px] text-slate-400 font-mono-num">
                    {i === 3 ? 'Melee' : `${slotAmmoView[i]} Loaded`}
                  </div>
                </button>
              ))}
              <div className="p-2.5 rounded-lg bg-slate-950/80 border border-emerald-500/30">
                <div className="text-emerald-400 font-bold">Medkits</div>
                <div className="text-white font-mono-num">{medkitCount} Kits (+75 HP)</div>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-950/80 border border-sky-500/30">
                <div className="text-sky-400 font-bold">Gloo Walls</div>
                <div className="text-white font-mono-num">{glooCount} Deployables</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Subtle Desktop Controls Helper */}
      <div className="hidden md:flex pointer-events-none absolute top-14 left-1/2 -translate-x-1/2 text-[11px] text-slate-300/80 gap-3">
        <span>WASD Move</span>
        <span>·</span>
        <span>Right-Drag / Fire-Drag Aim</span>
        <span>·</span>
        <span>Q Quick Swap</span>
        <span>·</span>
        <span>E Loot</span>
        <span>·</span>
        <span>G Gloo Wall</span>
        <span>·</span>
        <span>F Drive Vehicle</span>
      </div>

      {/* Clash Squad Buy Phase Economy Modal */}
      {buyPhaseOpen && (
        <div className="absolute inset-0 z-30 bg-slate-950/80 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-slate-900 border border-white/15 rounded-xl p-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
              <div>
                <h2 className="font-display text-xl font-bold text-white">Clash Squad Armory · Round {roundNumber}</h2>
                <p className="text-xs text-slate-400">Spend round cash to equip your primary firearm</p>
              </div>
              <div className="font-mono-num text-lg font-bold text-amber-400">${csCash}</div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-72 overflow-y-auto tactical-scroll pr-1">
              {WEAPONS.filter((w) => w.csPrice > 0).map((w) => {
                const selected = activePrimaryWeaponId === w.id;
                const price = profile.isAdmin ? 0 : w.csPrice;
                const affordable = csCash >= price;
                return (
                  <button
                    key={w.id}
                    disabled={!affordable && !selected}
                    onClick={() => {
                      if (selected) return;
                      if (csCash >= price) {
                        setCsCash((c) => c - price);
                        setActivePrimaryWeaponId(w.id);
                        simRef.current.activeSlot = 0;
                        setActiveSlot(0);
                        simRef.current.ammo[0] = w.magSize;
                        simRef.current.reserve[0] = w.magSize * 4;
                        setAmmo(w.magSize);
                        setReserveAmmo(w.magSize * 4);
                        setSlotAmmoView([...simRef.current.ammo] as [number, number, number, number]);
                        audioEngine.playUiClick();
                      }
                    }}
                    className={`p-3 rounded-lg border text-left transition-colors cursor-pointer ${
                      selected
                        ? 'bg-amber-500/20 border-amber-400 text-white'
                        : affordable
                        ? 'bg-slate-800/70 border-white/10 hover:border-amber-400/50 text-slate-100'
                        : 'bg-slate-900/40 border-white/5 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    <div className="text-[11px] text-amber-400 font-semibold">{w.weaponClass}</div>
                    <div className="font-display font-bold text-sm mt-0.5">{w.name}</div>
                    <div className="text-xs font-mono-num text-slate-300 mt-1">
                      {profile.isAdmin ? 'FREE (ADMIN)' : `$${w.csPrice}`}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="mt-5 flex justify-end gap-3">
              <button
                onClick={() => {
                  setBuyPhaseOpen(false);
                  audioEngine.playStartChime();
                }}
                className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-sm rounded-lg cursor-pointer"
              >
                Deploy to Round {roundNumber}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
