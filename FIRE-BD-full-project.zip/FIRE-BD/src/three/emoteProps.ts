import * as THREE from 'three';

export interface ActiveEmoteState {
  id: string;
  elapsed: number;
  duration: number;
}

export interface EmoteFxHandle {
  group: THREE.Group;
  emoteId: string;
  update: (t: number, dt: number) => void;
  dispose: () => void;
}

export function createEmoteFx(emoteId: string): EmoteFxHandle {
  const group = new THREE.Group();
  const disposables: Array<{ dispose: () => void }> = [];

  const track = <T extends { dispose: () => void }>(item: T): T => {
    disposables.push(item);
    return item;
  };

  let updater: (t: number, dt: number) => void = () => {};

  if (emoteId === 'emote_ffwc_throne') {
    const goldMat = track(
      new THREE.MeshStandardMaterial({
        color: '#facc15',
        metalness: 0.85,
        roughness: 0.2,
      })
    );
    const velvetMat = track(
      new THREE.MeshStandardMaterial({
        color: '#991b1b',
        roughness: 0.72,
        metalness: 0.08,
      })
    );
    const baseGeo = track(new THREE.BoxGeometry(1.05, 0.14, 0.92));
    const base = new THREE.Mesh(baseGeo, goldMat);
    base.position.set(0, 0.07, -0.14);
    group.add(base);

    const cushionGeo = track(new THREE.BoxGeometry(0.86, 0.34, 0.72));
    const cushion = new THREE.Mesh(cushionGeo, velvetMat);
    cushion.position.set(0, 0.31, -0.14);
    group.add(cushion);

    const backGeo = track(new THREE.BoxGeometry(0.98, 1.38, 0.14));
    const back = new THREE.Mesh(backGeo, goldMat);
    back.position.set(0, 0.88, -0.5);
    group.add(back);

    const backCushionGeo = track(new THREE.BoxGeometry(0.76, 1.1, 0.06));
    const backCushion = new THREE.Mesh(backCushionGeo, velvetMat);
    backCushion.position.set(0, 0.88, -0.41);
    group.add(backCushion);

    const crestGeo = track(new THREE.OctahedronGeometry(0.18, 0));
    const crest = new THREE.Mesh(crestGeo, goldMat);
    crest.position.set(0, 1.72, -0.5);
    group.add(crest);

    const armGeo = track(new THREE.BoxGeometry(0.14, 0.28, 0.76));
    [-0.46, 0.46].forEach((ax) => {
      const arm = new THREE.Mesh(armGeo, goldMat);
      arm.position.set(ax, 0.62, -0.14);
      group.add(arm);
    });

    updater = (t) => {
      const pop = Math.min(1, t / 0.32);
      group.scale.setScalar(0.2 + 0.8 * pop);
      crest.rotation.y = t * 1.8;
    };
  } else if (emoteId === 'emote_pirates_flag') {
    const poleMat = track(new THREE.MeshStandardMaterial({ color: '#d4d4d8', metalness: 0.75, roughness: 0.25 }));
    const clothMat = track(new THREE.MeshStandardMaterial({ color: '#b91c1c', roughness: 0.6, side: THREE.DoubleSide }));
    const trimMat = track(new THREE.MeshStandardMaterial({ color: '#111827', roughness: 0.5 }));
    const goldMat = track(new THREE.MeshStandardMaterial({ color: '#facc15', metalness: 0.85, roughness: 0.2 }));

    const poleGeo = track(new THREE.CylinderGeometry(0.032, 0.038, 2.35, 10));
    const pole = new THREE.Mesh(poleGeo, poleMat);
    pole.position.set(0.45, 1.18, 0.22);
    group.add(pole);

    const tipGeo = track(new THREE.ConeGeometry(0.075, 0.18, 6));
    const tip = new THREE.Mesh(tipGeo, goldMat);
    tip.position.set(0.45, 2.42, 0.22);
    group.add(tip);

    const flagGeo = track(new THREE.PlaneGeometry(0.95, 0.56, 8, 2));
    const flag = new THREE.Mesh(flagGeo, clothMat);
    flag.position.set(0.93, 2.02, 0.22);
    group.add(flag);

    const skullGeo = track(new THREE.BoxGeometry(0.18, 0.18, 0.04));
    const skull = new THREE.Mesh(skullGeo, trimMat);
    skull.position.set(0.93, 2.02, 0.23);
    group.add(skull);

    updater = (t) => {
      const slam = t < 0.45 ? THREE.MathUtils.lerp(1.4, 0, t / 0.45) : 0;
      pole.position.y = 1.18 + slam;
      tip.position.y = 2.42 + slam;
      flag.position.y = 2.02 + slam;
      skull.position.y = 2.02 + slam;
      flag.rotation.y = Math.sin(t * 7.5) * 0.18;
      skull.rotation.y = flag.rotation.y;
    };
  } else if (emoteId === 'emote_flowers_of_love') {
    const stemMat = track(new THREE.MeshStandardMaterial({ color: '#15803d', roughness: 0.6 }));
    const roseMat = track(
      new THREE.MeshStandardMaterial({
        color: '#e11d48',
        emissive: '#fb7185',
        emissiveIntensity: 0.45,
        roughness: 0.35,
      })
    );
    const stemGeo = track(new THREE.CylinderGeometry(0.015, 0.018, 0.42, 8));
    const stem = new THREE.Mesh(stemGeo, stemMat);
    stem.position.set(0.18, 0.92, 0.55);
    stem.rotation.x = 0.85;
    group.add(stem);

    const budGeo = track(new THREE.DodecahedronGeometry(0.085, 0));
    const bud = new THREE.Mesh(budGeo, roseMat);
    bud.position.set(0.18, 1.08, 0.72);
    group.add(bud);

    // Floating heart/petal particles
    const petalGeo = track(new THREE.PlaneGeometry(0.07, 0.07));
    const petals: Array<{ mesh: THREE.Mesh; phase: number; r: number }> = [];
    for (let i = 0; i < 18; i++) {
      const m = new THREE.Mesh(petalGeo, roseMat);
      const phase = (i / 18) * Math.PI * 2;
      const r = 0.35 + (i % 4) * 0.18;
      m.position.set(Math.cos(phase) * r, 0.4 + (i % 5) * 0.25, Math.sin(phase) * r);
      group.add(m);
      petals.push({ mesh: m, phase, r });
    }

    updater = (t) => {
      petals.forEach((p, idx) => {
        const y = ((t * 0.65 + idx * 0.15) % 1.9) + 0.25;
        p.mesh.position.set(
          Math.cos(t * 1.4 + p.phase) * p.r,
          y,
          Math.sin(t * 1.4 + p.phase) * p.r
        );
        p.mesh.rotation.x = t * 2 + p.phase;
        p.mesh.rotation.y = t * 2.5;
      });
    };
  } else if (emoteId === 'emote_tea_time') {
    const goldMat = track(new THREE.MeshStandardMaterial({ color: '#fbbf24', metalness: 0.7, roughness: 0.25 }));
    const teaMat = track(new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.2 }));
    const saucerGeo = track(new THREE.CylinderGeometry(0.13, 0.08, 0.02, 16));
    const saucer = new THREE.Mesh(saucerGeo, goldMat);
    saucer.position.set(0.24, 1.02, 0.42);
    group.add(saucer);

    const cupGeo = track(new THREE.CylinderGeometry(0.07, 0.05, 0.1, 14));
    const cup = new THREE.Mesh(cupGeo, goldMat);
    cup.position.set(0.24, 1.08, 0.42);
    group.add(cup);

    const liquidGeo = track(new THREE.CircleGeometry(0.06, 12));
    liquidGeo.rotateX(-Math.PI / 2);
    const liquid = new THREE.Mesh(liquidGeo, teaMat);
    liquid.position.set(0.24, 1.132, 0.42);
    group.add(liquid);

    updater = (t) => {
      const sip = Math.max(0, Math.sin(t * 2.6)) * 0.28;
      saucer.position.y = 1.02 + sip;
      cup.position.y = 1.08 + sip;
      liquid.position.y = 1.132 + sip;
      saucer.position.z = 0.42 - sip * 0.3;
      cup.position.z = 0.42 - sip * 0.3;
      liquid.position.z = 0.42 - sip * 0.3;
    };
  } else if (emoteId === 'emote_im_rich') {
    const billGeo = track(new THREE.PlaneGeometry(0.16, 0.08));
    const billMat = track(
      new THREE.MeshStandardMaterial({
        color: '#10b981',
        emissive: '#059669',
        emissiveIntensity: 0.25,
        side: THREE.DoubleSide,
      })
    );
    const bills: Array<{ mesh: THREE.Mesh; x: number; z: number; speed: number; phase: number }> = [];
    for (let i = 0; i < 34; i++) {
      const m = new THREE.Mesh(billGeo, billMat);
      const x = (Math.random() - 0.5) * 2.2;
      const z = (Math.random() - 0.5) * 2.2;
      m.position.set(x, 1.4 + Math.random() * 1.4, z);
      group.add(m);
      bills.push({ mesh: m, x, z, speed: 0.9 + Math.random() * 0.7, phase: Math.random() * Math.PI * 2 });
    }
    updater = (t) => {
      bills.forEach((b) => {
        const dropY = 2.6 - ((t * b.speed + b.phase) % 2.45);
        b.mesh.position.set(
          b.x + Math.sin(t * 4 + b.phase) * 0.16,
          dropY,
          b.z + Math.cos(t * 3.2 + b.phase) * 0.16
        );
        b.mesh.rotation.set(t * 3 + b.phase, t * 2.4, Math.sin(t * 5 + b.phase));
      });
    };
  } else if (emoteId === 'emote_booyah_celebration') {
    const sparkGeo = track(new THREE.BoxGeometry(0.06, 0.06, 0.02));
    const colors = ['#facc15', '#ff4500', '#38bdf8', '#22c55e'];
    const mats = colors.map((c) =>
      track(new THREE.MeshBasicMaterial({ color: c, side: THREE.DoubleSide }))
    );
    const confetti: Array<{ mesh: THREE.Mesh; vx: number; vy: number; vz: number }> = [];
    for (let i = 0; i < 32; i++) {
      const m = new THREE.Mesh(sparkGeo, mats[i % mats.length]);
      const angle = (i / 32) * Math.PI * 2;
      const speed = 0.7 + (i % 4) * 0.35;
      m.position.set(0, 1.4, 0);
      group.add(m);
      confetti.push({
        mesh: m,
        vx: Math.cos(angle) * speed,
        vy: 1.6 + (i % 3) * 0.55,
        vz: Math.sin(angle) * speed,
      });
    }
    updater = (t) => {
      confetti.forEach((c, idx) => {
        const cyc = (t + (idx % 3) * 0.12) % 1.8;
        c.mesh.position.set(
          c.vx * cyc,
          Math.max(0.08, 1.3 + c.vy * cyc - 1.6 * cyc * cyc),
          c.vz * cyc
        );
        c.mesh.rotation.set(t * 6, t * 4 + idx, t * 5);
      });
    };
  } else if (emoteId === 'emote_cobra_rising' || emoteId === 'emote_dragon_fist') {
    const ringGeo = track(new THREE.TorusGeometry(0.72, 0.035, 8, 32));
    ringGeo.rotateX(Math.PI / 2);
    const ringMat = track(
      new THREE.MeshBasicMaterial({
        color: emoteId === 'emote_cobra_rising' ? '#ef4444' : '#ff6b00',
        transparent: true,
        opacity: 0.88,
      })
    );
    const rings: THREE.Mesh[] = [];
    for (let i = 0; i < 3; i++) {
      const r = new THREE.Mesh(ringGeo, ringMat);
      r.position.y = 0.25 + i * 0.55;
      group.add(r);
      rings.push(r);
    }
    updater = (t) => {
      rings.forEach((r, idx) => {
        const y = ((t * 1.35 + idx * 0.6) % 1.95) + 0.12;
        r.position.y = y;
        const sc = 0.75 + Math.sin(t * 4 + idx) * 0.2;
        r.scale.setScalar(sc);
        r.rotation.y = t * (idx % 2 === 0 ? 3 : -3);
      });
    };
  } else if (emoteId === 'emote_scorpio_shatter') {
    const shockGeo = track(new THREE.RingGeometry(0.35, 0.52, 24));
    shockGeo.rotateX(-Math.PI / 2);
    const shockMat = track(
      new THREE.MeshBasicMaterial({
        color: '#a855f7',
        transparent: true,
        opacity: 0.85,
        side: THREE.DoubleSide,
      })
    );
    const shock = new THREE.Mesh(shockGeo, shockMat);
    shock.position.y = 0.05;
    group.add(shock);

    const shardGeo = track(new THREE.ConeGeometry(0.08, 0.34, 4));
    const shards: Array<{ mesh: THREE.Mesh; angle: number; dist: number }> = [];
    for (let i = 0; i < 8; i++) {
      const s = new THREE.Mesh(shardGeo, shockMat);
      const angle = (i / 8) * Math.PI * 2;
      s.position.set(Math.cos(angle) * 0.85, 0.15, Math.sin(angle) * 0.85);
      s.rotation.z = Math.cos(angle) * -0.45;
      group.add(s);
      shards.push({ mesh: s, angle, dist: 0.9 });
    }

    updater = (t) => {
      const impactT = Math.max(0, t - 0.55);
      const wave = (impactT * 2.1) % 1.4;
      shock.visible = t >= 0.55;
      shock.scale.setScalar(0.4 + wave * 2.4);
      shockMat.opacity = Math.max(0.1, 0.9 - wave * 0.55);
      shards.forEach((s) => {
        s.mesh.visible = t >= 0.55;
        const d = s.dist + wave * 0.65;
        s.mesh.position.set(Math.cos(s.angle) * d, 0.16 + Math.sin(wave * Math.PI) * 0.15, Math.sin(s.angle) * d);
      });
    };
  } else if (emoteId === 'emote_legendary_katana_slash') {
    const bladeMat = track(
      new THREE.MeshStandardMaterial({
        color: '#e2e8f0',
        emissive: '#22d3ee',
        emissiveIntensity: 0.75,
        metalness: 0.9,
        roughness: 0.15,
      })
    );
    const hiltMat = track(new THREE.MeshStandardMaterial({ color: '#111827', roughness: 0.6 }));

    const katanaGroup = new THREE.Group();
    const bladeGeo = track(new THREE.BoxGeometry(0.035, 0.92, 0.015));
    const blade = new THREE.Mesh(bladeGeo, bladeMat);
    blade.position.y = 0.55;
    katanaGroup.add(blade);
    const hiltGeo = track(new THREE.CylinderGeometry(0.022, 0.022, 0.24, 8));
    const hilt = new THREE.Mesh(hiltGeo, hiltMat);
    hilt.position.y = 0.04;
    katanaGroup.add(hilt);
    katanaGroup.position.set(0.32, 1.05, 0.32);
    group.add(katanaGroup);

    const arcGeo = track(new THREE.TorusGeometry(0.98, 0.045, 6, 24, Math.PI * 0.9));
    const arcMat = track(
      new THREE.MeshBasicMaterial({
        color: '#22d3ee',
        transparent: true,
        opacity: 0.85,
      })
    );
    const arc = new THREE.Mesh(arcGeo, arcMat);
    arc.position.set(0, 1.12, 0.15);
    arc.rotation.x = Math.PI / 2 - 0.35;
    group.add(arc);

    updater = (t) => {
      katanaGroup.rotation.z = Math.sin(t * 10) * 1.35;
      katanaGroup.rotation.x = Math.cos(t * 7) * 0.75 + 0.5;
      arc.rotation.z = t * 9;
      arcMat.opacity = 0.45 + Math.abs(Math.sin(t * 8)) * 0.5;
    };
  }

  return {
    group,
    emoteId,
    update: updater,
    dispose: () => {
      disposables.forEach((d) => d.dispose());
    },
  };
}
