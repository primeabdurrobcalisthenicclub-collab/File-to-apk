import * as THREE from 'three';
import { OutfitItem, WeaponDef, WeaponSkin } from '../types/game';
import { createJamdaniWeaveTexture, createLungiPlaidTexture } from './proceduralTextures';
import { buildWeaponMesh } from './weaponVehicleBuilder';

export interface CharacterAnimRefs {
  root: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  clothHem?: THREE.Mesh;
  palluSash?: THREE.Mesh;
  weaponMount: THREE.Group;
}

export function buildCharacterModel(
  outfit: OutfitItem,
  weapon: WeaponDef,
  skin: WeaponSkin,
  showWeapon = true
): { group: THREE.Group; refs: CharacterAnimRefs } {
  const root = new THREE.Group();
  root.name = `character_${outfit.id}`;

  const skinMat = new THREE.MeshStandardMaterial({
    color: outfit.skinTone,
    roughness: 0.62,
    metalness: 0.04,
  });

  const secondaryMat = new THREE.MeshStandardMaterial({
    color: outfit.secondaryColor,
    roughness: 0.55,
    metalness: outfit.clothStyle === 'armor' ? 0.35 : 0.08,
  });

  const accentMat = new THREE.MeshStandardMaterial({
    color: outfit.accentColor,
    roughness: 0.28,
    metalness: 0.72,
  });

  let primaryMat: THREE.MeshStandardMaterial;
  if (outfit.clothStyle === 'lungi') {
    const tex = createLungiPlaidTexture(outfit.primaryColor, outfit.secondaryColor, outfit.accentColor);
    primaryMat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.84, metalness: 0.04 });
  } else if (outfit.clothStyle === 'panjabi' || outfit.clothStyle === 'shari') {
    const tex = createJamdaniWeaveTexture(outfit.primaryColor, outfit.accentColor);
    primaryMat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.65, metalness: 0.14 });
  } else {
    primaryMat = new THREE.MeshStandardMaterial({
      color: outfit.primaryColor,
      roughness: outfit.clothStyle === 'armor' ? 0.42 : 0.72,
      metalness: outfit.clothStyle === 'armor' ? 0.42 : 0.06,
    });
  }

  const bootMat = new THREE.MeshStandardMaterial({
    color: '#111827',
    roughness: 0.7,
    metalness: 0.18,
  });

  // Legs (Bottom-center pivot at y=0)
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.14, 0.86, 0);
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.14, 0.86, 0);

  if (outfit.clothStyle === 'lungi' || outfit.clothStyle === 'shari') {
    // Feet & ankles below flowing wrap
    [-1, 1].forEach((side) => {
      const legGroup = side < 0 ? leftLeg : rightLeg;
      const calf = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.055, 0.76, 10), skinMat);
      calf.position.y = -0.38;
      legGroup.add(calf);
      const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.1, 0.22), bootMat);
      shoe.position.set(0, -0.81, 0.03);
      legGroup.add(shoe);
    });
  } else {
    [-1, 1].forEach((side) => {
      const legGroup = side < 0 ? leftLeg : rightLeg;
      const thigh = new THREE.Mesh(new THREE.CylinderGeometry(0.088, 0.072, 0.74, 10), secondaryMat);
      thigh.position.y = -0.37;
      thigh.castShadow = true;
      legGroup.add(thigh);

      const boot = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.16, 0.23), bootMat);
      boot.position.set(0, -0.78, 0.03);
      boot.castShadow = true;
      legGroup.add(boot);
    });
  }
  root.add(leftLeg);
  root.add(rightLeg);

  // Torso group
  const torso = new THREE.Group();
  torso.position.set(0, 0.86, 0);
  root.add(torso);

  const chestMat = outfit.clothStyle === 'lungi' ? secondaryMat : primaryMat;
  const chest = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.56, 0.25), chestMat);
  chest.position.y = 0.28;
  chest.castShadow = true;
  torso.add(chest);

  // Tactical Vest or Cultural Collar/Belt
  if (outfit.clothStyle === 'armor') {
    const vest = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.36, 0.29), accentMat);
    vest.position.y = 0.32;
    torso.add(vest);

    // Shoulder pauldrons
    [-0.29, 0.29].forEach((x) => {
      const pad = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.14, 0.24), secondaryMat);
      pad.position.set(x, 0.48, 0);
      torso.add(pad);
    });
  } else if (outfit.clothStyle === 'panjabi') {
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.12, 0.08, 12), accentMat);
    collar.position.set(0, 0.57, 0.01);
    torso.add(collar);
  } else if (outfit.clothStyle === 'shirt') {
    const placket = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.48, 0.265), accentMat);
    placket.position.set(0, 0.29, 0);
    torso.add(placket);
  }

  // Bundle-specific torso details
  if (outfit.id === 'bundle_the_streets' || outfit.id === 'bundle_breakdancer') {
    const chain = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.018, 8, 16), accentMat);
    chain.position.set(0, 0.5, 0.13);
    chain.rotation.x = 0.55;
    torso.add(chain);
  }
  if (outfit.id === 'bundle_cobra_rage') {
    const cobraHood = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.28, 0.08), accentMat);
    cobraHood.position.set(0, 0.62, -0.14);
    torso.add(cobraHood);
  }
  if (outfit.id === 'bundle_galaxy_dino' || outfit.id === 'bundle_blue_dino') {
    [0.48, 0.34, 0.2, 0.06].forEach((sy, idx) => {
      const spine = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.11, 4), accentMat);
      spine.position.set(0, sy, -0.17 - idx * 0.02);
      spine.rotation.x = -Math.PI / 2;
      torso.add(spine);
    });
  }

  // Flowing cloth hem for Lungi / Shari / Panjabi (animated cloth physics!)
  let clothHem: THREE.Mesh | undefined;
  let palluSash: THREE.Mesh | undefined;
  if (outfit.clothStyle === 'lungi' || outfit.clothStyle === 'shari') {
    primaryMat.side = THREE.DoubleSide;
    clothHem = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.29, 0.72, 16, 1, true), primaryMat);
    clothHem.position.set(0, -0.34, 0);
    clothHem.castShadow = true;
    torso.add(clothHem);

    const waistBand = new THREE.Mesh(new THREE.CylinderGeometry(0.245, 0.245, 0.08, 16), accentMat);
    waistBand.position.set(0, 0.02, 0);
    torso.add(waistBand);

    if (outfit.clothStyle === 'shari') {
      palluSash = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.62, 0.28), primaryMat);
      palluSash.position.set(-0.14, 0.28, -0.02);
      palluSash.rotation.z = 0.26;
      torso.add(palluSash);
    }
  } else if (outfit.clothStyle === 'panjabi') {
    clothHem = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.27, 0.36, 14), primaryMat);
    clothHem.position.set(0, -0.12, 0);
    clothHem.castShadow = true;
    torso.add(clothHem);
  }

  // Head
  const head = new THREE.Group();
  head.position.set(0, 0.62, 0);
  torso.add(head);

  const cranium = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.26, 0.24), skinMat);
  cranium.position.y = 0.13;
  cranium.castShadow = true;
  head.add(cranium);

  if (outfit.id === 'bundle_steampunk_revolution') {
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.025, 16), secondaryMat);
    brim.position.set(0, 0.26, 0);
    head.add(brim);
    const hatTop = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.13, 0.2, 16), secondaryMat);
    hatTop.position.set(0, 0.36, 0);
    head.add(hatTop);
    const hatBand = new THREE.Mesh(new THREE.CylinderGeometry(0.142, 0.142, 0.04, 16), accentMat);
    hatBand.position.set(0, 0.29, 0);
    head.add(hatBand);
    const goggles = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.06, 0.04), accentMat);
    goggles.position.set(0, 0.16, 0.125);
    head.add(goggles);
  } else if (outfit.id === 'bundle_the_streets' || outfit.id === 'bundle_breakdancer') {
    const capCrown = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.12, 0.26), primaryMat);
    capCrown.position.set(0, 0.24, 0);
    head.add(capCrown);
    const capBrim = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.025, 0.14), accentMat);
    capBrim.position.set(0, 0.2, outfit.id === 'bundle_the_streets' ? -0.16 : 0.16);
    head.add(capBrim);
    const shades = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.055, 0.035), accentMat);
    shades.position.set(0, 0.15, 0.125);
    head.add(shades);
  } else if (outfit.clothStyle === 'armor') {
    // Tactical Helmet + Glowing Visor
    const helmet = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.16, 0.28), primaryMat);
    helmet.position.set(0, 0.21, 0);
    head.add(helmet);

    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.22, 0.065, 0.04),
      new THREE.MeshStandardMaterial({
        color: outfit.accentColor,
        emissive: outfit.accentColor,
        emissiveIntensity: 0.75,
        roughness: 0.15,
      })
    );
    visor.position.set(0, 0.14, 0.125);
    head.add(visor);

    if (outfit.id === 'bundle_sakura' || outfit.id === 'bundle_zombie_samurai') {
      [-0.1, 0.1].forEach((hx) => {
        const horn = new THREE.Mesh(new THREE.ConeGeometry(0.032, 0.16, 6), accentMat);
        horn.position.set(hx, 0.33, 0.06);
        horn.rotation.z = hx < 0 ? 0.35 : -0.35;
        head.add(horn);
      });
    } else if (outfit.id === 'bundle_bunny_warrior') {
      [-0.07, 0.07].forEach((ex) => {
        const ear = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.28, 0.045), secondaryMat);
        ear.position.set(ex, 0.4, -0.02);
        ear.rotation.z = ex < 0 ? 0.12 : -0.12;
        head.add(ear);
      });
    } else if (outfit.id === 'bundle_galaxy_dino' || outfit.id === 'bundle_blue_dino') {
      const snout = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.11, 0.16), primaryMat);
      snout.position.set(0, 0.22, 0.16);
      head.add(snout);
    } else if (outfit.id === 'bundle_green_criminal' || outfit.id === 'bundle_red_criminal') {
      const mask = new THREE.Mesh(
        new THREE.BoxGeometry(0.23, 0.21, 0.03),
        new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.4 })
      );
      mask.position.set(0, 0.12, 0.128);
      head.add(mask);
    }
  } else {
    // Hair & sunglasses
    const hair = new THREE.Mesh(new THREE.BoxGeometry(0.255, 0.1, 0.26), bootMat);
    hair.position.set(0, 0.24, -0.01);
    head.add(hair);

    const shades = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.045, 0.03), accentMat);
    shades.position.set(0, 0.15, 0.125);
    head.add(shades);
  }

  // Arms
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.3, 0.48, 0);
  const rightArm = new THREE.Group();
  rightArm.position.set(0.3, 0.48, 0);

  const sleeveMat = outfit.clothStyle === 'lungi' ? secondaryMat : primaryMat;
  [-1, 1].forEach((side) => {
    const armGroup = side < 0 ? leftArm : rightArm;
    const upperArm = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.055, 0.28, 10), sleeveMat);
    upperArm.position.y = -0.14;
    upperArm.castShadow = true;
    armGroup.add(upperArm);

    const forearm = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.045, 0.25, 10), skinMat);
    forearm.position.y = -0.38;
    armGroup.add(forearm);
  });

  torso.add(leftArm);
  torso.add(rightArm);

  // Weapon Mount in Right Hand
  const weaponMount = new THREE.Group();
  weaponMount.position.set(0, -0.46, 0.18);
  rightArm.add(weaponMount);

  if (showWeapon) {
    const weaponMesh = buildWeaponMesh(weapon, skin);
    weaponMesh.rotation.x = Math.PI / 2 - 0.18;
    weaponMount.add(weaponMesh);
  }

  // Default tactical hold pose
  rightArm.rotation.set(-1.1, 0, -0.12);
  leftArm.rotation.set(-0.95, 0.35, 0.18);

  return {
    group: root,
    refs: {
      root,
      torso,
      head,
      leftArm,
      rightArm,
      leftLeg,
      rightLeg,
      clothHem,
      palluSash,
      weaponMount,
    },
  };
}

export function updateCharacterAnimation(
  refs: CharacterAnimRefs,
  elapsed: number,
  speedRatio: number,
  posture: 'stand' | 'crouch' | 'prone' = 'stand',
  activeEmote?: { id: string; elapsed: number; duration: number } | null
) {
  if (activeEmote && activeEmote.elapsed < activeEmote.duration) {
    const t = activeEmote.elapsed;
    refs.weaponMount.visible = false;
    refs.root.rotation.set(0, 0, 0);
    refs.root.position.y = 0;
    refs.torso.rotation.set(0, 0, 0);
    refs.torso.position.y = 0.86;
    refs.head.rotation.set(0, 0, 0);
    refs.leftArm.rotation.set(0, 0, 0.12);
    refs.rightArm.rotation.set(0, 0, -0.12);
    refs.leftLeg.rotation.set(0, 0, 0);
    refs.rightLeg.rotation.set(0, 0, 0);

    switch (activeEmote.id) {
      case 'emote_hello_wave':
        refs.rightArm.rotation.set(-0.2, 0, -2.55 + Math.sin(t * 10) * 0.35);
        refs.leftArm.rotation.set(-0.15, 0, 0.2);
        refs.head.rotation.z = Math.sin(t * 4) * 0.12;
        refs.torso.position.y = 0.86 + Math.abs(Math.sin(t * 4)) * 0.04;
        break;
      case 'emote_wiggle_walk':
        refs.torso.rotation.z = Math.sin(t * 7.5) * 0.24;
        refs.torso.rotation.y = Math.cos(t * 7.5) * 0.22;
        refs.leftArm.rotation.set(Math.sin(t * 11) * 0.5, 0, 0.95 + Math.sin(t * 8) * 0.45);
        refs.rightArm.rotation.set(-Math.sin(t * 11) * 0.5, 0, -0.95 - Math.cos(t * 8) * 0.45);
        refs.leftLeg.rotation.x = Math.sin(t * 7.5) * 0.45;
        refs.rightLeg.rotation.x = -Math.sin(t * 7.5) * 0.45;
        refs.torso.position.y = 0.84 + Math.abs(Math.sin(t * 7.5)) * 0.07;
        break;
      case 'emote_bhangra':
        refs.torso.position.y = 0.82 + Math.abs(Math.sin(t * 9.5)) * 0.12;
        refs.torso.rotation.z = Math.sin(t * 4.75) * 0.12;
        refs.leftArm.rotation.set(-0.3, 0, 2.35 + Math.sin(t * 9.5) * 0.3);
        refs.rightArm.rotation.set(-0.3, 0, -2.35 - Math.cos(t * 9.5) * 0.3);
        refs.leftLeg.rotation.x = Math.max(0, Math.sin(t * 9.5)) * -0.75;
        refs.rightLeg.rotation.x = Math.max(0, -Math.sin(t * 9.5)) * -0.75;
        break;
      case 'emote_samba':
        refs.torso.rotation.y = Math.sin(t * 10) * 0.42;
        refs.torso.rotation.z = Math.cos(t * 10) * 0.14;
        refs.leftArm.rotation.set(-0.7 + Math.sin(t * 10) * 0.5, 0, 0.85);
        refs.rightArm.rotation.set(-0.7 - Math.sin(t * 10) * 0.5, 0, -0.85);
        refs.leftLeg.rotation.x = Math.sin(t * 13) * 0.52;
        refs.rightLeg.rotation.x = -Math.sin(t * 13) * 0.52;
        refs.torso.position.y = 0.84 + Math.abs(Math.sin(t * 13)) * 0.06;
        break;
      case 'emote_kung_fu':
        refs.torso.position.y = 0.68;
        refs.leftLeg.rotation.set(-0.45, 0, 0.35);
        refs.rightLeg.rotation.set(-0.45, 0, -0.35);
        refs.torso.rotation.y = Math.sin(t * 5) * 0.35;
        refs.leftArm.rotation.set(-1.35 + Math.sin(t * 11) * 0.5, 0.3, 0.25);
        refs.rightArm.rotation.set(-1.35 - Math.sin(t * 11) * 0.5, -0.3, -0.25);
        break;
      case 'emote_crane_kick':
        if (t < 1.35) {
          refs.torso.position.y = 0.88;
          refs.leftLeg.rotation.x = -1.25;
          refs.leftArm.rotation.set(0, 0, 1.45);
          refs.rightArm.rotation.set(0, 0, -1.45);
        } else {
          const kickP = Math.sin(Math.min(1, (t - 1.35) / 0.55) * Math.PI);
          refs.rightLeg.rotation.x = -1.55 * kickP;
          refs.torso.rotation.x = -0.25 * kickP;
          refs.leftArm.rotation.set(-0.4, 0, 0.7);
          refs.rightArm.rotation.set(-0.4, 0, -0.7);
        }
        break;
      case 'emote_dragon_fist':
        if (t < 0.9) {
          refs.torso.position.y = 0.72;
          refs.torso.rotation.y = 0.65;
          refs.rightArm.rotation.set(0.55, 0, -0.3);
          refs.leftArm.rotation.set(-1.1, 0, 0.3);
        } else {
          const punch = Math.min(1, (t - 0.9) / 0.22);
          refs.torso.position.y = 0.78;
          refs.torso.rotation.y = THREE.MathUtils.lerp(0.65, -0.55, punch);
          refs.rightArm.rotation.set(-1.55, 0, 0);
          refs.leftArm.rotation.set(0.4, 0, 0.35);
          refs.leftLeg.rotation.x = -0.45;
          refs.rightLeg.rotation.x = 0.45;
        }
        break;
      case 'emote_one_finger_pushup': {
        const dip = Math.abs(Math.sin(t * 4.2)) * 0.14;
        refs.root.rotation.x = 1.42;
        refs.root.position.y = 0.34 - dip;
        refs.rightArm.rotation.set(-1.5, 0, 0);
        refs.leftArm.rotation.set(0.65, -0.35, -0.35);
        break;
      }
      case 'emote_shadow_boxer':
        refs.torso.position.y = 0.8 + Math.abs(Math.sin(t * 8)) * 0.06;
        refs.torso.rotation.y = Math.sin(t * 14) * 0.38;
        refs.leftArm.rotation.set(-1.45 + Math.sin(t * 18) * 0.75, 0.2, 0.15);
        refs.rightArm.rotation.set(-1.45 - Math.sin(t * 18) * 0.75, -0.2, -0.15);
        refs.leftLeg.rotation.x = -0.22 + Math.sin(t * 7) * 0.18;
        refs.rightLeg.rotation.x = 0.22 - Math.sin(t * 7) * 0.18;
        break;
      case 'emote_backflip':
        if (t < 0.35) {
          refs.torso.position.y = 0.62;
          refs.torso.rotation.x = 0.38;
        } else if (t < 1.55) {
          const air = (t - 0.35) / 1.2;
          refs.root.position.y = Math.sin(air * Math.PI) * 1.45;
          refs.root.rotation.x = -air * Math.PI * 2;
          refs.leftLeg.rotation.x = -0.9;
          refs.rightLeg.rotation.x = -0.9;
          refs.leftArm.rotation.set(-1.2, 0, 0.3);
          refs.rightArm.rotation.set(-1.2, 0, -0.3);
        } else {
          refs.torso.position.y = 0.74;
          refs.leftArm.rotation.set(0, 0, 0.8);
          refs.rightArm.rotation.set(0, 0, -0.8);
        }
        break;
      case 'emote_im_rich':
        refs.torso.rotation.x = -0.16;
        refs.leftArm.rotation.set(-1.1, 0, 0.4);
        refs.rightArm.rotation.set(-1.3 + Math.sin(t * 12) * 0.45, 0, -0.25);
        refs.torso.rotation.y = Math.sin(t * 3) * 0.2;
        break;
      case 'emote_ffwc_throne':
        refs.torso.position.y = 0.56;
        refs.torso.rotation.x = -0.14;
        refs.leftLeg.rotation.set(-1.28, 0.18, 0);
        refs.rightLeg.rotation.set(-1.28, -0.18, 0);
        refs.leftArm.rotation.set(-0.7, 0, 0.48);
        refs.rightArm.rotation.set(-0.75, 0, -0.48);
        break;
      case 'emote_pirates_flag':
        refs.torso.position.y = 0.86;
        refs.rightArm.rotation.set(-1.55 + Math.sin(Math.min(t, 0.45) * 6) * 0.5, 0, -0.15);
        refs.leftArm.rotation.set(-0.4, 0, 0.35);
        refs.leftLeg.rotation.x = -0.25;
        refs.rightLeg.rotation.x = 0.25;
        break;
      case 'emote_flowers_of_love':
        refs.torso.position.y = 0.52;
        refs.leftLeg.rotation.x = -1.1;
        refs.rightLeg.rotation.x = 0.75;
        refs.rightArm.rotation.set(-1.35, 0, -0.08);
        refs.leftArm.rotation.set(-0.35, 0, 0.3);
        refs.head.rotation.x = -0.1;
        break;
      case 'emote_tea_time':
        refs.torso.position.y = 0.78;
        refs.torso.rotation.z = 0.06;
        refs.rightArm.rotation.set(-1.25 - Math.max(0, Math.sin(t * 2.6)) * 0.45, 0, -0.1);
        refs.leftArm.rotation.set(-0.4, 0.4, 0.25);
        break;
      case 'emote_booyah_celebration':
        refs.root.position.y = Math.abs(Math.sin(t * 4.5)) * 0.32;
        refs.leftArm.rotation.set(-0.2, 0, 2.75);
        refs.rightArm.rotation.set(-0.2, 0, -2.75);
        refs.torso.rotation.y = Math.sin(t * 3.5) * 0.25;
        break;
      case 'emote_cobra_rising':
        refs.root.position.y = Math.min(0.45, t * 0.35) + Math.sin(t * 3.5) * 0.08;
        refs.leftArm.rotation.set(-0.3, 0, 1.35 + Math.sin(t * 4) * 0.2);
        refs.rightArm.rotation.set(-0.3, 0, -1.35 - Math.sin(t * 4) * 0.2);
        refs.head.rotation.x = -0.15;
        break;
      case 'emote_scorpio_shatter':
        if (t < 0.55) {
          refs.root.position.y = Math.sin((t / 0.55) * Math.PI) * 0.55;
          refs.rightArm.rotation.set(-2.5, 0, -0.2);
        } else {
          refs.torso.position.y = 0.46;
          refs.torso.rotation.x = 0.58;
          refs.rightArm.rotation.set(-1.45, 0, 0);
          refs.leftArm.rotation.set(0.45, 0, 0.45);
          refs.leftLeg.rotation.x = -0.7;
          refs.rightLeg.rotation.x = 0.65;
        }
        break;
      case 'emote_legendary_katana_slash':
        refs.torso.position.y = 0.78;
        refs.torso.rotation.y = Math.sin(t * 7.5) * 0.72;
        refs.rightArm.rotation.set(-1.4 + Math.sin(t * 10) * 0.85, 0, -0.6 + Math.cos(t * 10) * 0.65);
        refs.leftArm.rotation.set(-0.8, 0.4, 0.4);
        refs.leftLeg.rotation.x = -0.35;
        refs.rightLeg.rotation.x = 0.35;
        break;
      default:
        break;
    }

    if (refs.clothHem) {
      refs.clothHem.rotation.x = Math.sin(t * 6) * 0.14;
      refs.clothHem.rotation.z = Math.cos(t * 5) * 0.09;
    }
    if (refs.palluSash) {
      refs.palluSash.rotation.x = Math.sin(t * 6.5) * 0.18;
    }
    return;
  }

  // Restore weapon & default pose when not emoting
  refs.weaponMount.visible = true;
  refs.root.rotation.set(0, 0, 0);
  refs.root.position.y = 0;
  refs.torso.rotation.y = 0;
  refs.torso.rotation.z = 0;
  refs.head.rotation.set(0, 0, 0);
  refs.leftArm.rotation.z = 0.18;
  refs.rightArm.rotation.z = -0.12;
  refs.leftLeg.rotation.z = 0;
  refs.rightLeg.rotation.z = 0;

  const isMoving = speedRatio > 0.08;
  const strideFreq = 9.5;
  const swing = isMoving ? Math.sin(elapsed * strideFreq) * 0.65 * Math.min(speedRatio, 1.3) : 0;

  refs.leftLeg.rotation.x = swing;
  refs.rightLeg.rotation.x = -swing;

  // Idle breathing
  const breathe = Math.sin(elapsed * 2.4) * 0.02;
  refs.torso.position.y = posture === 'crouch' ? 0.54 : posture === 'prone' ? 0.2 : 0.86 + breathe;
  refs.torso.rotation.x = posture === 'prone' ? 1.35 : posture === 'crouch' ? 0.28 : 0;

  if (!isMoving) {
    refs.rightArm.rotation.x = -1.08 + breathe * 1.4;
    refs.leftArm.rotation.x = -0.92 - breathe;
  } else {
    refs.rightArm.rotation.x = -1.1 + swing * 0.15;
    refs.leftArm.rotation.x = -0.95 - swing * 0.18;
  }

  // Cloth sway physics for Bangladeshi Lungi, Panjabi, Shari
  if (refs.clothHem) {
    refs.clothHem.rotation.x = (isMoving ? -0.14 : 0) + Math.sin(elapsed * 3.5) * (isMoving ? 0.12 : 0.025);
    refs.clothHem.rotation.z = Math.cos(elapsed * 2.7) * (isMoving ? 0.07 : 0.015);
  }
  if (refs.palluSash) {
    refs.palluSash.rotation.x = Math.sin(elapsed * 4.2) * (isMoving ? 0.18 : 0.04);
  }
}
