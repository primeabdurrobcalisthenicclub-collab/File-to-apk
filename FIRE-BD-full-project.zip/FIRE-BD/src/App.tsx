import { useEffect, useMemo, useState } from 'react';
import {
  LuckRoyaleModal,
  VaultModal,
  VehiclesModal,
  WeaponsModal,
} from './components/ArmoryVaultModals';
import { LobbyModalType, LobbyOverlay } from './components/LobbyOverlay';
import { MatchSummaryModal, ProfileModal } from './components/ProfileAndSummaryModals';
import { SettingsModal } from './components/SettingsModal';
import { SplashScreen } from './components/SplashScreen';
import { StoreModal } from './components/StoreModal';
import { GAME_IMAGES } from './data/assets';
import {
  createInitialProfile,
  DEFAULT_HUD_LAYOUT,
  DEFAULT_SENSITIVITY,
  EMOTES,
  GAME_MODES,
  INITIAL_FRIENDS,
  LUCK_ROYALE_REWARDS,
  OUTFITS,
  VEHICLES,
  WEAPON_SKINS,
} from './data/catalog';
import { BattleArena } from './three/BattleArena';
import { LobbyScene } from './three/LobbyScene';
import {
  AuthProvider,
  ChatMessage,
  FriendEntry,
  GameModeId,
  HudButtonLayout,
  LobbyInspectTarget,
  LobbyWeather,
  MatchSummary,
  PlayerProfile,
  ScreenStage,
  SensitivitySettings,
  TeamFormat,
} from './types/game';
import { audioEngine } from './utils/sound';

const STORAGE_PROFILE_KEY = 'fire_bd_profile_v1';
const STORAGE_SENS_KEY = 'fire_bd_sens_v1';
const STORAGE_HUD_KEY = 'fire_bd_hud_v1';

export default function App() {
  const [stage, setStage] = useState<ScreenStage>('splash');
  const [profile, setProfile] = useState<PlayerProfile>(() => {
    const base = createInitialProfile();
    try {
      const saved = localStorage.getItem(STORAGE_PROFILE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as PlayerProfile;
        const validWeapon = WEAPON_SKINS.some((s) => s.weaponId === parsed.equippedWeaponId)
          ? parsed.equippedWeaponId
          : base.equippedWeaponId;
        return {
          ...base,
          ...parsed,
          equippedWeaponId: validWeapon,
          equippedSkinIds: { ...base.equippedSkinIds, ...(parsed.equippedSkinIds ?? {}) },
          ownedSkinIds: Array.from(new Set([...base.ownedSkinIds, ...(parsed.ownedSkinIds ?? [])])),
          skinLevels: { ...base.skinLevels, ...(parsed.skinLevels ?? {}) },
          ownedEmoteIds: parsed.ownedEmoteIds?.length
            ? Array.from(new Set(['emote_hello_wave', ...parsed.ownedEmoteIds]))
            : base.ownedEmoteIds,
          equippedEmoteIds: parsed.equippedEmoteIds?.length
            ? parsed.equippedEmoteIds
            : base.equippedEmoteIds,
        };
      }
    } catch {
      // ignore storage errors
    }
    return base;
  });

  const [sensitivity, setSensitivity] = useState<SensitivitySettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_SENS_KEY);
      if (saved) return JSON.parse(saved) as SensitivitySettings;
    } catch {
      // ignore
    }
    return DEFAULT_SENSITIVITY;
  });

  const [hudLayout, setHudLayout] = useState<HudButtonLayout[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_HUD_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as HudButtonLayout[];
        const savedIds = new Set(parsed.map((b) => b.id));
        const missing = DEFAULT_HUD_LAYOUT.filter((b) => !savedIds.has(b.id));
        return [...parsed, ...missing];
      }
    } catch {
      // ignore
    }
    return DEFAULT_HUD_LAYOUT;
  });

  const [selectedModeId, setSelectedModeId] = useState<GameModeId>('br_rank');
  const [selectedFormat, setSelectedFormat] = useState<TeamFormat>('4v4');
  const [activeModal, setActiveModal] = useState<LobbyModalType>(null);
  const [storeTabHint, setStoreTabHint] = useState<'bundles' | 'bangladeshi' | 'emotes' | 'topup' | undefined>(undefined);
  const [inspectTarget, setInspectTarget] = useState<LobbyInspectTarget>('character');
  const [lobbyWeather, setLobbyWeather] = useState<LobbyWeather>('clear');
  const [activeLobbyEmote, setActiveLobbyEmote] = useState<{ id: string; key: number } | null>(null);
  const [friends, setFriends] = useState<FriendEntry[]>(INITIAL_FRIENDS);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'System',
      text: 'Welcome to FIRE BD by Abdur Rob. Form a squad or select a combat mode to drop in!',
      timestamp: 'Now',
      isSystem: true,
    },
    {
      id: 'm2',
      sender: 'Tanvir_OP',
      text: 'Ready for BR Rank on Sonar Island!',
      timestamp: 'Now',
    },
  ]);
  const [matchCountdown, setMatchCountdown] = useState(3);
  const [lastSummary, setLastSummary] = useState<MatchSummary | null>(null);

  // Persist profile, sensitivity & HUD layout
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_PROFILE_KEY, JSON.stringify(profile));
    } catch {
      // ignore
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_SENS_KEY, JSON.stringify(sensitivity));
    } catch {
      // ignore
    }
  }, [sensitivity]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_HUD_KEY, JSON.stringify(hudLayout));
    } catch {
      // ignore
    }
  }, [hudLayout]);

  // Matchmaking countdown timer
  useEffect(() => {
    if (stage !== 'matchmaking') return;
    if (matchCountdown <= 0) {
      setStage('ingame');
      return;
    }
    const timer = window.setTimeout(() => setMatchCountdown((c) => c - 1), 750);
    return () => window.clearTimeout(timer);
  }, [stage, matchCountdown]);

  const squadFriends = useMemo(() => friends.filter((f) => f.inSquad), [friends]);

  const buildAdminState = (base: PlayerProfile, username?: string): PlayerProfile => {
    const allSkinLevels: Record<string, number> = { ...base.skinLevels };
    WEAPON_SKINS.forEach((s) => {
      allSkinLevels[s.id] = s.maxLevel;
    });
    return {
      ...base,
      username: username ?? base.username,
      provider: 'admin',
      isAdmin: true,
      diamonds: 999999,
      gold: 9999999,
      ownedOutfitIds: OUTFITS.map((o) => o.id),
      ownedSkinIds: WEAPON_SKINS.map((s) => s.id),
      skinLevels: allSkinLevels,
      ownedVehicleIds: VEHICLES.map((v) => v.id),
      ownedEmoteIds: EMOTES.map((e) => e.id),
      equippedEmoteIds: EMOTES.slice(0, 8).map((e) => e.id),
    };
  };

  const handleAuthenticate = (provider: AuthProvider, username: string) => {
    setProfile((prev) => {
      if (provider === 'admin') {
        return buildAdminState(prev, username);
      }
      return {
        ...prev,
        username,
        provider,
        isAdmin: false,
        boundProviders:
          provider === 'guest'
            ? prev.boundProviders
            : Array.from(new Set([...prev.boundProviders, provider])),
      };
    });
    setStage('lobby');
  };

  const handleActivateAdmin = (password: string): boolean => {
    if (password !== 'prime1bdatnb') return false;
    setProfile((prev) => buildAdminState(prev));
    return true;
  };

  const handleSignOut = () => {
    setActiveModal(null);
    setStage('splash');
  };

  const handleBindAccount = (provider: AuthProvider) => {
    setProfile((prev) => ({
      ...prev,
      provider: prev.provider === 'guest' ? provider : prev.provider,
      boundProviders: Array.from(new Set([...prev.boundProviders, provider])),
    }));
  };

  const handleSelectMode = (modeId: GameModeId) => {
    setSelectedModeId(modeId);
    const mode = GAME_MODES.find((m) => m.id === modeId) ?? GAME_MODES[0];
    if (!mode.supportedFormats.includes(selectedFormat)) {
      setSelectedFormat(mode.supportedFormats[0]);
    }
  };

  const handleBuyOutfit = (outfitId: string, useGold: boolean): string | null => {
    const item = OUTFITS.find((o) => o.id === outfitId);
    if (!item) return 'Outfit not found.';

    if (profile.ownedOutfitIds.includes(outfitId)) {
      setProfile((p) => ({ ...p, equippedOutfitId: outfitId }));
      setInspectTarget('character');
      return null;
    }

    if (useGold) {
      if (item.priceGold <= 0 || profile.gold < item.priceGold) {
        return 'Not enough Gold Coins.';
      }
      setProfile((p) => ({
        ...p,
        gold: p.gold - item.priceGold,
        ownedOutfitIds: [...p.ownedOutfitIds, outfitId],
        equippedOutfitId: outfitId,
      }));
    } else {
      if (profile.diamonds < item.priceDiamonds) {
        return 'Not enough Diamonds. Top up via Store!';
      }
      setProfile((p) => ({
        ...p,
        diamonds: p.diamonds - item.priceDiamonds,
        ownedOutfitIds: [...p.ownedOutfitIds, outfitId],
        equippedOutfitId: outfitId,
      }));
    }
    setInspectTarget('character');
    audioEngine.playVictoryFanfare();
    return null;
  };

  const handleToggleEquipEmote = (emoteId: string) => {
    setProfile((p) => {
      if (!p.ownedEmoteIds.includes(emoteId)) return p;
      const already = p.equippedEmoteIds.includes(emoteId);
      if (already) {
        if (p.equippedEmoteIds.length <= 1) return p;
        return { ...p, equippedEmoteIds: p.equippedEmoteIds.filter((id) => id !== emoteId) };
      }
      const next = [...p.equippedEmoteIds, emoteId].slice(-8);
      return { ...p, equippedEmoteIds: next };
    });
  };

  const handleBuyEmote = (emoteId: string, useGold: boolean): string | null => {
    const emote = EMOTES.find((e) => e.id === emoteId);
    if (!emote) return 'Emote not found.';

    if (profile.ownedEmoteIds.includes(emoteId)) {
      handleToggleEquipEmote(emoteId);
      return null;
    }

    if (profile.isAdmin) {
      setProfile((p) => ({
        ...p,
        ownedEmoteIds: [...p.ownedEmoteIds, emoteId],
        equippedEmoteIds: [...p.equippedEmoteIds, emoteId].slice(-8),
      }));
      audioEngine.playVictoryFanfare();
      return null;
    }

    if (useGold) {
      if (emote.priceGold <= 0 || profile.gold < emote.priceGold) {
        return 'Not enough Gold Coins.';
      }
      setProfile((p) => ({
        ...p,
        gold: p.gold - emote.priceGold,
        ownedEmoteIds: [...p.ownedEmoteIds, emoteId],
        equippedEmoteIds: [...p.equippedEmoteIds, emoteId].slice(-8),
      }));
    } else {
      if (profile.diamonds < emote.priceDiamonds) {
        return 'Not enough Diamonds. Top up via Store!';
      }
      setProfile((p) => ({
        ...p,
        diamonds: p.diamonds - emote.priceDiamonds,
        ownedEmoteIds: [...p.ownedEmoteIds, emoteId],
        equippedEmoteIds: [...p.equippedEmoteIds, emoteId].slice(-8),
      }));
    }
    audioEngine.playVictoryFanfare();
    return null;
  };

  const handleBuySkin = (skinId: string): string | null => {
    const skin = WEAPON_SKINS.find((s) => s.id === skinId);
    if (!skin) return 'Skin not found.';

    if (profile.ownedSkinIds.includes(skinId)) {
      setProfile((p) => ({
        ...p,
        equippedWeaponId: skin.weaponId,
        equippedSkinIds: { ...p.equippedSkinIds, [skin.weaponId]: skinId },
      }));
      return null;
    }

    if (profile.diamonds < skin.priceDiamonds) {
      return 'Not enough Diamonds. Top up via Store!';
    }
    setProfile((p) => ({
      ...p,
      diamonds: p.diamonds - skin.priceDiamonds,
      ownedSkinIds: [...p.ownedSkinIds, skinId],
      equippedWeaponId: skin.weaponId,
      equippedSkinIds: { ...p.equippedSkinIds, [skin.weaponId]: skinId },
    }));
    audioEngine.playVictoryFanfare();
    return null;
  };

  const handleUpgradeSkin = (skinId: string): string | null => {
    const skin = WEAPON_SKINS.find((s) => s.id === skinId);
    if (!skin) return 'Skin not found.';
    const currentLv = profile.skinLevels[skinId] ?? skin.level;
    if (currentLv >= skin.maxLevel) return 'Skin already at max level.';
    if (profile.diamonds < skin.upgradeCostDiamonds) {
      return `Need ${skin.upgradeCostDiamonds} Diamonds to upgrade.`;
    }
    setProfile((p) => ({
      ...p,
      diamonds: p.diamonds - skin.upgradeCostDiamonds,
      skinLevels: { ...p.skinLevels, [skinId]: currentLv + 1 },
    }));
    audioEngine.playVictoryFanfare();
    return null;
  };

  const handleBuyVehicle = (vehicleId: string): string | null => {
    const veh = VEHICLES.find((v) => v.id === vehicleId);
    if (!veh) return 'Vehicle not found.';
    if (profile.ownedVehicleIds.includes(vehicleId)) {
      setProfile((p) => ({ ...p, equippedVehicleId: vehicleId }));
      return null;
    }
    if (profile.diamonds < veh.priceDiamonds) {
      return 'Not enough Diamonds. Top up via Store!';
    }
    setProfile((p) => ({
      ...p,
      diamonds: p.diamonds - veh.priceDiamonds,
      ownedVehicleIds: [...p.ownedVehicleIds, vehicleId],
      equippedVehicleId: vehicleId,
    }));
    audioEngine.playVictoryFanfare();
    return null;
  };

  const handleLuckRoyaleSpin = (
    currency: 'diamonds' | 'gold'
  ): { rewardLabel: string } | { error: string } => {
    const cost = profile.isAdmin ? 0 : currency === 'diamonds' ? 40 : 800;
    if (currency === 'diamonds' && profile.diamonds < cost) {
      return { error: 'Need 40 Diamonds for Royal Spin.' };
    }
    if (currency === 'gold' && profile.gold < cost) {
      return { error: 'Need 800 Gold Coins to spin.' };
    }

    const reward = LUCK_ROYALE_REWARDS[Math.floor(Math.random() * LUCK_ROYALE_REWARDS.length)];
    setProfile((p) => {
      const next: PlayerProfile = {
        ...p,
        diamonds: currency === 'diamonds' ? p.diamonds - cost : p.diamonds,
        gold: currency === 'gold' ? p.gold - cost : p.gold,
      };
      if (reward.type === 'diamonds') next.diamonds += reward.amount;
      if (reward.type === 'gold') next.gold += reward.amount;
      if (reward.type === 'outfit' && !next.ownedOutfitIds.includes(reward.itemId)) {
        next.ownedOutfitIds = [...next.ownedOutfitIds, reward.itemId];
        next.equippedOutfitId = reward.itemId;
      }
      if (reward.type === 'skin' && !next.ownedSkinIds.includes(reward.itemId)) {
        next.ownedSkinIds = [...next.ownedSkinIds, reward.itemId];
      }
      if (reward.type === 'vehicle' && !next.ownedVehicleIds.includes(reward.itemId)) {
        next.ownedVehicleIds = [...next.ownedVehicleIds, reward.itemId];
        next.equippedVehicleId = reward.itemId;
      }
      return next;
    });
    return { rewardLabel: reward.label };
  };

  const handleAddFriend = (query: string) => {
    const newFriend: FriendEntry = {
      uid: query.startsWith('BD-') ? query : `BD-${Math.floor(100000 + Math.random() * 899999)}`,
      username: query.startsWith('BD-') ? `Player_${query.slice(-3)}` : query,
      rankTier: 'Platinum I',
      online: true,
      inSquad: false,
      likes: Math.floor(120 + Math.random() * 500),
      outfitId: OUTFITS[Math.floor(Math.random() * OUTFITS.length)].id,
    };
    setFriends((prev) => [newFriend, ...prev]);
  };

  const handleToggleSquadInvite = (uid: string) => {
    setFriends((prev) => {
      const target = prev.find((f) => f.uid === uid);
      if (!target || !target.online) return prev;
      const currentlyIn = prev.filter((f) => f.inSquad).length;
      if (!target.inSquad && currentlyIn >= 3) return prev; // max squad 4 including player
      return prev.map((f) => (f.uid === uid ? { ...f, inSquad: !f.inSquad } : f));
    });
  };

  const handleSendChat = (text: string) => {
    setChatMessages((prev) => [
      ...prev,
      { id: `${Date.now()}`, sender: profile.username, text, timestamp: 'Now' },
    ]);
  };

  const handleMatchEnd = (summary: MatchSummary) => {
    setLastSummary(summary);
    setProfile((p) => {
      const nextRp = Math.max(1000, p.rankPoints + summary.rankDelta);
      const nextTier =
        nextRp >= 3200
          ? 'Heroic'
          : nextRp >= 2800
          ? 'Diamond IV'
          : nextRp >= 2500
          ? 'Diamond II'
          : 'Platinum III';
      return {
        ...p,
        matches: p.matches + 1,
        booyahs: p.booyahs + (summary.victory ? 1 : 0),
        kills: p.kills + summary.playerKills,
        gold: p.gold + summary.goldEarned,
        rankPoints: nextRp,
        rankTier: nextTier,
        // Squadmates also randomly commend player after match
        likes: p.likes + (summary.victory ? 2 : 1),
      };
    });
    setStage('summary');
  };

  const handleLikeParticipant = (participantId: string) => {
    if (!lastSummary) return;
    setLastSummary((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        participants: prev.participants.map((part) =>
          part.id === participantId && !part.likedByMe
            ? { ...part, likedByMe: true, likesReceived: part.likesReceived + 1 }
            : part
        ),
      };
    });
    if (participantId === 'player') {
      setProfile((p) => ({ ...p, likes: p.likes + 1 }));
    }
  };

  const equippedSkinId =
    profile.equippedSkinIds[profile.equippedWeaponId] ??
    WEAPON_SKINS.find((s) => s.weaponId === profile.equippedWeaponId)?.id ??
    WEAPON_SKINS[0].id;

  const currentMode = GAME_MODES.find((m) => m.id === selectedModeId) ?? GAME_MODES[0];

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#080b10]">
      {stage === 'splash' && <SplashScreen onAuthenticate={handleAuthenticate} />}

      {(stage === 'lobby' || stage === 'matchmaking') && (
        <>
          <LobbyScene
            equippedOutfitId={profile.equippedOutfitId}
            equippedWeaponId={profile.equippedWeaponId}
            equippedSkinId={equippedSkinId}
            equippedVehicleId={profile.equippedVehicleId}
            inspectTarget={inspectTarget}
            squadFriends={squadFriends}
            weather={lobbyWeather}
            activeEmote={activeLobbyEmote}
          />

          <LobbyOverlay
            profile={profile}
            selectedModeId={selectedModeId}
            selectedFormat={selectedFormat}
            friends={friends}
            chatMessages={chatMessages}
            inspectTarget={inspectTarget}
            weather={lobbyWeather}
            onSelectMode={handleSelectMode}
            onSelectFormat={setSelectedFormat}
            onStartMatch={() => {
              setActiveModal(null);
              setMatchCountdown(3);
              setStage('matchmaking');
            }}
            onOpenModal={(m) => {
              setStoreTabHint(m === 'topup' ? 'topup' : undefined);
              setActiveModal(m);
            }}
            onAddFriend={handleAddFriend}
            onToggleSquadInvite={handleToggleSquadInvite}
            onSendChat={handleSendChat}
            onSetInspectTarget={setInspectTarget}
            onChangeWeather={setLobbyWeather}
            onPlayEmote={(emoteId) => setActiveLobbyEmote({ id: emoteId, key: Date.now() })}
          />

          {/* Modals */}
          {(activeModal === 'store' || activeModal === 'topup') && (
            <StoreModal
              initialTab={storeTabHint ?? (activeModal === 'topup' ? 'topup' : 'bundles')}
              profile={profile}
              onClose={() => {
                setStoreTabHint(undefined);
                setActiveModal(null);
                setInspectTarget('character');
              }}
              onBuyOutfit={handleBuyOutfit}
              onBuyEmote={handleBuyEmote}
              onBuySkin={handleBuySkin}
              onBuyVehicle={handleBuyVehicle}
              onCompleteTopUp={(diamonds) =>
                setProfile((p) => ({ ...p, diamonds: p.diamonds + diamonds }))
              }
            />
          )}

          {activeModal === 'vault' && (
            <VaultModal
              profile={profile}
              onEquipOutfit={(id) => {
                setProfile((p) => ({ ...p, equippedOutfitId: id }));
                setInspectTarget('character');
              }}
              onToggleEquipEmote={handleToggleEquipEmote}
              onPreviewEmote={(emoteId) => {
                setInspectTarget('character');
                setActiveLobbyEmote({ id: emoteId, key: Date.now() });
              }}
              onOpenStore={(tab) => {
                setStoreTabHint(tab);
                setActiveModal('store');
              }}
              onClose={() => setActiveModal(null)}
            />
          )}

          {activeModal === 'weapons' && (
            <WeaponsModal
              profile={profile}
              onSelectWeapon={(weaponId) => {
                setProfile((p) => ({ ...p, equippedWeaponId: weaponId }));
                setInspectTarget('weapon');
              }}
              onSelectSkin={(weaponId, skinId) => {
                setProfile((p) => ({
                  ...p,
                  equippedWeaponId: weaponId,
                  equippedSkinIds: { ...p.equippedSkinIds, [weaponId]: skinId },
                }));
                setInspectTarget('weapon');
              }}
              onUpgradeSkin={handleUpgradeSkin}
              onBuySkin={handleBuySkin}
              onClose={() => {
                setActiveModal(null);
                setInspectTarget('character');
              }}
            />
          )}

          {activeModal === 'vehicles' && (
            <VehiclesModal
              profile={profile}
              onSelectVehicle={(vehicleId) => {
                setProfile((p) => ({ ...p, equippedVehicleId: vehicleId }));
                setInspectTarget('vehicle');
              }}
              onBuyVehicle={handleBuyVehicle}
              onClose={() => {
                setActiveModal(null);
                setInspectTarget('character');
              }}
            />
          )}

          {activeModal === 'luck_royale' && (
            <LuckRoyaleModal
              profile={profile}
              onSpin={handleLuckRoyaleSpin}
              onClose={() => setActiveModal(null)}
            />
          )}

          {activeModal === 'settings' && (
            <SettingsModal
              sensitivity={sensitivity}
              hudLayout={hudLayout}
              onSaveSensitivity={setSensitivity}
              onSaveHud={setHudLayout}
              onClose={() => setActiveModal(null)}
            />
          )}

          {activeModal === 'profile' && (
            <ProfileModal
              profile={profile}
              onBindAccount={handleBindAccount}
              onActivateAdmin={handleActivateAdmin}
              onSignOut={handleSignOut}
              onClose={() => setActiveModal(null)}
            />
          )}

          {/* Matchmaking Countdown Overlay */}
          {stage === 'matchmaking' && (
            <div className="fixed inset-0 z-50 bg-slate-950/90 flex items-center justify-center p-4">
              <div className="w-full max-w-md bg-slate-900 border border-amber-400/40 rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src={
                    currentMode.mapKey === 'sonar_island'
                      ? GAME_IMAGES.mapSonarIsland
                      : GAME_IMAGES.mapDhakaYard
                  }
                  alt={currentMode.mapName}
                  referrerPolicy="no-referrer"
                  className="w-full h-44 object-cover"
                />
                <div className="p-6 text-center">
                  <div className="text-xs text-amber-400 font-semibold uppercase tracking-widest mb-1">
                    Matchmaking · {selectedFormat}
                  </div>
                  <h2 className="font-display text-2xl font-extrabold text-white mb-2">
                    {currentMode.name} — {currentMode.mapName}
                  </h2>
                  <p className="text-sm text-slate-300 font-mono-num mb-5">
                    Deploying to battlefield in {matchCountdown}...
                  </p>
                  <button
                    onClick={() => setStage('lobby')}
                    className="px-6 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
                  >
                    Cancel Search
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {stage === 'ingame' && (
        <BattleArena
          profile={profile}
          modeId={selectedModeId}
          format={selectedFormat}
          sensitivity={sensitivity}
          hudLayout={hudLayout}
          onMatchEnd={handleMatchEnd}
          onExitEarly={() => setStage('lobby')}
        />
      )}

      {stage === 'summary' && lastSummary && (
        <MatchSummaryModal
          summary={lastSummary}
          onLikeParticipant={handleLikeParticipant}
          onReturnLobby={() => {
            setLastSummary(null);
            setStage('lobby');
          }}
        />
      )}
    </div>
  );
}
