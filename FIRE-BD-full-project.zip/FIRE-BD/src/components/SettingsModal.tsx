import React, { useRef, useState } from 'react';
import { Download, FileCode2, RotateCcw, Sliders, X } from 'lucide-react';
import { DEFAULT_HUD_LAYOUT, DEFAULT_SENSITIVITY } from '../data/catalog';
import { HudButtonId, HudButtonLayout, SensitivitySettings } from '../types/game';
import { audioEngine } from '../utils/sound';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsModalProps {
  sensitivity: SensitivitySettings;
  hudLayout: HudButtonLayout[];
  onSaveSensitivity: (next: SensitivitySettings) => void;
  onSaveHud: (next: HudButtonLayout[]) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  sensitivity,
  hudLayout,
  onSaveSensitivity,
  onSaveHud,
  onClose,
}) => {
  const [tab, setTab] = useState<'sensitivity' | 'hud' | 'export'>('sensitivity');
  const [localSens, setLocalSens] = useState<SensitivitySettings>(sensitivity);
  const [localHud, setLocalHud] = useState<HudButtonLayout[]>(hudLayout);
  const [selectedBtnId, setSelectedBtnId] = useState<HudButtonId>('fire');
  const [savedMsg, setSavedMsg] = useState<string | null>(null);
  const previewRef = useRef<HTMLDivElement>(null);
  const draggingIdRef = useRef<HudButtonId | null>(null);

  const selectedBtn = localHud.find((b) => b.id === selectedBtnId) ?? localHud[0];

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!draggingIdRef.current || !previewRef.current) return;
    const rect = previewRef.current.getBoundingClientRect();
    const xPct = Math.max(6, Math.min(94, ((e.clientX - rect.left) / rect.width) * 100));
    const yPct = Math.max(10, Math.min(92, ((e.clientY - rect.top) / rect.height) * 100));
    setLocalHud((prev) =>
      prev.map((btn) => (btn.id === draggingIdRef.current ? { ...btn, xPct, yPct } : btn))
    );
  };

  const handleSaveAll = () => {
    onSaveSensitivity(localSens);
    onSaveHud(localHud);
    audioEngine.playUiClick();
    setSavedMsg('Settings saved & applied to live combat HUD.');
    setTimeout(() => setSavedMsg(null), 2200);
  };

  const sensFields: Array<{ key: keyof SensitivitySettings; label: string }> = [
    { key: 'general', label: 'General' },
    { key: 'redDot', label: 'Red Dot' },
    { key: 'scope2x', label: '2x Scope' },
    { key: 'scope4x', label: '4x Scope' },
    { key: 'sniperScope', label: 'Sniper Scope' },
    { key: 'freeLook', label: 'Free Look' },
  ];

  return (
    <div className="fixed inset-0 z-40 bg-slate-950/88 flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-4xl max-h-[92vh] bg-slate-900 border border-white/15 rounded-2xl flex flex-col shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <Sliders className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="font-display text-lg font-bold text-white">Combat Controls & Sensitivity</h2>
              <p className="text-xs text-slate-400">Customize Free Fire-style HUD layout, opacity, scale, and 0–100 sensitivity</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center justify-between px-5 py-2.5 border-b border-white/10">
          <div className="flex gap-2">
            <button
              onClick={() => setTab('sensitivity')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                tab === 'sensitivity' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
              }`}
            >
              Sensitivity (0–100)
            </button>
            <button
              onClick={() => setTab('hud')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                tab === 'hud' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
              }`}
            >
              Custom HUD Editor
            </button>
            <button
              onClick={() => setTab('export')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer flex items-center gap-1.5 ${
                tab === 'export' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
              }`}
            >
              <FileCode2 className="w-3.5 h-3.5" />
              Export HTML / APK
            </button>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setLocalSens(DEFAULT_SENSITIVITY);
                setLocalHud(DEFAULT_HUD_LAYOUT);
                audioEngine.playUiClick();
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
            </button>
            <button
              onClick={handleSaveAll}
              className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer"
            >
              Save Changes
            </button>
          </div>
        </div>

        {savedMsg && (
          <div className="mx-5 mt-3 px-3.5 py-2 rounded-lg bg-emerald-500/20 border border-emerald-400/50 text-emerald-200 text-xs font-semibold">
            {savedMsg}
          </div>
        )}

        <div className="p-5 overflow-y-auto tactical-scroll flex-1">
          {tab === 'sensitivity' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {sensFields.map(({ key, label }) => (
                <div key={key} className="p-4 rounded-xl bg-slate-950/75 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-display font-bold text-sm text-white">{label}</span>
                    <span className="font-mono-num text-sm font-bold text-amber-400">{localSens[key]}</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={localSens[key]}
                    onChange={(e) =>
                      setLocalSens((prev) => ({ ...prev, [key]: Number(e.target.value) }))
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono-num mt-1">
                    <span>0</span>
                    <span>50</span>
                    <span>100</span>
                  </div>
                </div>
              ))}
            </div>
          ) : tab === 'export' ? (
            <div className="space-y-4">
              <div className="p-5 rounded-xl bg-slate-950/80 border border-amber-400/25 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-display text-base font-bold text-white">
                    Export Playable HTML &amp; Full Source ZIP
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Download either the single-file runnable HTML or the complete editable project ZIP (all TypeScript, Three.js, React, Capacitor &amp; GitHub Actions APK files).
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <PWAInstallButton />
                  <a
                    href="/FIRE-BD-standalone.html"
                    download="FIRE-BD-standalone.html"
                    onClick={() => audioEngine.playUiClick()}
                    className="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold inline-flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    Download HTML
                  </a>
                  <a
                    href="/FIRE-BD-full-project.zip"
                    download="FIRE-BD-full-project.zip"
                    onClick={() => audioEngine.playUiClick()}
                    className="px-4 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold inline-flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    Download Project ZIP
                  </a>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/75 border border-emerald-400/20 space-y-2 text-xs text-slate-300">
                <div className="font-display font-bold text-emerald-300">Android APK Packaging Options</div>
                <ul className="space-y-1.5 text-[11px] text-slate-300 leading-relaxed">
                  <li>
                    <span className="text-white font-semibold">1. Instant PWA Install:</span> Open in Android Chrome and tap <em>Install App</em> (or Browser Menu → Install App) to run full-screen like a native app.
                  </li>
                  <li>
                    <span className="text-white font-semibold">2. Signed APK via PWABuilder:</span> Paste the Shared App URL into <span className="text-amber-300">pwabuilder.com</span> and click <em>Package for Stores → Android APK</em>.
                  </li>
                  <li>
                    <span className="text-white font-semibold">3. Native Capacitor APK:</span> Project includes Capacitor config & GitHub Actions workflow — push to GitHub or run <code className="px-1.5 py-0.5 rounded bg-slate-800 text-amber-300">npx cap sync android</code> to compile <code className="px-1.5 py-0.5 rounded bg-slate-800 text-amber-300">app-debug.apk</code>.
                  </li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/60 border border-white/10 space-y-2 text-xs text-slate-300">
                <div className="font-display font-bold text-amber-300">Quick Edit Guide (Modular Source)</div>
                <p className="text-slate-400">
                  Use the AI Studio Download ZIP button to export all editable TypeScript/React source files, or edit directly and regenerate the standalone HTML anytime with <code className="px-1.5 py-0.5 rounded bg-slate-800 text-amber-300">npm run build:html</code>.
                </p>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1 text-[11px] text-slate-300">
                  <li><span className="text-amber-400 font-semibold">Weapons, Bundles, Emotes, Prices:</span> catalog data module</li>
                  <li><span className="text-amber-400 font-semibold">PRIME Intro & Login Screen:</span> splash component</li>
                  <li><span className="text-amber-400 font-semibold">3D Lobby & Weather:</span> lobby scene module</li>
                  <li><span className="text-amber-400 font-semibold">Combat, HUD & Physics:</span> battle arena module</li>
                </ul>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Selected Button Properties Bar */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-white/10 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="text-[11px] text-slate-400">Selected Control</div>
                  <div className="font-display font-bold text-sm text-amber-400">{selectedBtn.label}</div>
                </div>

                <div className="flex items-center gap-3 flex-1 max-w-xs">
                  <span className="text-xs text-slate-300 whitespace-nowrap">
                    Size {Math.round(selectedBtn.scale * 100)}%
                  </span>
                  <input
                    type="range"
                    min={10}
                    max={150}
                    value={Math.round(selectedBtn.scale * 100)}
                    onChange={(e) => {
                      const scale = Number(e.target.value) / 100;
                      setLocalHud((prev) =>
                        prev.map((b) => (b.id === selectedBtn.id ? { ...b, scale } : b))
                      );
                    }}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                <div className="flex items-center gap-3 flex-1 max-w-xs">
                  <span className="text-xs text-slate-300 whitespace-nowrap">
                    Opacity {Math.round(selectedBtn.opacity * 100)}%
                  </span>
                  <input
                    type="range"
                    min={10}
                    max={100}
                    value={Math.round(selectedBtn.opacity * 100)}
                    onChange={(e) => {
                      const opacity = Number(e.target.value) / 100;
                      setLocalHud((prev) =>
                        prev.map((b) => (b.id === selectedBtn.id ? { ...b, opacity } : b))
                      );
                    }}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Interactive Drag-and-Drop HUD Canvas */}
              <div
                ref={previewRef}
                onPointerMove={handlePointerMove}
                onPointerUp={() => {
                  draggingIdRef.current = null;
                }}
                onPointerLeave={() => {
                  draggingIdRef.current = null;
                }}
                className="relative w-full h-[360px] sm:h-[420px] rounded-xl bg-slate-950 border border-white/15 overflow-hidden select-none touch-none"
              >
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.08),transparent_70%)] pointer-events-none" />
                <div className="absolute top-2.5 left-3 text-[11px] text-slate-400 pointer-events-none">
                  Drag any button to reposition · Tap to adjust size (10–150%) and transparency (10–100%)
                </div>

                {localHud.map((btn) => {
                  const isSel = btn.id === selectedBtnId;
                  const isRect = btn.id === 'weaponSwitch' || btn.id === 'ping' || btn.id === 'drive' || btn.id === 'revive';
                  return (
                    <button
                      key={btn.id}
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                        setSelectedBtnId(btn.id);
                        draggingIdRef.current = btn.id;
                      }}
                      onPointerUp={() => {
                        draggingIdRef.current = null;
                      }}
                      style={{
                        left: `${btn.xPct}%`,
                        top: `${btn.yPct}%`,
                        transform: `translate(-50%, -50%) scale(${btn.scale})`,
                        opacity: btn.opacity,
                      }}
                      className={`absolute px-2.5 py-1.5 border-2 text-[10px] font-display font-bold cursor-move touch-none ${
                        isRect ? 'rounded-lg' : 'rounded-full'
                      } ${
                        btn.id === 'fire' || btn.id === 'leftFire'
                          ? 'bg-red-600/80 text-white w-14 h-14 flex items-center justify-center'
                          : btn.id === 'joystick'
                          ? 'bg-slate-800/80 text-amber-300 w-20 h-20 flex items-center justify-center'
                          : 'bg-slate-800/85 text-white'
                      } ${isSel ? 'border-amber-400 ring-2 ring-amber-400/40' : 'border-white/30'}`}
                    >
                      {btn.label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
