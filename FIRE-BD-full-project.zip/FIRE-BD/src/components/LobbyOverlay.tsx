import React, { useState } from 'react';
import {
  Car,
  CloudRain,
  Crosshair,
  Gem,
  MessageSquare,
  Mic,
  MicOff,
  Moon,
  Play,
  Plus,
  Settings,
  Shield,
  Shirt,
  ShoppingBag,
  Smile,
  Sparkles,
  Sun,
  ThumbsUp,
  UserPlus,
  Users,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { GAME_IMAGES } from '../data/assets';
import { EMOTES, GAME_MODES } from '../data/catalog';
import {
  ChatMessage,
  FriendEntry,
  GameModeId,
  LobbyInspectTarget,
  LobbyWeather,
  PlayerProfile,
  TeamFormat,
} from '../types/game';
import { audioEngine } from '../utils/sound';
import { PWAInstallButton } from './PWAInstallButton';

export type LobbyModalType =
  | null
  | 'store'
  | 'topup'
  | 'luck_royale'
  | 'vault'
  | 'weapons'
  | 'vehicles'
  | 'settings'
  | 'profile';

interface LobbyOverlayProps {
  profile: PlayerProfile;
  selectedModeId: GameModeId;
  selectedFormat: TeamFormat;
  friends: FriendEntry[];
  chatMessages: ChatMessage[];
  inspectTarget: LobbyInspectTarget;
  weather: LobbyWeather;
  onSelectMode: (modeId: GameModeId) => void;
  onSelectFormat: (format: TeamFormat) => void;
  onStartMatch: () => void;
  onOpenModal: (modal: LobbyModalType) => void;
  onAddFriend: (query: string) => void;
  onToggleSquadInvite: (uid: string) => void;
  onSendChat: (text: string) => void;
  onSetInspectTarget: (target: LobbyInspectTarget) => void;
  onChangeWeather: (weather: LobbyWeather) => void;
  onPlayEmote: (emoteId: string) => void;
}

export const LobbyOverlay: React.FC<LobbyOverlayProps> = ({
  profile,
  selectedModeId,
  selectedFormat,
  friends,
  chatMessages,
  inspectTarget,
  weather,
  onSelectMode,
  onSelectFormat,
  onStartMatch,
  onOpenModal,
  onAddFriend,
  onToggleSquadInvite,
  onSendChat,
  onSetInspectTarget,
  onChangeWeather,
  onPlayEmote,
}) => {
  const [socialOpen, setSocialOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [emoteOpen, setEmoteOpen] = useState(false);
  const [modeMenuOpen, setModeMenuOpen] = useState(false);
  const [friendQuery, setFriendQuery] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [micOn, setMicOn] = useState(true);
  const [mutedAudio, setMutedAudio] = useState(audioEngine.muted);

  const currentMode = GAME_MODES.find((m) => m.id === selectedModeId) ?? GAME_MODES[0];
  const squadMembers = friends.filter((f) => f.inSquad);
  const mapThumb =
    currentMode.mapKey === 'sonar_island' ? GAME_IMAGES.mapSonarIsland : GAME_IMAGES.mapDhakaYard;

  const handleFriendSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendQuery.trim()) return;
    onAddFriend(friendQuery.trim());
    setFriendQuery('');
    audioEngine.playUiClick();
  };

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    onSendChat(chatInput.trim());
    setChatInput('');
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-3 sm:p-5">
      {/* TOP ROW: Player Profile (Left) + Currencies & Social/Squad Bar (Right) */}
      <div className="flex items-start justify-between gap-4">
        {/* Top-Left Player Profile Card */}
        <div className="pointer-events-auto flex items-center gap-3">
          <button
            onClick={() => {
              audioEngine.playUiClick();
              onOpenModal('profile');
            }}
            className="flex items-center gap-3 bg-slate-950/88 hover:bg-slate-900 border border-white/15 rounded-xl px-3.5 py-2 transition-colors text-left cursor-pointer"
          >
            <div className="w-10 h-10 rounded-lg bg-amber-500 text-slate-950 font-display font-extrabold flex items-center justify-center text-base shrink-0">
              {profile.username.slice(0, 2).toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-sm text-white truncate max-w-[130px]">
                  {profile.username}
                </span>
                {profile.isAdmin ? (
                  <span className="text-[10px] text-emerald-400 font-bold whitespace-nowrap">
                    ADMIN
                  </span>
                ) : (
                  profile.provider === 'guest' &&
                  profile.boundProviders.length === 0 && (
                    <span className="text-[10px] text-amber-400 font-semibold whitespace-nowrap">
                      Bind ID
                    </span>
                  )
                )}
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono-num">
                <span>{profile.rankTier}</span>
                <span>·</span>
                <span className="flex items-center gap-1 text-amber-300">
                  <ThumbsUp className="w-3 h-3" /> {profile.likes}
                </span>
              </div>
            </div>
          </button>

          {/* Diamonds & Gold Bar */}
          <div className="hidden sm:flex items-center gap-2 bg-slate-950/88 border border-white/15 rounded-xl px-3 py-2 font-mono-num text-xs">
            <button
              onClick={() => {
                audioEngine.playUiClick();
                onOpenModal('topup');
              }}
              className="flex items-center gap-1.5 text-sky-300 hover:text-white cursor-pointer"
            >
              <Gem className="w-4 h-4 text-sky-400" />
              <span className="font-bold">{profile.diamonds}</span>
              <span className="w-4 h-4 rounded bg-amber-500 text-slate-950 flex items-center justify-center">
                <Plus className="w-3 h-3" />
              </span>
            </button>
            <div className="h-4 w-px bg-white/15 mx-1" />
            <div className="flex items-center gap-1.5 text-amber-300">
              <span className="w-3.5 h-3.5 rounded-full bg-amber-400 inline-block" />
              <span className="font-bold">{profile.gold.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Top-Center Dynamic 3D Weather Toggle */}
        <div className="pointer-events-auto hidden md:flex items-center gap-1 bg-slate-950/88 border border-white/15 rounded-xl p-1">
          {(
            [
              { id: 'clear' as const, label: 'Clear', icon: Sun },
              { id: 'rain' as const, label: 'Rain', icon: CloudRain },
              { id: 'night' as const, label: 'Night', icon: Moon },
            ]
          ).map((w) => {
            const Icon = w.icon;
            const active = weather === w.id;
            return (
              <button
                key={w.id}
                onClick={() => {
                  audioEngine.playUiClick();
                  onChangeWeather(w.id);
                }}
                title={`Set Lobby Weather: ${w.label}`}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-display font-bold transition-colors cursor-pointer ${
                  active
                    ? w.id === 'rain'
                      ? 'bg-sky-500 text-slate-950'
                      : w.id === 'night'
                      ? 'bg-indigo-400 text-slate-950'
                      : 'bg-amber-500 text-slate-950'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{w.label}</span>
              </button>
            );
          })}
        </div>

        {/* Top-Right Social, Squad & Settings Bar */}
        <div className="pointer-events-auto flex items-center gap-2 relative">
          <PWAInstallButton compact />
          {/* Compact Mobile Weather Cycle Button */}
          <button
            onClick={() => {
              audioEngine.playUiClick();
              const order: LobbyWeather[] = ['clear', 'rain', 'night'];
              const next = order[(order.indexOf(weather) + 1) % order.length];
              onChangeWeather(next);
            }}
            title={`Weather: ${weather} (tap to cycle)`}
            className="md:hidden p-2.5 rounded-xl bg-slate-950/88 border border-white/15 text-amber-300 hover:text-white cursor-pointer"
          >
            {weather === 'rain' ? (
              <CloudRain className="w-4 h-4 text-sky-400" />
            ) : weather === 'night' ? (
              <Moon className="w-4 h-4 text-indigo-300" />
            ) : (
              <Sun className="w-4 h-4 text-amber-400" />
            )}
          </button>
          {/* Squad Indicator */}
          <button
            onClick={() => {
              audioEngine.playUiClick();
              setSocialOpen((s) => !s);
            }}
            className="flex items-center gap-2 bg-slate-950/88 hover:bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-xs font-medium text-white cursor-pointer"
          >
            <Users className="w-4 h-4 text-amber-400" />
            <span className="whitespace-nowrap">Squad {1 + squadMembers.length}/4</span>
          </button>

          {/* Voice Mic Toggle */}
          <button
            onClick={() => {
              setMicOn((m) => !m);
              audioEngine.playUiClick();
            }}
            title={micOn ? 'Mute Squad Mic' : 'Unmute Squad Mic'}
            className={`p-2.5 rounded-xl border cursor-pointer ${
              micOn
                ? 'bg-slate-950/88 border-emerald-500/40 text-emerald-400'
                : 'bg-slate-950/88 border-white/15 text-slate-400'
            }`}
          >
            {micOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
          </button>

          {/* Sound Effects Toggle */}
          <button
            onClick={() => {
              audioEngine.muted = !audioEngine.muted;
              setMutedAudio(audioEngine.muted);
            }}
            title="Toggle Audio"
            className="p-2.5 rounded-xl bg-slate-950/88 border border-white/15 text-slate-300 hover:text-white cursor-pointer"
          >
            {mutedAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Settings / HUD / Sensitivity */}
          <button
            onClick={() => {
              audioEngine.playUiClick();
              onOpenModal('settings');
            }}
            title="Custom HUD & Sensitivity"
            className="p-2.5 rounded-xl bg-slate-950/88 border border-white/15 text-slate-200 hover:border-amber-400 cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* Expandable Friend List & Squad Invite Drawer */}
          {socialOpen && (
            <div className="absolute right-0 top-13 w-80 bg-slate-950/95 border border-white/15 rounded-xl p-4 shadow-2xl z-30">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-display font-bold text-sm text-white">Friends & Squad</h3>
                <button
                  onClick={() => setSocialOpen(false)}
                  className="text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Close
                </button>
              </div>

              {/* Add Friend by UID / Username */}
              <form onSubmit={handleFriendSubmit} className="flex gap-1.5 mb-3">
                <input
                  type="text"
                  value={friendQuery}
                  onChange={(e) => setFriendQuery(e.target.value)}
                  placeholder="Add by UID or username..."
                  className="flex-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-amber-400"
                />
                <button
                  type="submit"
                  className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" /> Add
                </button>
              </form>

              <div className="space-y-2 max-h-56 overflow-y-auto tactical-scroll pr-1">
                {friends.map((f) => (
                  <div
                    key={f.uid}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-900/90 border border-white/5"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">{f.username}</div>
                      <div className="text-[10px] text-slate-400 font-mono-num">
                        {f.uid} · {f.rankTier}
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        audioEngine.playUiClick();
                        onToggleSquadInvite(f.uid);
                      }}
                      className={`px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer ${
                        f.inSquad
                          ? 'bg-emerald-600/30 border border-emerald-400/50 text-emerald-300'
                          : f.online
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {f.inSquad ? 'In Squad' : f.online ? 'Invite' : 'Offline'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* MIDDLE: Left-Side Navigation Panel (Store, Luck Royale, Vault, Weapons, Vehicles) */}
      <div className="flex items-center justify-between my-auto">
        <nav className="pointer-events-auto flex flex-col gap-2 w-36 sm:w-44">
          {[
            { id: 'store' as const, label: 'Store', icon: ShoppingBag, inspect: 'character' as const },
            { id: 'luck_royale' as const, label: 'Luck Royale', icon: Sparkles, inspect: 'character' as const },
            { id: 'vault' as const, label: 'Vault', icon: Shirt, inspect: 'character' as const },
            { id: 'weapons' as const, label: 'Weapons', icon: Crosshair, inspect: 'weapon' as const },
            { id: 'vehicles' as const, label: 'Vehicles', icon: Car, inspect: 'vehicle' as const },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  audioEngine.playUiClick();
                  onSetInspectTarget(item.inspect);
                  onOpenModal(item.id);
                }}
                className="flex items-center gap-3 px-3.5 py-2.5 rounded-xl bg-slate-950/88 hover:bg-slate-900 border border-white/15 hover:border-amber-400/60 text-slate-100 text-xs sm:text-sm font-display font-bold tracking-wide transition-colors cursor-pointer"
              >
                <Icon className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="whitespace-nowrap">{item.label}</span>
              </button>
            );
          })}

          {inspectTarget !== 'character' && (
            <button
              onClick={() => onSetInspectTarget('character')}
              className="mt-1 px-3 py-1.5 rounded-lg bg-amber-500/20 border border-amber-400/50 text-amber-300 text-xs font-semibold cursor-pointer"
            >
              Show Character
            </button>
          )}
        </nav>
      </div>

      {/* BOTTOM ROW: Squad Text Chat + Emote Trigger (Left) + Mode Selection & START (Right) */}
      <div className="flex items-end justify-between gap-4">
        {/* Bottom-Left Squad Chat & Emotes */}
        <div className="pointer-events-auto flex items-end gap-2 relative">
          {emoteOpen && (
            <div className="absolute bottom-13 left-0 w-72 bg-slate-950/95 border border-white/15 rounded-xl p-3 shadow-2xl z-30">
              <div className="flex items-center justify-between mb-2">
                <span className="font-display font-bold text-xs text-white">Equipped Emotes</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setEmoteOpen(false);
                      onOpenModal('store');
                    }}
                    className="text-[11px] text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
                  >
                    Store
                  </button>
                  <button
                    onClick={() => setEmoteOpen(false)}
                    className="text-[11px] text-slate-400 hover:text-white cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-1.5 max-h-52 overflow-y-auto tactical-scroll">
                {profile.equippedEmoteIds.map((eid) => {
                  const em = EMOTES.find((x) => x.id === eid);
                  if (!em) return null;
                  return (
                    <button
                      key={em.id}
                      onClick={() => {
                        audioEngine.playUiClick();
                        onSetInspectTarget('character');
                        onPlayEmote(em.id);
                        setEmoteOpen(false);
                      }}
                      className="px-2.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-white/10 hover:border-amber-400/60 text-left cursor-pointer"
                    >
                      <div className="text-[11px] font-display font-bold text-white truncate">
                        {em.name}
                      </div>
                      <div className="text-[10px]" style={{ color: em.accentColor }}>
                        {em.rarity}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <button
            onClick={() => {
              audioEngine.playUiClick();
              setEmoteOpen((e) => !e);
            }}
            className="flex items-center gap-1.5 bg-slate-950/88 hover:bg-slate-900 border border-white/15 hover:border-amber-400/50 rounded-xl px-3 py-2.5 text-xs font-display font-bold text-amber-300 cursor-pointer shrink-0"
            title="Perform Emote"
          >
            <Smile className="w-4 h-4" />
            <span className="hidden sm:inline">Emotes</span>
          </button>

          {chatOpen ? (
            <div className="w-72 sm:w-80 bg-slate-950/92 border border-white/15 rounded-xl p-3 shadow-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="font-display font-bold text-xs text-white">Squad & World Chat</span>
                <button
                  onClick={() => setChatOpen(false)}
                  className="text-[11px] text-slate-400 hover:text-white cursor-pointer"
                >
                  Minimize
                </button>
              </div>
              <div className="h-28 overflow-y-auto tactical-scroll space-y-1.5 text-xs mb-2 pr-1">
                {chatMessages.map((msg) => (
                  <div key={msg.id} className="leading-snug">
                    <span className={msg.isSystem ? 'text-amber-400 font-semibold' : 'text-sky-400 font-semibold'}>
                      {msg.sender}:{' '}
                    </span>
                    <span className="text-slate-200">{msg.text}</span>
                  </div>
                ))}
              </div>
              <form onSubmit={handleChatSubmit} className="flex gap-1.5">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Message squad..."
                  className="flex-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-amber-400"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold cursor-pointer"
                >
                  Send
                </button>
              </form>
            </div>
          ) : (
            <button
              onClick={() => setChatOpen(true)}
              className="flex items-center gap-2 bg-slate-950/88 hover:bg-slate-900 border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 cursor-pointer"
            >
              <MessageSquare className="w-4 h-4 text-amber-400" />
              <span className="max-w-[160px] truncate">
                {chatMessages[chatMessages.length - 1]?.text ?? 'Open Squad Chat'}
              </span>
            </button>
          )}
        </div>

        {/* Bottom-Right Mode Selector + START CTA */}
        <div className="pointer-events-auto relative flex flex-col items-end gap-2">
          {modeMenuOpen && (
            <div className="w-80 sm:w-96 bg-slate-950/95 border border-white/15 rounded-xl p-4 shadow-2xl mb-1">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-display font-bold text-sm text-white">Select Combat Mode</h3>
                <button
                  onClick={() => setModeMenuOpen(false)}
                  className="text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Done
                </button>
              </div>
              <div className="space-y-2 max-h-64 overflow-y-auto tactical-scroll pr-1">
                {GAME_MODES.map((m) => {
                  const active = m.id === selectedModeId;
                  return (
                    <button
                      key={m.id}
                      onClick={() => {
                        audioEngine.playUiClick();
                        onSelectMode(m.id);
                      }}
                      className={`w-full p-2.5 rounded-lg border text-left flex items-center gap-3 transition-colors cursor-pointer ${
                        active
                          ? 'bg-amber-500/20 border-amber-400 text-white'
                          : 'bg-slate-900/80 border-white/10 hover:border-white/25 text-slate-200'
                      }`}
                    >
                      <img
                        src={m.mapKey === 'sonar_island' ? GAME_IMAGES.mapSonarIsland : GAME_IMAGES.mapDhakaYard}
                        alt={m.mapName}
                        referrerPolicy="no-referrer"
                        className="w-16 h-11 rounded object-cover shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-display font-bold text-sm">{m.name}</span>
                          {m.isRanked && (
                            <span className="text-[10px] text-amber-400 font-semibold flex items-center gap-0.5">
                              <Shield className="w-3 h-3" /> Ranked
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate">
                          {m.mapName} · {m.subtitle}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Format selector for the chosen mode */}
              <div className="mt-3 pt-3 border-t border-white/10">
                <div className="text-[11px] text-slate-400 mb-1.5">Team Format</div>
                <div className="flex flex-wrap gap-1.5">
                  {currentMode.supportedFormats.map((fmt) => (
                    <button
                      key={fmt}
                      onClick={() => {
                        audioEngine.playUiClick();
                        onSelectFormat(fmt);
                      }}
                      className={`px-2.5 py-1 rounded text-xs font-mono-num font-bold cursor-pointer ${
                        selectedFormat === fmt
                          ? 'bg-amber-500 text-slate-950'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {fmt}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div className="flex items-stretch gap-2.5">
            {/* Mode Card Trigger */}
            <button
              onClick={() => {
                audioEngine.playUiClick();
                setModeMenuOpen((o) => !o);
              }}
              className="flex items-center gap-3 bg-slate-950/90 hover:bg-slate-900 border border-white/15 rounded-xl p-2 pr-4 text-left cursor-pointer"
            >
              <img
                src={mapThumb}
                alt={currentMode.mapName}
                referrerPolicy="no-referrer"
                className="w-14 h-11 rounded-lg object-cover shrink-0"
              />
              <div>
                <div className="font-display font-bold text-sm text-white flex items-center gap-1.5">
                  <span>{currentMode.name}</span>
                  <span className="text-amber-400 font-mono-num text-xs">{selectedFormat}</span>
                </div>
                <div className="text-[11px] text-slate-400">{currentMode.mapName} · Tap to Switch</div>
              </div>
            </button>

            {/* Primary START Match Button */}
            <button
              onClick={() => {
                audioEngine.playStartChime();
                onStartMatch();
              }}
              className="px-7 sm:px-9 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-extrabold text-base sm:text-lg tracking-wider rounded-xl shadow-xl flex items-center gap-2 transition-transform active:scale-95 cursor-pointer"
            >
              <Play className="w-5 h-5 fill-slate-950" />
              <span>START</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
