import React from 'react';
import { Award, CheckCircle2, Link2, ThumbsUp, Trophy, X } from 'lucide-react';
import { GAME_MODES } from '../data/catalog';
import { AuthProvider, MatchSummary, PlayerProfile } from '../types/game';
import { audioEngine } from '../utils/sound';

interface ProfileModalProps {
  profile: PlayerProfile;
  onBindAccount: (provider: AuthProvider) => void;
  onActivateAdmin: (password: string) => boolean;
  onSignOut: () => void;
  onClose: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  profile,
  onBindAccount,
  onActivateAdmin,
  onSignOut,
  onClose,
}) => {
  const [adminPwd, setAdminPwd] = React.useState('');
  const [adminStatus, setAdminStatus] = React.useState<string | null>(null);

  const bindOptions: Array<{ id: AuthProvider; label: string }> = [
    { id: 'facebook', label: 'Facebook' },
    { id: 'google', label: 'Gmail / Google' },
    { id: 'apple', label: 'Apple ID' },
  ];

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = onActivateAdmin(adminPwd);
    if (ok) {
      audioEngine.playVictoryFanfare();
      setAdminStatus('Admin Mode active: Everything unlocked for free!');
      setAdminPwd('');
    } else {
      setAdminStatus('Invalid admin password.');
    }
  };

  return (
    <div className="fixed inset-0 z-40 bg-slate-950/88 flex items-center justify-center p-4">
      <div className="w-full max-w-xl bg-slate-900 border border-white/15 rounded-2xl p-6 shadow-2xl max-h-[92vh] overflow-y-auto tactical-scroll">
        <div className="flex items-start justify-between border-b border-white/10 pb-4 mb-5">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-xl bg-amber-500 text-slate-950 font-display font-extrabold text-xl flex items-center justify-center">
              {profile.username.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-xl font-bold text-white">{profile.username}</h2>
                {profile.isAdmin && (
                  <span className="text-[11px] font-bold text-emerald-400">ADMIN · FREE EVERYTHING</span>
                )}
              </div>
              <div className="text-xs text-slate-400 font-mono-num mt-0.5">
                UID: {profile.uid} · {profile.rankTier} ({profile.rankPoints} RP)
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Career Stats & Visible Total Likes */}
        <div className="grid grid-cols-4 gap-3 mb-5">
          <div className="p-3 rounded-xl bg-slate-950/75 border border-white/10 text-center">
            <div className="text-[11px] text-slate-400">Total Likes</div>
            <div className="font-mono-num text-lg font-bold text-amber-400 flex items-center justify-center gap-1 mt-0.5">
              <ThumbsUp className="w-4 h-4" /> {profile.likes}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/75 border border-white/10 text-center">
            <div className="text-[11px] text-slate-400">Matches</div>
            <div className="font-mono-num text-lg font-bold text-white mt-0.5">{profile.matches}</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/75 border border-white/10 text-center">
            <div className="text-[11px] text-slate-400">Booyahs</div>
            <div className="font-mono-num text-lg font-bold text-emerald-400 mt-0.5">{profile.booyahs}</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/75 border border-white/10 text-center">
            <div className="text-[11px] text-slate-400">Eliminations</div>
            <div className="font-mono-num text-lg font-bold text-white mt-0.5">{profile.kills}</div>
          </div>
        </div>

        {/* Account Binding Support */}
        <div className="p-4 rounded-xl bg-slate-950/80 border border-white/10 mb-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-display font-bold text-sm text-white flex items-center gap-2">
              <Link2 className="w-4 h-4 text-amber-400" /> Account Binding & Recovery
            </h3>
            <span className="text-[11px] text-slate-400 capitalize">Signed in: {profile.provider}</span>
          </div>
          <p className="text-xs text-slate-400 mb-3">
            Bind your FIRE BD account to preserve Diamonds, Cultural Outfits, Rank, and Likes across devices.
          </p>
          <div className="grid grid-cols-3 gap-2.5">
            {bindOptions.map((opt) => {
              const bound = profile.boundProviders.includes(opt.id);
              return (
                <button
                  key={opt.id}
                  disabled={bound}
                  onClick={() => {
                    audioEngine.playUiClick();
                    onBindAccount(opt.id);
                  }}
                  className={`py-2 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer ${
                    bound
                      ? 'bg-emerald-600/20 border-emerald-500/40 text-emerald-300 cursor-default'
                      : 'bg-slate-900 hover:bg-slate-800 border-white/15 text-white'
                  }`}
                >
                  {bound && <CheckCircle2 className="w-3.5 h-3.5" />}
                  <span>{bound ? `${opt.label} Bound` : `Bind ${opt.label}`}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Admin Unlock / Switch Account */}
        <div className="p-4 rounded-xl bg-slate-950/80 border border-white/10 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-sm text-emerald-300">Admin Access (Free Everything)</h3>
            <button
              type="button"
              onClick={onSignOut}
              className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
            >
              Switch Account
            </button>
          </div>
          {!profile.isAdmin ? (
            <form onSubmit={handleAdminSubmit} className="flex gap-2">
              <input
                type="password"
                value={adminPwd}
                onChange={(e) => {
                  setAdminPwd(e.target.value);
                  setAdminStatus(null);
                }}
                placeholder="Enter admin password..."
                className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-white/15 text-xs text-white focus:outline-none focus:border-emerald-400"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold cursor-pointer"
              >
                Unlock All Free
              </button>
            </form>
          ) : (
            <p className="text-xs text-emerald-300">
              Admin privileges active: all outfits, bundles, gun skins, upgrades, vehicles, and spins are unlocked at 0 cost.
            </p>
          )}
          {adminStatus && <p className="text-xs font-semibold text-amber-300">{adminStatus}</p>}
        </div>
      </div>
    </div>
  );
};

interface MatchSummaryModalProps {
  summary: MatchSummary;
  onLikeParticipant: (participantId: string) => void;
  onReturnLobby: () => void;
}

export const MatchSummaryModal: React.FC<MatchSummaryModalProps> = ({
  summary,
  onLikeParticipant,
  onReturnLobby,
}) => {
  const mode = GAME_MODES.find((m) => m.id === summary.modeId) ?? GAME_MODES[0];

  return (
    <div className="fixed inset-0 z-40 bg-slate-950/92 flex items-center justify-center p-4">
      <div className="w-full max-w-3xl bg-slate-900 border border-white/15 rounded-2xl p-6 shadow-2xl">
        {/* Result Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4 mb-5">
          <div className="flex items-center gap-3.5">
            <div
              className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                summary.victory ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
              }`}
            >
              {summary.victory ? <Trophy className="w-7 h-7" /> : <Award className="w-7 h-7" />}
            </div>
            <div>
              <h2 className="font-display text-3xl font-extrabold tracking-wide text-white">
                {summary.victory ? 'BOOYAH!' : 'MATCH COMPLETE'}
              </h2>
              <div className="text-xs text-slate-400">
                {mode.name} · {summary.format} · {mode.mapName} · {summary.durationSec}s
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 font-mono-num text-xs">
            <div className="text-right">
              <div className="text-slate-400">Gold Earned</div>
              <div className="text-base font-bold text-amber-400">+{summary.goldEarned}</div>
            </div>
            {mode.isRanked && (
              <div className="text-right">
                <div className="text-slate-400">Rank Points</div>
                <div className={`text-base font-bold ${summary.rankDelta >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {summary.rankDelta >= 0 ? `+${summary.rankDelta}` : summary.rankDelta} RP
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Scoreboard with Interactive Like Buttons */}
        <div className="text-xs font-semibold text-slate-300 mb-2">
          Match Scoreboard · Tap Like to commend players
        </div>
        <div className="space-y-2 max-h-64 overflow-y-auto tactical-scroll pr-1 mb-5">
          {summary.participants.map((p) => (
            <div
              key={p.id}
              className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                p.isPlayer
                  ? 'bg-amber-500/15 border-amber-400/60'
                  : p.team === 'ally'
                  ? 'bg-slate-950/75 border-sky-500/30'
                  : 'bg-slate-950/75 border-red-500/20'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    p.team === 'ally' ? 'bg-sky-500/20 text-sky-300' : 'bg-red-500/20 text-red-300'
                  }`}
                >
                  {p.team === 'ally' ? 'SQUAD' : 'OPP'}
                </span>
                <span className="font-display font-bold text-sm text-white truncate">
                  {p.name} {p.isPlayer && '(You)'}
                </span>
              </div>

              <div className="flex items-center gap-4 font-mono-num text-xs shrink-0">
                <span className="text-slate-300">{p.kills} Kills</span>
                <span className="text-slate-400 hidden sm:inline">{p.damage} DMG</span>
                <button
                  disabled={p.likedByMe}
                  onClick={() => {
                    audioEngine.playUiClick();
                    onLikeParticipant(p.id);
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 cursor-pointer transition-colors ${
                    p.likedByMe
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 hover:bg-slate-700 text-amber-300'
                  }`}
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>{p.likedByMe ? 'Liked' : 'Like'} ({p.likesReceived})</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end">
          <button
            onClick={() => {
              audioEngine.playUiClick();
              onReturnLobby();
            }}
            className="px-8 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-extrabold text-sm tracking-wider rounded-xl cursor-pointer"
          >
            RETURN TO LOBBY
          </button>
        </div>
      </div>
    </div>
  );
};
