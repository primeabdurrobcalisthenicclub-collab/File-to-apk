import React, { useState } from 'react';
import { ArrowUpCircle, Smile, Sparkles, X } from 'lucide-react';
import { EMOTES, LUCK_ROYALE_REWARDS, OUTFITS, VEHICLES, WEAPONS, WEAPON_SKINS } from '../data/catalog';
import { PlayerProfile, WeaponClass } from '../types/game';
import { audioEngine } from '../utils/sound';

interface VaultModalProps {
  profile: PlayerProfile;
  onEquipOutfit: (outfitId: string) => void;
  onToggleEquipEmote: (emoteId: string) => void;
  onPreviewEmote: (emoteId: string) => void;
  onOpenStore: (tab?: 'bundles' | 'bangladeshi' | 'emotes') => void;
  onClose: () => void;
}

export const VaultModal: React.FC<VaultModalProps> = ({
  profile,
  onEquipOutfit,
  onToggleEquipEmote,
  onPreviewEmote,
  onOpenStore,
  onClose,
}) => {
  const [filter, setFilter] = useState<'all' | 'bangladeshi' | 'rare_bundle' | 'emotes'>('all');

  const items = OUTFITS.filter((o) => filter === 'all' || o.category === filter);

  return (
    <div className="fixed inset-y-4 left-4 sm:left-6 z-40 w-[calc(100vw-2rem)] sm:w-[430px] bg-slate-950/95 border border-white/15 rounded-2xl flex flex-col shadow-2xl overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/10">
        <div>
          <h2 className="font-display text-lg font-bold text-white">Vault & Emotes</h2>
          <p className="text-[11px] text-slate-400">Equip Outfits, Cultural Attire & Combat Emotes</p>
        </div>
        <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 cursor-pointer">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex gap-1.5 px-4 py-2.5 border-b border-white/10 overflow-x-auto">
        {[
          { id: 'all' as const, label: 'All Outfits' },
          { id: 'bangladeshi' as const, label: 'Bangladeshi' },
          { id: 'rare_bundle' as const, label: 'Rare Bundles' },
          { id: 'emotes' as const, label: `Emotes (${profile.ownedEmoteIds.length}/${EMOTES.length})` },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer ${
              filter === f.id ? 'bg-amber-500 text-slate-950' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="p-4 overflow-y-auto tactical-scroll space-y-2.5 flex-1">
        {filter === 'emotes' ? (
          EMOTES.map((emote) => {
            const owned = profile.ownedEmoteIds.includes(emote.id);
            const equipped = profile.equippedEmoteIds.includes(emote.id);
            return (
              <div
                key={emote.id}
                className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                  equipped ? 'bg-amber-500/15 border-amber-400' : 'bg-slate-900/80 border-white/10'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="w-10 h-10 rounded-lg border border-white/15 shrink-0 flex items-center justify-center"
                    style={{ backgroundColor: `${emote.accentColor}22` }}
                  >
                    <Smile className="w-5 h-5" style={{ color: emote.accentColor }} />
                  </div>
                  <div className="min-w-0">
                    <div className="font-display font-bold text-sm text-white truncate">{emote.name}</div>
                    <div className="text-[11px] text-slate-400">
                      {emote.rarity} · {emote.category.toUpperCase()}
                    </div>
                  </div>
                </div>

                {owned ? (
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => {
                        audioEngine.playUiClick();
                        onPreviewEmote(emote.id);
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 text-xs font-bold cursor-pointer"
                    >
                      Play
                    </button>
                    <button
                      onClick={() => {
                        audioEngine.playUiClick();
                        onToggleEquipEmote(emote.id);
                      }}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                        equipped
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                      }`}
                    >
                      {equipped ? 'Equipped' : 'Equip'}
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => onOpenStore('emotes')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold shrink-0 cursor-pointer"
                  >
                    Unlock in Store
                  </button>
                )}
              </div>
            );
          })
        ) : (
          items.map((item) => {
            const owned = profile.ownedOutfitIds.includes(item.id);
            const equipped = profile.equippedOutfitId === item.id;
            return (
              <div
                key={item.id}
                className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                  equipped ? 'bg-amber-500/15 border-amber-400' : 'bg-slate-900/80 border-white/10'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="w-11 h-11 rounded-lg border border-white/15 shrink-0"
                    style={{
                      background: `linear-gradient(135deg, ${item.primaryColor}, ${item.secondaryColor})`,
                    }}
                  />
                  <div className="min-w-0">
                    <div className="font-display font-bold text-sm text-white truncate">{item.name}</div>
                    <div className="text-[11px] text-slate-400">
                      {item.rarity} · {item.clothStyle.toUpperCase()}
                    </div>
                  </div>
                </div>

                {owned ? (
                  <button
                    onClick={() => {
                      audioEngine.playUiClick();
                      onEquipOutfit(item.id);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold shrink-0 cursor-pointer ${
                      equipped ? 'bg-emerald-500 text-slate-950' : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                    }`}
                  >
                    {equipped ? 'Equipped' : 'Equip'}
                  </button>
                ) : (
                  <button
                    onClick={() => onOpenStore()}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold shrink-0 cursor-pointer"
                  >
                    Unlock in Store
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

interface WeaponsModalProps {
  profile: PlayerProfile;
  onSelectWeapon: (weaponId: string) => void;
  onSelectSkin: (weaponId: string, skinId: string) => void;
  onUpgradeSkin: (skinId: string) => string | null;
  onBuySkin: (skinId: string) => string | null;
  onClose: () => void;
}

export const WeaponsModal: React.FC<WeaponsModalProps> = ({
  profile,
  onSelectWeapon,
  onSelectSkin,
  onUpgradeSkin,
  onBuySkin,
  onClose,
}) => {
  const [selectedClass, setSelectedClass] = useState<'ALL' | WeaponClass>('ALL');
  const [notice, setNotice] = useState<string | null>(null);

  const classes: Array<'ALL' | WeaponClass> = ['ALL', 'AR', 'Marksman', 'SMG', 'Shotgun', 'Sniper', 'Pistol', 'Utility', 'Melee'];
  const weapons = WEAPONS.filter((w) => selectedClass === 'ALL' || w.weaponClass === selectedClass);
  const currentWeapon = WEAPONS.find((w) => w.id === profile.equippedWeaponId) ?? WEAPONS[0];
  const weaponSkins = WEAPON_SKINS.filter((s) => s.weaponId === currentWeapon.id);

  return (
    <div className="fixed inset-y-4 left-4 sm:left-6 z-40 w-[calc(100vw-2rem)] sm:w-[460px] bg-slate-950/95 border border-white/15 rounded-2xl flex flex-col shadow-2xl overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/10">
        <div>
          <h2 className="font-display text-lg font-bold text-white">Weapons & Upgradable Skins</h2>
          <p className="text-[11px] text-slate-400">Drag the 3D weapon on the right to inspect skin finishes</p>
        </div>
        <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 cursor-pointer">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex gap-1.5 px-4 py-2.5 border-b border-white/10 overflow-x-auto">
        {classes.map((c) => (
          <button
            key={c}
            onClick={() => setSelectedClass(c)}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer ${
              selectedClass === c ? 'bg-amber-500 text-slate-950' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {notice && (
        <div className="mx-4 mt-2.5 px-3 py-1.5 rounded-lg bg-amber-500/20 border border-amber-400/50 text-amber-200 text-xs">
          {notice}
        </div>
      )}

      <div className="p-4 overflow-y-auto tactical-scroll space-y-4 flex-1">
        {/* Weapon List */}
        <div className="grid grid-cols-2 gap-2">
          {weapons.map((w) => {
            const active = w.id === currentWeapon.id;
            return (
              <button
                key={w.id}
                onClick={() => {
                  audioEngine.playUiClick();
                  onSelectWeapon(w.id);
                }}
                className={`p-2.5 rounded-xl border text-left cursor-pointer ${
                  active ? 'bg-amber-500/20 border-amber-400 text-white' : 'bg-slate-900/80 border-white/10 text-slate-200'
                }`}
              >
                <div className="text-[10px] text-amber-400 font-semibold">{w.weaponClass}</div>
                <div className="font-display font-bold text-sm">{w.name}</div>
                <div className="text-[11px] text-slate-400 font-mono-num">
                  DMG {w.damage} · MAG {w.magSize}
                </div>
              </button>
            );
          })}
        </div>

        {/* Skins for Selected Weapon */}
        <div className="pt-3 border-t border-white/10">
          <h3 className="font-display font-bold text-sm text-white mb-2.5">
            {currentWeapon.name} Finishes & Evo Upgrades
          </h3>
          <div className="space-y-2.5">
            {weaponSkins.map((s) => {
              const owned = profile.ownedSkinIds.includes(s.id);
              const equipped = profile.equippedSkinIds[currentWeapon.id] === s.id;
              const curLevel = profile.skinLevels[s.id] ?? s.level;
              return (
                <div
                  key={s.id}
                  className={`p-3 rounded-xl border ${
                    equipped ? 'bg-amber-500/15 border-amber-400' : 'bg-slate-900/80 border-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="font-display font-bold text-sm text-white">
                        {s.name} <span className="text-amber-400 text-xs">Lv.{curLevel}/{s.maxLevel}</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        +{s.damageBonus + (curLevel - 1) * 2} Damage · +{s.fireRateBonusPct}% Rate
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {owned ? (
                        <>
                          {curLevel < s.maxLevel && (
                            <button
                              onClick={() => {
                                const err = onUpgradeSkin(s.id);
                                setNotice(err ?? `Upgraded ${s.name} to Lv.${curLevel + 1}!`);
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                            >
                              <ArrowUpCircle className="w-3.5 h-3.5" /> {s.upgradeCostDiamonds} 💎
                            </button>
                          )}
                          <button
                            onClick={() => {
                              audioEngine.playUiClick();
                              onSelectSkin(currentWeapon.id, s.id);
                            }}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                              equipped ? 'bg-emerald-500 text-slate-950' : 'bg-amber-500 text-slate-950'
                            }`}
                          >
                            {equipped ? 'Equipped' : 'Equip'}
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => {
                            const err = onBuySkin(s.id);
                            setNotice(err ?? `Unlocked & equipped ${s.name}!`);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer"
                        >
                          Unlock {s.priceDiamonds} 💎
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

interface VehiclesModalProps {
  profile: PlayerProfile;
  onSelectVehicle: (vehicleId: string) => void;
  onBuyVehicle: (vehicleId: string) => string | null;
  onClose: () => void;
}

export const VehiclesModal: React.FC<VehiclesModalProps> = ({
  profile,
  onSelectVehicle,
  onBuyVehicle,
  onClose,
}) => {
  const [notice, setNotice] = useState<string | null>(null);

  return (
    <div className="fixed inset-y-4 left-4 sm:left-6 z-40 w-[calc(100vw-2rem)] sm:w-[430px] bg-slate-950/95 border border-white/15 rounded-2xl flex flex-col shadow-2xl overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/10">
        <div>
          <h2 className="font-display text-lg font-bold text-white">Vehicle Garage</h2>
          <p className="text-[11px] text-slate-400">All 5 vehicles are drivable on Sonar Island</p>
        </div>
        <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 cursor-pointer">
          <X className="w-5 h-5" />
        </button>
      </div>

      {notice && (
        <div className="mx-4 mt-2.5 px-3 py-1.5 rounded-lg bg-amber-500/20 border border-amber-400/50 text-amber-200 text-xs">
          {notice}
        </div>
      )}

      <div className="p-4 overflow-y-auto tactical-scroll space-y-3 flex-1">
        {VEHICLES.map((v) => {
          const owned = profile.ownedVehicleIds.includes(v.id);
          const equipped = profile.equippedVehicleId === v.id;
          return (
            <div
              key={v.id}
              onClick={() => onSelectVehicle(v.id)}
              className={`p-3.5 rounded-xl border cursor-pointer transition-colors ${
                equipped ? 'bg-amber-500/15 border-amber-400' : 'bg-slate-900/80 border-white/10 hover:border-white/25'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <div className="font-display font-bold text-sm text-white">{v.name}</div>
                {owned ? (
                  <span className="text-[11px] font-bold text-emerald-400">
                    {equipped ? 'Active Showcase' : 'Owned'}
                  </span>
                ) : (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      const err = onBuyVehicle(v.id);
                      setNotice(err ?? `Unlocked ${v.name}!`);
                    }}
                    className="px-3 py-1 rounded-lg bg-amber-500 text-slate-950 text-xs font-bold cursor-pointer"
                  >
                    Buy {v.priceDiamonds} 💎
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-400 mb-2">{v.description}</p>
              <div className="flex items-center gap-3 text-[11px] font-mono-num text-slate-300">
                <span>TOP {v.topSpeed * 4} km/h</span>
                <span>·</span>
                <span>ARMOR {v.armor}</span>
                {v.amphibious && (
                  <>
                    <span>·</span>
                    <span className="text-sky-400 font-semibold">Amphibious</span>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

interface LuckRoyaleModalProps {
  profile: PlayerProfile;
  onSpin: (currency: 'diamonds' | 'gold') => { rewardLabel: string } | { error: string };
  onClose: () => void;
}

export const LuckRoyaleModal: React.FC<LuckRoyaleModalProps> = ({ profile, onSpin, onClose }) => {
  const [spinning, setSpinning] = useState(false);
  const [resultText, setResultText] = useState<string | null>(null);
  const [rotation, setRotation] = useState(0);

  const triggerSpin = (currency: 'diamonds' | 'gold') => {
    if (spinning) return;
    const outcome = onSpin(currency);
    if ('error' in outcome) {
      setResultText(outcome.error);
      return;
    }
    setSpinning(true);
    setResultText(null);
    audioEngine.playStartChime();
    setRotation((r) => r + 1080 + Math.floor(Math.random() * 360));
    setTimeout(() => {
      setSpinning(false);
      setResultText(`Won: ${outcome.rewardLabel}!`);
      audioEngine.playVictoryFanfare();
    }, 1100);
  };

  return (
    <div className="fixed inset-0 z-40 bg-slate-950/88 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-white/15 rounded-2xl p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-5">
          <div>
            <h2 className="font-display text-xl font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" /> Luck Royale Wheel
            </h2>
            <p className="text-xs text-slate-400">Spin for Mythic Bundles, Evo Gun Skins, Vehicles & Diamonds</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          {/* Wheel Visualization */}
          <div className="flex flex-col items-center">
            <div className="relative w-56 h-56 rounded-full border-4 border-amber-400 bg-slate-950 flex items-center justify-center shadow-2xl overflow-hidden">
              <div
                className="absolute inset-2 rounded-full border-2 border-dashed border-amber-300/40 transition-transform duration-1000 ease-out flex items-center justify-center"
                style={{ transform: `rotate(${rotation}deg)` }}
              >
                <div className="w-32 h-32 rounded-full bg-gradient-to-br from-amber-500/30 to-red-600/30 border border-amber-400/50 flex items-center justify-center font-display font-extrabold text-amber-300 text-sm text-center px-2">
                  FIRE BD ROYALE
                </div>
              </div>
              <div className="absolute -top-1 w-0 h-0 border-l-[8px] border-r-[8px] border-t-[14px] border-l-transparent border-r-transparent border-t-amber-400" />
            </div>

            {resultText && (
              <div className="mt-4 px-4 py-2 rounded-lg bg-amber-500/20 border border-amber-400 text-amber-200 text-xs font-bold text-center">
                {resultText}
              </div>
            )}
          </div>

          {/* Prize Pool & Spin Buttons */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-slate-300">Featured Jackpot Pool</div>
            <div className="grid grid-cols-1 gap-1.5 max-h-48 overflow-y-auto tactical-scroll pr-1">
              {LUCK_ROYALE_REWARDS.map((r) => (
                <div
                  key={r.id}
                  className="px-3 py-2 rounded-lg bg-slate-950/75 border border-white/10 flex items-center justify-between text-xs"
                >
                  <span className="text-white font-medium">{r.label}</span>
                  <span className="text-amber-400 font-semibold">{r.rarity}</span>
                </div>
              ))}
            </div>

            <div className="pt-2 flex gap-2.5">
              <button
                disabled={spinning}
                onClick={() => triggerSpin('gold')}
                className="flex-1 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-display font-bold text-xs cursor-pointer disabled:opacity-50"
              >
                {profile.isAdmin ? 'Admin Spin · FREE' : 'Spin · 800 Gold'}
              </button>
              <button
                disabled={spinning}
                onClick={() => triggerSpin('diamonds')}
                className="flex-1 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-xs cursor-pointer disabled:opacity-50"
              >
                {profile.isAdmin ? 'Royal Spin · FREE' : 'Royal Spin · 40 💎'}
              </button>
            </div>
            <div className="text-[11px] text-slate-400 font-mono-num text-center">
              Balance: {profile.diamonds} Diamonds · {profile.gold.toLocaleString()} Gold
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
