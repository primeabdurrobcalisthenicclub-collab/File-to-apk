import React, { useEffect, useRef, useState } from 'react';
import { GAME_IMAGES } from '../data/assets';
import { AuthProvider } from '../types/game';
import { audioEngine } from '../utils/sound';

interface SplashScreenProps {
  onAuthenticate: (provider: AuthProvider, username: string) => void;
}

const LAUNCH_STORAGE_KEY = 'fire_bd_launched_before';

export const SplashScreen: React.FC<SplashScreenProps> = ({ onAuthenticate }) => {
  const [step, setStep] = useState<'intro' | 'loading' | 'tap' | 'login'>('intro');
  const [hasLaunchedBefore] = useState<boolean>(() => {
    try {
      return localStorage.getItem(LAUNCH_STORAGE_KEY) === '1';
    } catch {
      return false;
    }
  });
  const [introTimeSec, setIntroTimeSec] = useState(0);
  const [loadPct, setLoadPct] = useState(0);

  const [customName, setCustomName] = useState('Abdur_Rob_BD');
  const [selectedProvider, setSelectedProvider] = useState<AuthProvider | null>(null);
  const [adminPassword, setAdminPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const soundPlayedRef = useRef(false);

  // 1. PRIME Studio Intro Sequence (~3.4s total)
  useEffect(() => {
    if (step !== 'intro') return;

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

    if (prefersReducedMotion) {
      const t = window.setTimeout(() => {
        try {
          localStorage.setItem(LAUNCH_STORAGE_KEY, '1');
        } catch {
          // ignore
        }
        setStep('loading');
      }, 900);
      return () => window.clearTimeout(t);
    }

    const startMs = performance.now();
    let rafId = 0;

    const frame = (now: number) => {
      const elapsedSec = (now - startMs) / 1000;
      setIntroTimeSec(elapsedSec);

      if (!soundPlayedRef.current && elapsedSec >= 0.08) {
        soundPlayedRef.current = true;
        audioEngine.playStudioIntro();
      }

      if (elapsedSec >= 3.45) {
        try {
          localStorage.setItem(LAUNCH_STORAGE_KEY, '1');
        } catch {
          // ignore
        }
        setStep('loading');
        return;
      }
      rafId = requestAnimationFrame(frame);
    };

    rafId = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafId);
  }, [step]);

  // 2. Game Loading Progress Bar Sequence -> "Tap to Begin"
  useEffect(() => {
    if (step !== 'loading') return;
    const startMs = performance.now();
    const durationMs = 1350;
    let rafId = 0;

    const tickLoad = (now: number) => {
      const progress = Math.min(1, (now - startMs) / durationMs);
      const eased = 1 - Math.pow(1 - progress, 2.2);
      setLoadPct(Math.round(eased * 100));
      if (progress >= 1) {
        setStep('tap');
        return;
      }
      rafId = requestAnimationFrame(tickLoad);
    };

    rafId = requestAnimationFrame(tickLoad);
    return () => cancelAnimationFrame(rafId);
  }, [step]);

  const handleIntroSkip = () => {
    if (!hasLaunchedBefore || introTimeSec < 1.5) return;
    try {
      localStorage.setItem(LAUNCH_STORAGE_KEY, '1');
    } catch {
      // ignore
    }
    audioEngine.playUiClick();
    setStep('loading');
  };

  const handleTapBegin = () => {
    audioEngine.playStartChime();
    setStep('login');
  };

  const handleProviderClick = (provider: AuthProvider) => {
    audioEngine.playUiClick();
    setSelectedProvider(provider);
    setAuthError(null);
  };

  const handleConfirmLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const provider = selectedProvider ?? 'guest';
    if (provider === 'admin') {
      if (adminPassword !== 'prime1bdatnb') {
        setAuthError('Invalid admin password.');
        return;
      }
    }
    const defaultName =
      provider === 'admin'
        ? 'Admin_Abdur_Rob'
        : provider === 'guest'
        ? `Guest_${Math.floor(1000 + Math.random() * 8999)}`
        : 'Abdur_Rob_BD';
    const finalName = customName.trim() || defaultName;
    audioEngine.playStartChime();
    onAuthenticate(provider, finalName);
  };

  // Compute opacity & scale for 0.0-0.5s Fade-In, 0.5-2.5s Hold + Shine, 2.5-3.2s Fade-Out
  let logoOpacity = 1;
  let logoScale = 1;
  if (introTimeSec < 0.5) {
    const p = Math.min(1, Math.max(0, introTimeSec / 0.5));
    const eased = 1 - Math.pow(1 - p, 3);
    logoOpacity = eased;
    logoScale = 0.92 + 0.08 * eased;
  } else if (introTimeSec > 2.5) {
    const out = Math.min(1, Math.max(0, (introTimeSec - 2.5) / 0.7));
    logoOpacity = 1 - out;
    logoScale = 1;
  }

  // Subtle cross-fade dark overlay at 3.2s-3.45s into the main game Loading Screen
  const crossfadeOverlayOpacity =
    introTimeSec > 3.2 ? Math.min(1, (introTimeSec - 3.2) / 0.25) : 0;

  if (step === 'intro') {
    const canSkip = hasLaunchedBefore && introTimeSec >= 1.5;
    return (
      <div
        onClick={handleIntroSkip}
        className={`relative w-full h-full overflow-hidden bg-[#FFFFFF] flex flex-col items-center justify-between select-none px-6 py-5 sm:py-7 ${
          canSkip ? 'cursor-pointer' : 'cursor-default'
        }`}
        aria-label="PRIME Studio Splash Screen"
      >
        {/* Top Spacer (or Skip Hint after 1.5s for returning players) */}
        <div className="w-full flex justify-end min-h-[24px]">
          {canSkip && (
            <span className="text-[11px] sm:text-xs font-medium text-[#6B7280] tracking-wide">
              Tap anywhere to skip
            </span>
          )}
        </div>

        {/* Center Studio Emblem + PRIME Wordmark */}
        <div
          className="relative flex flex-col items-center justify-center overflow-hidden px-6 py-4"
          style={{
            opacity: logoOpacity,
            transform: `scale(${logoScale})`,
            willChange: 'transform, opacity',
          }}
        >
          {/* Sharp-Edged Geometric PRIME Emblem */}
          <svg
            viewBox="0 0 120 88"
            className="w-16 h-12 sm:w-22 sm:h-16 md:w-26 md:h-20 mb-2 sm:mb-3"
            aria-hidden="true"
          >
            {/* Outer crimson blade */}
            <polygon points="14,76 34,12 96,12 108,34 62,34 52,58 28,58 22,76" fill="#E62E00" />
            {/* Vibrant Fire Orange upper shard */}
            <polygon points="34,12 96,12 86,26 42,26" fill="#FF4500" />
            {/* Dark Charcoal sharp bevel core */}
            <polygon points="44,34 86,34 76,52 38,52" fill="#1A1A1A" />
            {/* Fire Orange lower thrust fang */}
            <polygon points="14,76 48,58 76,58 58,76" fill="#FF4500" />
          </svg>

          {/* Large Clean Uppercase Geometric Sans Typography */}
          <div className="flex items-center gap-2.5 sm:gap-3.5">
            <span
              className="font-display font-black uppercase tracking-[0.22em] text-[#E62E00] leading-none"
              style={{ fontSize: 'clamp(2.25rem, 6.5vw, 4.75rem)' }}
            >
              PRIME
            </span>
          </div>

          {/* Sharp Dark Charcoal Accent Underline & Studio Mark */}
          <div className="mt-2 sm:mt-2.5 flex items-center gap-3 w-full max-w-[260px] sm:max-w-[320px]">
            <div className="h-[3px] flex-1 bg-[#1A1A1A]" />
            <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.38em] text-[#1A1A1A]">
              ENTERTAINMENT
            </span>
            <div className="h-[3px] flex-1 bg-[#FF4500]" />
          </div>

          {/* Fast Diagonal Light-Glint Sweep during 0.5s–2.5s hold */}
          <div
            className="pointer-events-none absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/85 to-transparent animate-prime-glint"
            aria-hidden="true"
          />
        </div>

        {/* Bottom Healthy Gaming Advisory & Studio Copyright */}
        <footer className="w-full max-w-2xl text-center">
          <p className="text-[10px] sm:text-xs text-[#6B7280] leading-relaxed">
            Healthy Gaming Advisory: Please play in moderation and take regular breaks.
            © 2025 PRIME Studio · Created by Abdur Rob. All rights reserved.
          </p>
        </footer>

        {/* Subtle cross-fade curtain at 3.2s -> 3.45s */}
        {crossfadeOverlayOpacity > 0 && (
          <div
            className="pointer-events-none absolute inset-0 bg-[#080b10]"
            style={{ opacity: crossfadeOverlayOpacity }}
          />
        )}
      </div>
    );
  }

  const loadingStatusText =
    loadPct < 35
      ? 'Initializing Sonar Island Terrain...'
      : loadPct < 75
      ? 'Loading Tactical Armory & Heritage Skins...'
      : 'Connecting Battle Royale Servers...';

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#080b10] flex flex-col justify-between">
      {/* Cinematic Key Art Backdrop */}
      <img
        src={GAME_IMAGES.splashHeroArt}
        alt="FIRE BD Battle Royale Key Art"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover object-center"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-[#080b10] via-[#080b10]/45 to-[#080b10]/70" />

      {/* Top Creator & Title Header */}
      <div className="relative z-10 flex items-center justify-between px-6 sm:px-10 pt-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-amber-500 flex items-center justify-center font-display font-extrabold text-slate-950 text-lg">
            FB
          </div>
          <div>
            <div className="font-display font-extrabold text-xl tracking-wider text-white">FIRE BD</div>
            <div className="text-xs text-slate-300">Created by Abdur Rob</div>
          </div>
        </div>
        <div className="text-xs text-slate-300 font-mono-num">
          Sonar Island · Dhaka Yard
        </div>
      </div>

      {/* Center / Bottom Interactive Region */}
      <div className="relative z-10 flex flex-col items-center justify-end pb-10 sm:pb-14 px-4">
        {step === 'loading' ? (
          <div className="w-full max-w-xl flex flex-col items-center text-center">
            <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
              FIRE BD
            </h1>
            <div className="w-full bg-slate-950/85 border border-white/15 rounded-xl p-4 shadow-2xl">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-slate-200 font-medium">{loadingStatusText}</span>
                <span className="font-mono-num font-bold text-amber-400">{loadPct}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-white/10">
                <div
                  className="h-full bg-gradient-to-r from-[#E62E00] via-[#FF4500] to-amber-400 transition-all duration-75"
                  style={{ width: `${loadPct}%` }}
                />
              </div>
            </div>
          </div>
        ) : step === 'tap' ? (
          <div className="flex flex-col items-center text-center max-w-xl">
            <p className="text-xs tracking-widest uppercase text-amber-400 font-semibold mb-2">
              Next-Gen 3D Tactical Battle Royale
            </p>
            <h1 className="font-display text-4xl sm:text-6xl font-extrabold text-white tracking-tight text-balance mb-6">
              DROP IN. GEAR UP. SURVIVE.
            </h1>
            <button
              onClick={handleTapBegin}
              className="px-10 py-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-extrabold text-lg tracking-wider rounded-lg shadow-2xl transition-transform active:scale-95 cursor-pointer"
            >
              TAP TO BEGIN
            </button>
            <p className="text-xs text-slate-400 mt-4">
              PBR 3D Graphics · Drivable Vehicles · Bangladeshi Heritage Outfits
            </p>
          </div>
        ) : (
          <div className="w-full max-w-md bg-slate-950/92 border border-white/15 rounded-xl p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="font-display text-xl font-bold text-white">Sign In to FIRE BD</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Choose an account platform, Guest Login, or Admin Access
                </p>
              </div>
              <button
                onClick={() => setStep('tap')}
                className="text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Back
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5 mb-3">
              <button
                type="button"
                onClick={() => handleProviderClick('facebook')}
                className={`py-2.5 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  selectedProvider === 'facebook'
                    ? 'bg-blue-600 border-blue-400 text-white'
                    : 'bg-slate-900 border-white/10 hover:border-blue-500/60 text-slate-200'
                }`}
              >
                <span>Facebook</span>
              </button>
              <button
                type="button"
                onClick={() => handleProviderClick('google')}
                className={`py-2.5 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  selectedProvider === 'google'
                    ? 'bg-red-600 border-red-400 text-white'
                    : 'bg-slate-900 border-white/10 hover:border-red-400/60 text-slate-200'
                }`}
              >
                <span>Gmail / Google</span>
              </button>
              <button
                type="button"
                onClick={() => handleProviderClick('apple')}
                className={`py-2.5 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  selectedProvider === 'apple'
                    ? 'bg-slate-100 border-white text-slate-950'
                    : 'bg-slate-900 border-white/10 hover:border-white/50 text-slate-200'
                }`}
              >
                <span>Apple ID</span>
              </button>
              <button
                type="button"
                onClick={() => handleProviderClick('guest')}
                className={`py-2.5 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  selectedProvider === 'guest'
                    ? 'bg-amber-500 border-amber-300 text-slate-950'
                    : 'bg-slate-900 border-white/10 hover:border-amber-400/60 text-slate-200'
                }`}
              >
                <span>Guest Login</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() => handleProviderClick('admin')}
              className={`w-full mb-4 py-2 px-3 rounded-lg border text-xs font-display font-bold tracking-wide transition-colors cursor-pointer ${
                selectedProvider === 'admin'
                  ? 'bg-emerald-500 border-emerald-300 text-slate-950'
                  : 'bg-slate-900 border-emerald-500/35 hover:border-emerald-400 text-emerald-300'
              }`}
            >
              Admin Login (Free Everything)
            </button>

            <form onSubmit={handleConfirmLogin} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-300 mb-1">Callsign / Username</label>
                <input
                  type="text"
                  maxLength={18}
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-white/15 text-sm text-white focus:outline-none focus:border-amber-400"
                  placeholder="Enter player callsign"
                />
              </div>
              {selectedProvider === 'admin' && (
                <div>
                  <label className="block text-xs text-emerald-300 mb-1">Admin Password</label>
                  <input
                    type="password"
                    required
                    value={adminPassword}
                    onChange={(e) => {
                      setAdminPassword(e.target.value);
                      setAuthError(null);
                    }}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-emerald-500/40 text-sm text-white focus:outline-none focus:border-emerald-400"
                    placeholder="Enter admin password"
                  />
                  {authError && (
                    <p className="text-xs text-red-400 font-semibold mt-1">{authError}</p>
                  )}
                </div>
              )}
              {selectedProvider === 'guest' && (
                <p className="text-[11px] text-amber-300">
                  Guest progress is saved locally and can be bound to Facebook, Gmail, or Apple ID anytime from your Profile.
                </p>
              )}
              <button
                type="submit"
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-sm tracking-wider rounded-lg transition-colors cursor-pointer"
              >
                ENTER LOBBY {selectedProvider ? `(${selectedProvider.toUpperCase()})` : '(GUEST)'}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
