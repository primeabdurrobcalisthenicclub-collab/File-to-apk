import React, { useState } from 'react';
import { CreditCard, Gem, ShieldCheck, Smile, X } from 'lucide-react';
import { DIAMOND_PACKS, EMOTES, OUTFITS, VEHICLES, WEAPON_SKINS } from '../data/catalog';
import { DiamondPack, EmoteCategory, PlayerProfile } from '../types/game';
import { audioEngine } from '../utils/sound';

interface StoreModalProps {
  initialTab?: 'bundles' | 'bangladeshi' | 'emotes' | 'skins' | 'topup';
  profile: PlayerProfile;
  onClose: () => void;
  onBuyOutfit: (outfitId: string, useGold: boolean) => string | null;
  onBuyEmote: (emoteId: string, useGold: boolean) => string | null;
  onBuySkin: (skinId: string) => string | null;
  onBuyVehicle: (vehicleId: string) => string | null;
  onCompleteTopUp: (diamonds: number, cardBrand: string, last4: string) => void;
}

export const StoreModal: React.FC<StoreModalProps> = ({
  initialTab = 'bundles',
  profile,
  onClose,
  onBuyOutfit,
  onBuyEmote,
  onBuySkin,
  onBuyVehicle,
  onCompleteTopUp,
}) => {
  const [tab, setTab] = useState<'bundles' | 'bangladeshi' | 'emotes' | 'skins' | 'topup'>(initialTab);
  const [emoteFilter, setEmoteFilter] = useState<'all' | EmoteCategory>('all');
  const [feedback, setFeedback] = useState<string | null>(null);

  // Payment Gateway state
  const [selectedPack, setSelectedPack] = useState<DiamondPack>(DIAMOND_PACKS[2]);
  const [cardBrand, setCardBrand] = useState<'Visa' | 'Mastercard'>('Visa');
  const [cardNumber, setCardNumber] = useState('4532 8910 2234 7812');
  const [expiry, setExpiry] = useState('09/29');
  const [cvv, setCvv] = useState('482');
  const [holderName, setHolderName] = useState(profile.username);
  const [processingPay, setProcessingPay] = useState(false);

  const showMsg = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 2800);
  };

  const formatCardNumber = (val: string) => {
    const digits = val.replace(/\D/g, '').slice(0, 16);
    if (digits.startsWith('5')) setCardBrand('Mastercard');
    else if (digits.startsWith('4')) setCardBrand('Visa');
    return digits.replace(/(.{4})/g, '$1 ').trim();
  };

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanDigits = cardNumber.replace(/\s/g, '');
    if (cleanDigits.length < 16 || expiry.length < 4 || cvv.length < 3) {
      showMsg('Please enter valid card details.');
      return;
    }
    setProcessingPay(true);
    audioEngine.playUiClick();
    setTimeout(() => {
      setProcessingPay(false);
      const total = selectedPack.diamonds + selectedPack.bonusDiamonds;
      onCompleteTopUp(total, cardBrand, cleanDigits.slice(-4));
      audioEngine.playVictoryFanfare();
      showMsg(`Payment Approved (${cardBrand} •••• ${cleanDigits.slice(-4)}): +${total} Diamonds credited!`);
    }, 850);
  };

  const rareBundles = OUTFITS.filter((o) => o.category === 'rare_bundle');
  const bangladeshiOutfits = OUTFITS.filter((o) => o.category === 'bangladeshi');

  return (
    <div className="fixed inset-0 z-40 bg-slate-950/85 flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-4xl max-h-[90vh] bg-slate-900 border border-white/15 rounded-2xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <div>
            <h2 className="font-display text-xl font-bold text-white">FIRE BD Armory & Store</h2>
            <p className="text-xs text-slate-400">Rare Tactical Bundles, Bangladeshi Cultural Outfits & Diamond Top-Up</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 text-xs font-mono-num">
              <span className="flex items-center gap-1 text-sky-300 font-bold">
                <Gem className="w-4 h-4 text-sky-400" /> {profile.diamonds}
              </span>
              <span className="text-amber-300 font-bold">{profile.gold.toLocaleString()} Gold</span>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 px-5 py-3 border-b border-white/10 overflow-x-auto">
          {[
            { id: 'bundles' as const, label: 'Rare Bundles (400-500 💎)' },
            { id: 'bangladeshi' as const, label: 'Bangladeshi Heritage' },
            { id: 'emotes' as const, label: 'Emotes & Thrones' },
            { id: 'skins' as const, label: 'Gun Skins & Vehicles' },
            { id: 'topup' as const, label: 'Diamond Top-Up (Card)' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => {
                audioEngine.playUiClick();
                setTab(t.id);
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer transition-colors ${
                tab === t.id
                  ? 'bg-amber-500 text-slate-950'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {feedback && (
          <div className="mx-5 mt-3 px-4 py-2 rounded-lg bg-amber-500/20 border border-amber-400/50 text-amber-200 text-xs font-semibold">
            {feedback}
          </div>
        )}

        {/* Content Body */}
        <div className="p-5 overflow-y-auto tactical-scroll flex-1">
          {tab === 'bundles' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {rareBundles.map((item) => {
                const owned = profile.ownedOutfitIds.includes(item.id);
                return (
                  <div
                    key={item.id}
                    className="p-4 rounded-xl bg-slate-950/70 border border-white/10 flex flex-col justify-between gap-3"
                  >
                    <div className="flex items-start gap-3.5">
                      <div
                        className="w-16 h-16 rounded-xl border border-white/15 shrink-0 flex items-center justify-center font-display font-bold text-xs text-white"
                        style={{
                          background: `linear-gradient(135deg, ${item.primaryColor}, ${item.secondaryColor})`,
                        }}
                      >
                        <span style={{ color: item.accentColor }}>{item.rarity}</span>
                      </div>
                      <div>
                        <div className="font-display font-bold text-base text-white">{item.name}</div>
                        <div className="text-[11px] text-amber-400 font-semibold mt-0.5">
                          {item.rarity} Bundle · Cloth & Armor Rig
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{item.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-white/10">
                      <span className="font-mono-num text-sm font-bold text-sky-300 flex items-center gap-1">
                        <Gem className="w-4 h-4 text-sky-400" /> {item.priceDiamonds}
                      </span>
                      <button
                        onClick={() => {
                          const err = onBuyOutfit(item.id, false);
                          showMsg(err ?? `Equipped ${item.name}!`);
                        }}
                        className={`px-4 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                          owned
                            ? 'bg-emerald-600/25 border border-emerald-400/50 text-emerald-300'
                            : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                        }`}
                      >
                        {owned ? 'Owned · Equip' : `Unlock ${item.priceDiamonds} 💎`}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'bangladeshi' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {bangladeshiOutfits.map((item) => {
                const owned = profile.ownedOutfitIds.includes(item.id);
                return (
                  <div
                    key={item.id}
                    className="p-4 rounded-xl bg-slate-950/70 border border-white/10 flex flex-col justify-between gap-3"
                  >
                    <div className="flex items-start gap-3.5">
                      <div
                        className="w-16 h-16 rounded-xl border border-amber-400/30 shrink-0 flex items-center justify-center font-display font-bold text-[11px]"
                        style={{
                          background: `linear-gradient(135deg, ${item.primaryColor}, ${item.secondaryColor})`,
                        }}
                      >
                        <span style={{ color: item.accentColor }}>{item.clothStyle.toUpperCase()}</span>
                      </div>
                      <div>
                        <div className="font-display font-bold text-base text-white">{item.name}</div>
                        <div className="text-[11px] text-emerald-400 font-semibold mt-0.5">
                          Bangladeshi Cultural Heritage · Dynamic Cloth Sway
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{item.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/10">
                      <div className="text-xs font-mono-num text-slate-300">
                        {item.priceDiamonds} 💎 or {item.priceGold.toLocaleString()} Gold
                      </div>
                      <div className="flex gap-2">
                        {!owned && item.priceGold > 0 && (
                          <button
                            onClick={() => {
                              const err = onBuyOutfit(item.id, true);
                              showMsg(err ?? `Unlocked & equipped ${item.name}!`);
                            }}
                            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold cursor-pointer"
                          >
                            Buy Gold
                          </button>
                        )}
                        <button
                          onClick={() => {
                            const err = onBuyOutfit(item.id, false);
                            showMsg(err ?? `Equipped ${item.name}!`);
                          }}
                          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                            owned
                              ? 'bg-emerald-600/25 border border-emerald-400/50 text-emerald-300'
                              : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                          }`}
                        >
                          {owned ? 'Owned · Equip' : `Buy ${item.priceDiamonds} 💎`}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'emotes' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-1.5">
                {[
                  { id: 'all' as const, label: 'All Emotes' },
                  { id: 'dance' as const, label: 'Dance & Fun' },
                  { id: 'action' as const, label: 'Action & Martial Arts' },
                  { id: 'mythic' as const, label: 'Mythic & Thrones' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setEmoteFilter(f.id)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                      emoteFilter === f.id
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {EMOTES.filter((e) => emoteFilter === 'all' || e.category === emoteFilter).map((emote) => {
                  const owned = profile.ownedEmoteIds.includes(emote.id);
                  const equipped = profile.equippedEmoteIds.includes(emote.id);
                  return (
                    <div
                      key={emote.id}
                      className="p-4 rounded-xl bg-slate-950/75 border border-white/10 flex flex-col justify-between gap-3"
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className="w-12 h-12 rounded-xl border border-white/15 shrink-0 flex items-center justify-center"
                          style={{ backgroundColor: `${emote.accentColor}22`, borderColor: `${emote.accentColor}66` }}
                        >
                          <Smile className="w-6 h-6" style={{ color: emote.accentColor }} />
                        </div>
                        <div className="min-w-0">
                          <div className="font-display font-bold text-sm text-white leading-snug">
                            {emote.name}
                          </div>
                          <div className="text-[11px] font-semibold mt-0.5" style={{ color: emote.accentColor }}>
                            {emote.rarity} · {emote.category.toUpperCase()}
                          </div>
                          <p className="text-xs text-slate-400 mt-1">{emote.description}</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/10">
                        <div className="text-xs font-mono-num text-slate-300">
                          {emote.priceDiamonds === 0
                            ? 'Starter Free'
                            : profile.isAdmin
                            ? 'Admin Free'
                            : `${emote.priceDiamonds} 💎 / ${emote.priceGold.toLocaleString()} Gold`}
                        </div>
                        {owned ? (
                          <button
                            onClick={() => {
                              const err = onBuyEmote(emote.id, false);
                              showMsg(err ?? (equipped ? `${emote.name} ready in Emote Wheel` : `Equipped ${emote.name}!`));
                            }}
                            className="px-3.5 py-1.5 rounded-lg bg-emerald-600/25 border border-emerald-400/50 text-emerald-300 text-xs font-bold cursor-pointer"
                          >
                            {equipped ? 'Owned · Equipped' : 'Owned · Equip'}
                          </button>
                        ) : (
                          <div className="flex gap-1.5">
                            {emote.priceGold > 0 && (
                              <button
                                onClick={() => {
                                  const err = onBuyEmote(emote.id, true);
                                  showMsg(err ?? `Unlocked & equipped ${emote.name}!`);
                                }}
                                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold cursor-pointer"
                              >
                                {profile.isAdmin ? 'Free' : `${emote.priceGold.toLocaleString()} Gold`}
                              </button>
                            )}
                            <button
                              onClick={() => {
                                const err = onBuyEmote(emote.id, false);
                                showMsg(err ?? `Unlocked & equipped ${emote.name}!`);
                              }}
                              className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer"
                            >
                              {profile.isAdmin ? 'Claim Free' : `${emote.priceDiamonds} 💎`}
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {tab === 'skins' && (
            <div className="space-y-5">
              <div>
                <h3 className="font-display font-bold text-sm text-white mb-2.5">Upgradable Evo & Rare Gun Skins</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {WEAPON_SKINS.filter((s) => s.priceDiamonds > 0).map((s) => {
                    const owned = profile.ownedSkinIds.includes(s.id);
                    return (
                      <div
                        key={s.id}
                        className="p-3.5 rounded-xl bg-slate-950/70 border border-white/10 flex items-center justify-between gap-3"
                      >
                        <div>
                          <div className="font-display font-bold text-sm text-white">{s.name}</div>
                          <div className="text-[11px] text-amber-400">
                            {s.rarity} · +{s.damageBonus} DMG · +{s.fireRateBonusPct}% Fire Rate
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            const err = onBuySkin(s.id);
                            showMsg(err ?? `Equipped ${s.name}!`);
                          }}
                          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold shrink-0 cursor-pointer ${
                            owned
                              ? 'bg-emerald-600/25 border border-emerald-400/50 text-emerald-300'
                              : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                          }`}
                        >
                          {owned ? 'Owned' : `${s.priceDiamonds} 💎`}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div>
                <h3 className="font-display font-bold text-sm text-white mb-2.5">Garage Vehicles</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {VEHICLES.filter((v) => v.priceDiamonds > 0).map((v) => {
                    const owned = profile.ownedVehicleIds.includes(v.id);
                    return (
                      <div
                        key={v.id}
                        className="p-3.5 rounded-xl bg-slate-950/70 border border-white/10 flex items-center justify-between gap-3"
                      >
                        <div>
                          <div className="font-display font-bold text-sm text-white">{v.name}</div>
                          <div className="text-[11px] text-slate-400">
                            {v.amphibious ? 'Amphibious Water+Land' : `Armor ${v.armor} · Speed ${v.topSpeed * 4} km/h`}
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            const err = onBuyVehicle(v.id);
                            showMsg(err ?? `Unlocked & equipped ${v.name}!`);
                          }}
                          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold shrink-0 cursor-pointer ${
                            owned
                              ? 'bg-emerald-600/25 border border-emerald-400/50 text-emerald-300'
                              : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                          }`}
                        >
                          {owned ? 'Owned' : `${v.priceDiamonds} 💎`}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {tab === 'topup' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {/* Diamond Packs */}
              <div className="space-y-2.5">
                <h3 className="font-display font-bold text-sm text-white mb-2">1. Select Diamond Package</h3>
                {DIAMOND_PACKS.map((pack) => {
                  const active = selectedPack.id === pack.id;
                  return (
                    <button
                      key={pack.id}
                      onClick={() => {
                        audioEngine.playUiClick();
                        setSelectedPack(pack);
                      }}
                      className={`w-full p-3 rounded-xl border flex items-center justify-between text-left cursor-pointer transition-colors ${
                        active
                          ? 'bg-amber-500/20 border-amber-400 text-white'
                          : 'bg-slate-950/70 border-white/10 hover:border-white/25 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Gem className="w-5 h-5 text-sky-400" />
                        <div>
                          <div className="font-display font-bold text-sm">
                            {pack.diamonds} + {pack.bonusDiamonds} Bonus Diamonds
                          </div>
                          <div className="text-[11px] text-slate-400">{pack.label}</div>
                        </div>
                      </div>
                      <span className="font-mono-num font-bold text-sm text-amber-400">
                        ${pack.priceUsd.toFixed(2)}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Visa / Mastercard Payment Gateway */}
              <form
                onSubmit={handleCheckout}
                className="p-4 rounded-xl bg-slate-950/85 border border-white/15 flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-display font-bold text-sm text-white flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-amber-400" />
                      <span>2. Card Payment Gateway</span>
                    </h3>
                    <div className="flex gap-1.5 text-[11px] font-bold">
                      <button
                        type="button"
                        onClick={() => setCardBrand('Visa')}
                        className={`px-2 py-0.5 rounded border cursor-pointer ${
                          cardBrand === 'Visa'
                            ? 'bg-blue-600 border-blue-400 text-white'
                            : 'bg-slate-900 border-white/10 text-slate-400'
                        }`}
                      >
                        VISA
                      </button>
                      <button
                        type="button"
                        onClick={() => setCardBrand('Mastercard')}
                        className={`px-2 py-0.5 rounded border cursor-pointer ${
                          cardBrand === 'Mastercard'
                            ? 'bg-orange-600 border-orange-400 text-white'
                            : 'bg-slate-900 border-white/10 text-slate-400'
                        }`}
                      >
                        MASTERCARD
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Cardholder Name</label>
                      <input
                        type="text"
                        required
                        value={holderName}
                        onChange={(e) => setHolderName(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-white/15 text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Card Number (Credit / Debit)</label>
                      <input
                        type="text"
                        required
                        value={cardNumber}
                        onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-white/15 text-xs font-mono-num text-white focus:outline-none focus:border-amber-400"
                        placeholder="4532 •••• •••• ••••"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Expiry (MM/YY)</label>
                        <input
                          type="text"
                          required
                          maxLength={5}
                          value={expiry}
                          onChange={(e) => setExpiry(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-white/15 text-xs font-mono-num text-white focus:outline-none focus:border-amber-400"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">CVV</label>
                        <input
                          type="password"
                          required
                          maxLength={4}
                          value={cvv}
                          onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                          className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-white/15 text-xs font-mono-num text-white focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10">
                  <div className="flex items-center justify-between text-xs mb-3">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" /> Instant Encrypted Top-Up
                    </span>
                    <span className="font-mono-num font-bold text-white">
                      Total: ${selectedPack.priceUsd.toFixed(2)}
                    </span>
                  </div>
                  <button
                    type="submit"
                    disabled={processingPay}
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-60 text-slate-950 font-display font-bold text-sm rounded-lg cursor-pointer"
                  >
                    {processingPay
                      ? 'Authorizing Card...'
                      : profile.isAdmin
                      ? `Admin Free Claim: +${selectedPack.diamonds + selectedPack.bonusDiamonds} Diamonds ($0.00)`
                      : `Pay $${selectedPack.priceUsd.toFixed(2)} for ${selectedPack.diamonds + selectedPack.bonusDiamonds} Diamonds`}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
