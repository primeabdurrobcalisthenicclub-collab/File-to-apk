export type AuthProvider = 'facebook' | 'google' | 'apple' | 'guest' | 'admin';

export type ScreenStage = 'splash' | 'lobby' | 'matchmaking' | 'ingame' | 'summary';

export type LobbyInspectTarget = 'character' | 'weapon' | 'vehicle';

export type LobbyWeather = 'clear' | 'rain' | 'night';

export type OutfitCategory = 'tactical' | 'rare_bundle' | 'bangladeshi';

export type ClothStyle = 'armor' | 'lungi' | 'panjabi' | 'shirt' | 'shari';

export type EmoteCategory = 'basic' | 'dance' | 'action' | 'mythic';

export interface EmoteDef {
  id: string;
  name: string;
  category: EmoteCategory;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Mythic';
  durationSec: number;
  priceDiamonds: number;
  priceGold: number;
  accentColor: string;
  description: string;
}

export interface OutfitItem {
  id: string;
  name: string;
  category: OutfitCategory;
  clothStyle: ClothStyle;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Mythic';
  priceDiamonds: number;
  priceGold: number;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  skinTone: string;
  description: string;
}

export type WeaponClass = 'AR' | 'SMG' | 'Shotgun' | 'Sniper' | 'Marksman' | 'Pistol' | 'Melee' | 'Utility';

export interface WeaponDef {
  id: string;
  name: string;
  weaponClass: WeaponClass;
  damage: number;
  fireRateMs: number;
  range: number;
  magSize: number;
  reloadMs: number;
  spread: number;
  pellets?: number;
  maxScope: 'none' | 'redDot' | '2x' | '4x' | 'sniper';
  csPrice: number;
  description: string;
}

export interface WeaponSkin {
  id: string;
  weaponId: string;
  name: string;
  rarity: 'Standard' | 'Rare' | 'Evo Lv.2' | 'Evo Lv.4';
  level: number;
  maxLevel: number;
  priceDiamonds: number;
  upgradeCostDiamonds: number;
  bodyColor: string;
  accentColor: string;
  muzzleColor: string;
  damageBonus: number;
  fireRateBonusPct: number;
}

export type VehicleType = 'sports_car' | 'monster_truck' | 'jeep' | 'amphibious_bike' | 'tuk_tuk';

export interface VehicleDef {
  id: string;
  type: VehicleType;
  name: string;
  topSpeed: number;
  acceleration: number;
  handling: number;
  armor: number;
  amphibious: boolean;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  priceDiamonds: number;
  description: string;
}

export type GameModeId = 'br_rank' | 'br_casual' | 'cs_rank' | 'lone_wolf' | 'duel';

export type TeamFormat = '1v1' | '1v2' | '1v4' | '2v2' | '2v4' | '4v4';

export interface GameModeDef {
  id: GameModeId;
  name: string;
  subtitle: string;
  mapName: string;
  mapKey: 'sonar_island' | 'dhaka_yard';
  supportedFormats: TeamFormat[];
  isRanked: boolean;
  roundBased: boolean;
  description: string;
}

export interface SensitivitySettings {
  general: number;
  redDot: number;
  scope2x: number;
  scope4x: number;
  sniperScope: number;
  freeLook: number;
}

export type HudButtonId =
  | 'joystick'
  | 'fire'
  | 'leftFire'
  | 'scope'
  | 'jump'
  | 'crouch'
  | 'prone'
  | 'glooWall'
  | 'sprint'
  | 'weaponSwitch'
  | 'quickSwitch'
  | 'reload'
  | 'medkit'
  | 'backpack'
  | 'activeSkill'
  | 'freeLook'
  | 'revive'
  | 'ping'
  | 'drive';

export interface HudButtonLayout {
  id: HudButtonId;
  label: string;
  xPct: number;
  yPct: number;
  scale: number;
  opacity: number;
}

export interface FriendEntry {
  uid: string;
  username: string;
  rankTier: string;
  online: boolean;
  inSquad: boolean;
  likes: number;
  outfitId: string;
}

export interface ChatMessage {
  id: string;
  sender: string;
  text: string;
  timestamp: string;
  isSystem?: boolean;
}

export interface MatchParticipantStat {
  id: string;
  name: string;
  team: 'ally' | 'enemy';
  isPlayer: boolean;
  kills: number;
  damage: number;
  survived: boolean;
  likesReceived: number;
  likedByMe: boolean;
}

export interface MatchSummary {
  modeId: GameModeId;
  format: TeamFormat;
  victory: boolean;
  placement: number;
  totalTeams: number;
  playerKills: number;
  playerDamage: number;
  rankDelta: number;
  goldEarned: number;
  durationSec: number;
  participants: MatchParticipantStat[];
}

export interface PlayerProfile {
  uid: string;
  username: string;
  provider: AuthProvider;
  boundProviders: AuthProvider[];
  isAdmin?: boolean;
  diamonds: number;
  gold: number;
  likes: number;
  rankTier: string;
  rankPoints: number;
  kills: number;
  matches: number;
  booyahs: number;
  equippedOutfitId: string;
  equippedWeaponId: string;
  equippedSkinIds: Record<string, string>;
  equippedVehicleId: string;
  ownedOutfitIds: string[];
  ownedSkinIds: string[];
  skinLevels: Record<string, number>;
  ownedVehicleIds: string[];
  ownedEmoteIds: string[];
  equippedEmoteIds: string[];
}

export interface DiamondPack {
  id: string;
  diamonds: number;
  bonusDiamonds: number;
  priceUsd: number;
  label: string;
}
