import splashHeroArt from '../assets/images/splash_hero_art_1794605422871.jpg';
import mapSonarIsland from '../assets/images/map_sonar_island_1794605422842.jpg';
import mapDhakaYard from '../assets/images/map_dhaka_yard_1794605423339.jpg';

export const GAME_IMAGES = {
  splashHeroArt,
  mapSonarIsland,
  mapDhakaYard,
};
