# FIRE BD — App Export, Standalone HTML & Android APK Artifact

**Creator:** Abdur Rob  
**Game:** FIRE BD (3D Tactical Battle Royale & Clash Squad)  
**Shared App URL:** https://ais-pre-x2checinc7wnljaztbmzbq-866893593207.asia-northeast1.run.app

---

## 1. Important Environment Note About `.apk` Compilation
AI Studio runs inside a **Node.js / Web Linux sandbox** without Java JDK, Android SDK, or Gradle installed, so a binary `.apk` file cannot be compiled directly inside this container.  
To solve this cleanly, the project now includes:
1. **Self-Contained Single-File HTML (`FIRE-BD-standalone.html`)** — downloadable directly from **Settings → Export HTML / APK → Download HTML** inside the app.
2. **Full Android PWA Compliance (`manifest.webmanifest`, service worker, 192px/512px/maskable PNG icons)** — directly installable onto Android phones in fullscreen landscape mode AND ready for 1-click APK packaging via PWABuilder.
3. **Capacitor Android Config (`capacitor.config.json`) + GitHub Actions Auto-APK Workflow (`.github/workflows/build-android-apk.yml`)** — compiles a real `app-debug.apk` automatically when pushed to GitHub.

---

## 2. How to Get the Android `.apk` File (2 Easy Methods)

### Method A: Fastest — 1-Minute APK via PWABuilder (No Coding or Android Studio Required)
1. Open **https://www.pwabuilder.com/** in your browser.
2. Paste your **Shared App URL**:
   `https://ais-pre-x2checinc7wnljaztbmzbq-866893593207.asia-northeast1.run.app`
3. Click **Start** → PWABuilder detects the configured `manifest.webmanifest`, icons, and service worker automatically.
4. Click **Package for Stores → Android → Generate Package** and download the `.apk` + signing key ZIP directly to your phone or PC.

### Method B: Native Capacitor APK (Automatic Cloud Build via GitHub Actions)
1. Export the full project ZIP from AI Studio (**Download / Export** icon at top-right).
2. Upload/push the repository to **GitHub** (the workflow file `.github/workflows/build-android-apk.yml` is already included).
3. Open the **Actions** tab on GitHub → run **Build FIRE BD Android APK** (or let it run on push).
4. Download the compiled **`FIRE-BD-Android-APK`** (`app-debug.apk`) artifact directly from the GitHub Actions run summary.

### Local Capacitor Commands (If You Have Android Studio Installed)
```bash
npm install
npm run build
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
The APK output will be at: `android/app/build/outputs/apk/debug/app-debug.apk`.

---

## 3. Standalone Single-File HTML Export
- **In-App Download:** Open **Settings → Export HTML / APK → Download HTML** to save `FIRE-BD-standalone.html`.
- **Rebuild After Edits:** Run `npm run build:html` to regenerate `public/FIRE-BD-standalone.html` with all Three.js 3D code, React UI, Tailwind styles, and embedded images bundled inside a single HTML file.

---

## 4. Editable Source Architecture
- `index.html` — Entry HTML template & mobile/PWA metadata
- `src/data/catalog.ts` — Weapons (AR, SMG, Shotgun, Sniper, Pistol, Melee, Gloo), Gun Skins, Outfits (Rare + Bangladeshi Cultural Lungi/Panjabi/Shari), 19 Emotes, Vehicles, and Gold/Diamond pricing
- `src/components/SplashScreen.tsx` — Pure white PRIME Studio 3.5s intro animation, Loading Screen, and Multi-Platform Login (Google, Facebook, Apple, Guest, Admin `prime1bdatnb`)
- `src/three/LobbyScene.tsx` — 3D Interactive Lobby with Character/Weapon/Vehicle inspection, Squad view, and Clear/Rain/Night weather effects
- `src/three/characterBuilder.ts` & `src/three/emoteProps.ts` — 3D modular character assembly, outfit meshes, and skeletal/prop choreography for all 19 emotes
- `src/three/BattleArena.tsx` — Playable 3D Battle Royale & Clash Squad combat engine with full Free Fire-style multi-touch HUD, drag-headshot aim, scopes, vehicles, and live emotes
- `src/components/StoreModal.tsx`, `src/components/ArmoryVaultModals.tsx`, `src/components/SettingsModal.tsx` — Store, Vault, Armory, Vehicles, Luck Royale, Sensitivity, Custom HUD Editor, and Export/APK panel
